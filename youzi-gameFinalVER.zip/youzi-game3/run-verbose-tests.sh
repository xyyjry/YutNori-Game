#!/bin/bash

# 创建输出目录
mkdir -p test-out
mkdir -p test-bin

# 编译模型类
echo "编译模型类..."
javac -d test-bin com/xingyang/yutnori/model/*.java

# 编译测试类
echo "编译测试类..."
javac -d test-bin -cp test-bin:lib/junit-4.13.2.jar:lib/hamcrest-core-1.3.jar test/com/xingyang/yutnori/*.java

# 切换到test-bin目录运行测试
echo "运行详细测试..."
cd test-bin

# 创建一个简单的测试运行器来显示详细输出
cat > DetailTestRunner.java << EOF
import org.junit.runner.JUnitCore;
import org.junit.runner.Result;
import org.junit.runner.notification.Failure;
import org.junit.runner.Description;
import org.junit.runner.notification.RunListener;

public class DetailTestRunner {
    public static void main(String[] args) {
        if (args.length == 0) {
            System.out.println("需要指定测试类");
            System.exit(1);
        }
        
        JUnitCore core = new JUnitCore();
        core.addListener(new RunListener() {
            @Override
            public void testStarted(Description description) {
                System.out.println("开始测试: " + description.getMethodName());
            }
            
            @Override
            public void testFinished(Description description) {
                System.out.println("测试完成: " + description.getMethodName());
                System.out.println("----------------------------------------");
            }
            
            @Override
            public void testFailure(Failure failure) {
                System.out.println("测试失败: " + failure.getDescription().getMethodName());
                System.out.println("原因: " + failure.getMessage());
                System.out.println(failure.getTrace());
            }
        });
        
        try {
            Class<?> testClass = Class.forName(args[0]);
            Result result = core.run(testClass);
            
            System.out.println("========================================");
            System.out.println("测试结果摘要:");
            System.out.println("运行测试: " + result.getRunCount());
            System.out.println("失败测试: " + result.getFailureCount());
            System.out.println("忽略测试: " + result.getIgnoreCount());
            System.out.println("测试时间: " + result.getRunTime() + "ms");
            
            System.exit(result.wasSuccessful() ? 0 : 1);
        } catch (ClassNotFoundException e) {
            System.out.println("找不到测试类: " + args[0]);
            System.exit(1);
        }
    }
}
EOF

# 编译测试运行器
javac -cp .:../lib/junit-4.13.2.jar:../lib/hamcrest-core-1.3.jar DetailTestRunner.java

# 如果没有参数传入，运行所有测试
if [ $# -eq 0 ]; then
    echo "运行所有测试..."
    for TEST_CLASS in YutSetTest PieceTest PlayerTest BoardTest GameTest; do
        echo "========== 运行测试类: $TEST_CLASS =========="
        java -cp .:../lib/junit-4.13.2.jar:../lib/hamcrest-core-1.3.jar DetailTestRunner $TEST_CLASS
        echo ""
    done
else
    # 运行指定测试
    TEST_CLASS=$1
    echo "运行测试类: $TEST_CLASS..."
    java -cp .:../lib/junit-4.13.2.jar:../lib/hamcrest-core-1.3.jar DetailTestRunner $TEST_CLASS
fi

# 返回原目录
cd .. 