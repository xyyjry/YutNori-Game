import org.junit.runner.JUnitCore;
import org.junit.runner.Result;
import org.junit.runner.notification.Failure;
import org.junit.runner.Description;
import org.junit.runner.notification.RunListener;

public class DetailTestRunner {
    public static void main(String[] args) {
        if (args.length == 0) {
            System.out.println("需要指定测试类");
            System.exit(1);
        }
        
        JUnitCore core = new JUnitCore();
        core.addListener(new RunListener() {
            @Override
            public void testStarted(Description description) {
                System.out.println("开始测试: " + description.getMethodName());
            }
            
            @Override
            public void testFinished(Description description) {
                System.out.println("测试完成: " + description.getMethodName());
                System.out.println("----------------------------------------");
            }
            
            @Override
            public void testFailure(Failure failure) {
                System.out.println("测试失败: " + failure.getDescription().getMethodName());
                System.out.println("原因: " + failure.getMessage());
                System.out.println(failure.getTrace());
            }
        });
        
        try {
            Class<?> testClass = Class.forName(args[0]);
            Result result = core.run(testClass);
            
            System.out.println("========================================");
            System.out.println("测试结果摘要:");
            System.out.println("运行测试: " + result.getRunCount());
            System.out.println("失败测试: " + result.getFailureCount());
            System.out.println("忽略测试: " + result.getIgnoreCount());
            System.out.println("测试时间: " + result.getRunTime() + "ms");
            
            System.exit(result.wasSuccessful() ? 0 : 1);
        } catch (ClassNotFoundException e) {
            System.out.println("找不到测试类: " + args[0]);
            System.exit(1);
        }
    }
}
