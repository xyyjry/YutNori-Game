#!/bin/bash

echo "正在启动韩国传统游戏 - 윷놀이 (Yut Nori) 命令行版本..."

# 确保已经编译
if [ ! -d "out" ]; then
  echo "需要先编译游戏，正在编译..."
  sh fix-compile.sh
fi

# 直接运行命令行版本
# 通过环境变量告诉程序直接使用命令行界面
export YUT_NORI_UI_TYPE=2  # 2表示命令行界面
java -cp out com.xingyang.yutnori.YutNoriGame 