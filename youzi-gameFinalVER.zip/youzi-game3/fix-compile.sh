#!/bin/bash

echo "正在清理之前的类文件..."
find . -name "*.class" -type f -delete

echo "确保目录结构正确..."
mkdir -p out

echo "使用单一命令编译所有Java文件，指定正确的类路径..."
javac -d out -sourcepath . com/xingyang/yutnori/model/*.java com/xingyang/yutnori/ui/*.java com/xingyang/*.java com/xingyang/yutnori/*.java com/xingyang/yutnori/ui/cli/*.java com/xingyang/yutnori/ui/swing/*.java com/xingyang/yutnori/controller/*.java com/xingyang/yutnori/ui/interfaces/*.java

if [ $? -eq 0 ]; then
  echo "编译成功！"
  
  # 检查是否有环境变量指定运行
  if [ -n "$YUT_NORI_UI_TYPE" ]; then
    echo "正在运行游戏（UI类型: $YUT_NORI_UI_TYPE）..."
    java -cp out com.xingyang.yutnori.YutNoriGame
  else
    echo "正在运行UI选择界面..."
    java -cp out com.xingyang.yutnori.YutNoriGame
  fi
else
  echo "编译失败，请检查错误信息。"
fi 