package com.xingyang.yutnori.ui;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * 游戏UI选择界面
 * 提供一个更友好的界面让用户选择游戏UI类型
 */
public class UISelectionScreen {
    private JFrame frame;
    private int selectedUIType = -1;
    private boolean selectionMade = false;
    
    /**
     * 创建并显示UI选择界面
     */
    public UISelectionScreen() {
        initialize();
        frame.setVisible(true);
    }
    
    /**
     * 初始化界面组件
     */
    private void initialize() {
        frame = new JFrame("윷놀이 (Yut Nori) - 인터페이스 선택");
        frame.setSize(600, 400);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLocationRelativeTo(null);
        frame.setResizable(false);
        
        // 添加窗口关闭监听器
        frame.addWindowListener(new java.awt.event.WindowAdapter() {
            @Override
            public void windowClosing(java.awt.event.WindowEvent windowEvent) {
                System.out.println("선택 화면이 닫혔습니다. 프로그램 종료");
                System.exit(0);
            }
        });
        
        // 主面板使用BorderLayout
        JPanel mainPanel = new JPanel(new BorderLayout(20, 20));
        mainPanel.setBackground(new Color(245, 245, 245));
        mainPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        
        // 标题面板
        JPanel titlePanel = new JPanel(new BorderLayout());
        titlePanel.setOpaque(false);
        
        JLabel titleLabel = new JLabel("한국 전통 게임 - 윷놀이 (Yut Nori)", JLabel.CENTER);
        titleLabel.setFont(new Font("Malgun Gothic", Font.BOLD, 24));
        titleLabel.setForeground(new Color(139, 69, 19));
        
        JLabel subtitleLabel = new JLabel("사용할 인터페이스를 선택하세요", JLabel.CENTER);
        subtitleLabel.setFont(new Font("Malgun Gothic", Font.PLAIN, 16));
        subtitleLabel.setForeground(new Color(100, 100, 100));
        
        titlePanel.add(titleLabel, BorderLayout.CENTER);
        titlePanel.add(subtitleLabel, BorderLayout.SOUTH);
        
        // 为Mac OS设置Look and Feel以确保按钮正确显示
        String osName = System.getProperty("os.name").toLowerCase();
        if (osName.contains("mac")) {
            try {
                UIManager.setLookAndFeel(UIManager.getCrossPlatformLookAndFeelClassName());
                System.out.println("为Mac OS设置跨平台Look and Feel");
            } catch (Exception e) {
                System.out.println("无法设置Look and Feel: " + e.getMessage());
            }
        }
        
        // 按钮面板 - 1行2列
        JPanel buttonPanel = new JPanel(new GridLayout(1, 2, 30, 0));
        buttonPanel.setOpaque(false);
        buttonPanel.setBorder(BorderFactory.createEmptyBorder(15, 30, 15, 30));
        
        // Swing UI 按钮
        JButton swingButton = createUIButton("그래픽 인터페이스", 
                                            "모든 게임 기능이 포함된\n완벽한 그래픽 인터페이스", 
                                            new Color(70, 130, 180), 1);
        
        // 简易UI 按钮
        JButton simpleButton = createUIButton("간단한 인터페이스", 
                                             "빠른 게임에 적합한\n간결한 게임 인터페이스", 
                                             new Color(220, 80, 80), 3);
        
        buttonPanel.add(swingButton);
        buttonPanel.add(simpleButton);
        
        // 添加说明文本
        JPanel descPanel = new JPanel(new BorderLayout());
        descPanel.setOpaque(false);
        
        JLabel descLabel = new JLabel("언제든지 창을 닫아 게임을 종료할 수 있습니다", JLabel.CENTER);
        descLabel.setFont(new Font("Malgun Gothic", Font.ITALIC, 12));
        descLabel.setForeground(new Color(120, 120, 120));
        
        descPanel.add(descLabel, BorderLayout.CENTER);
        
        // 将所有面板添加到主面板
        mainPanel.add(titlePanel, BorderLayout.NORTH);
        mainPanel.add(buttonPanel, BorderLayout.CENTER);
        mainPanel.add(descPanel, BorderLayout.SOUTH);
        
        frame.add(mainPanel);
    }
    
    /**
     * 创建UI选择按钮
     */
    private JButton createUIButton(String title, String description, Color color, final int uiType) {
        JButton button = new JButton();
        button.setLayout(new BorderLayout());
        
        // 给按钮设置边框颜色而不是背景色
        button.setBackground(Color.WHITE);
        button.setBorder(BorderFactory.createLineBorder(color, 3));
        button.setFocusPainted(false);
        
        // 关键修复：强制Mac OS也显示背景颜色
        button.setOpaque(true);
        button.setContentAreaFilled(true);
        
        JLabel titleLabel = new JLabel(title, JLabel.CENTER);
        titleLabel.setFont(new Font("Malgun Gothic", Font.BOLD, 18));
        titleLabel.setForeground(color);  // 文本颜色使用按钮边框的颜色
        
        JLabel descLabel = new JLabel("<html><div style='text-align: center;'>" + 
                                     description.replace("\n", "<br>") + 
                                     "</div></html>", JLabel.CENTER);
        descLabel.setFont(new Font("Malgun Gothic", Font.PLAIN, 14));
        descLabel.setForeground(new Color(80, 80, 80));  // 深灰色描述文本
        
        // 为标题和描述添加一些padding
        titleLabel.setBorder(BorderFactory.createEmptyBorder(10, 5, 5, 5));
        descLabel.setBorder(BorderFactory.createEmptyBorder(5, 5, 15, 5));
        
        button.add(titleLabel, BorderLayout.NORTH);
        button.add(descLabel, BorderLayout.CENTER);
        
        // 鼠标悬停效果
        button.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                button.setBorder(BorderFactory.createLineBorder(color.darker(), 4));
                button.setBackground(new Color(245, 245, 245));
            }
            
            public void mouseExited(java.awt.event.MouseEvent evt) {
                button.setBorder(BorderFactory.createLineBorder(color, 3));
                button.setBackground(Color.WHITE);
            }
        });
        
        // 点击事件
        button.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                selectedUIType = uiType;
                selectionMade = true;
                frame.dispose();
            }
        });
        
        return button;
    }
    
    /**
     * 等待用户选择并返回选择的UI类型
     */
    public int waitForSelection() {
        // 等待用户做出选择
        while (!selectionMade) {
            try {
                Thread.sleep(100);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        }
        return selectedUIType;
    }
    
    /**
     * 获取用户选择的UI类型
     */
    public int getSelectedUIType() {
        return selectedUIType;
    }
} 