package com.xingyang.yutnori.controller;

import com.xingyang.yutnori.model.Piece;
import com.xingyang.yutnori.model.Player;

/**
 * 游戏状态监听器接口。
 * 实现此接口的类可以接收来自游戏控制器的游戏状态变化通知。
 * 这是MVC架构中实现观察者模式的关键接口。
 */
public interface GameStateListener {
    
    /**
     * 当游戏重置时调用
     */
    void onGameReset();
    
    /**
     * 当掷棒完成时调用
     * @param result 掷棒结果
     */
    void onYutThrown(int result);
    
    /**
     * 当选择特定掷棒结果时调用
     * @param roll 选择的掷棒结果
     */
    void onRollSelected(int roll);
    
    /**
     * 当棋子移动时调用
     * @param piece 移动的棋子
     */
    void onPieceMoved(Piece piece);
    
    /**
     * 当回合结束时调用
     */
    void onTurnEnded();
    
    /**
     * 当游戏结束时调用
     * @param winner 获胜玩家
     */
    void onGameOver(Player winner);

} 