#!/bin/bash

# 清除旧的编译文件
rm -rf out/*

# 确保输出目录存在
mkdir -p out

# 确保simple目录的输出目录存在
mkdir -p out/com/xingyang/yutnori/ui/simple

# 步骤1：先编译模型类
echo "编译模型类..."
javac -d out com/xingyang/yutnori/model/*.java

# 步骤2：编译控制器类
echo "编译控制器类..."
javac -d out -cp out com/xingyang/yutnori/controller/*.java

# 步骤3：编译UI接口
echo "编译UI接口..."
javac -d out -cp out com/xingyang/yutnori/ui/interfaces/*.java

# 步骤4：编译现有UI组件
echo "编译UI组件..."
javac -d out -cp out com/xingyang/yutnori/ui/*.java

# 步骤5：编译Swing UI实现
echo "编译Swing UI实现..."
javac -d out -cp out com/xingyang/yutnori/ui/swing/*.java

# 步骤6：编译命令行UI实现
echo "编译命令行UI实现..."
javac -d out -cp out com/xingyang/yutnori/ui/cli/*.java

# 步骤6b：编译简易UI实现
echo "编译简易UI实现..."
javac -d out -cp out com/xingyang/yutnori/ui/simple/*.java

# 步骤7：编译原有应用类
echo "编译应用类..."
javac -d out -cp out com/xingyang/*.java

# 步骤8：编译新的主程序类
echo "编译主程序类..."
javac -d out -cp out com/xingyang/yutnori/*.java

echo "编译完成。运行以下命令来启动游戏："
echo "java -cp out com.xingyang.yutnori.YutNoriGame" 