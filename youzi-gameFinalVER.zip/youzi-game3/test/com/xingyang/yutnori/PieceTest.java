import org.junit.Test;
import org.junit.Before;
import static org.junit.Assert.*;

import com.xingyang.yutnori.model.Piece;
import com.xingyang.yutnori.model.Player;

import java.awt.Color;

/**
 * 윷놀이 게임의 말 테스트 클래스
 * 말의 이동 및 겹침 논리를 테스트합니다
 */
public class PieceTest {
    
    private Player testPlayer;
    private Piece testPiece;
    
    @Before
    public void setUp() {
        // 테스트용 플레이어와 말 생성
        testPlayer = new Player("TestPlayer", Color.RED);
        testPiece = new Piece(testPlayer, 0);
    }
    
    @Test
    public void testInitialState() {
        // 말의 초기 상태 확인
        assertEquals("말의 ID는 0이어야 합니다", 0, testPiece.getId());
        assertEquals("말의 소유자는 testPlayer여야 합니다", testPlayer, testPiece.getOwner());
        assertEquals("말의 초기 위치는 -1이어야 합니다", -1, testPiece.getPosition());
        assertEquals("말의 이전 위치는 -1이어야 합니다", -1, testPiece.getPreviousPosition());
        assertFalse("말은 초기에 완료되지 않아야 합니다", testPiece.isCompleted());
        assertTrue("말은 초기에 집에 있어야 합니다", testPiece.isHome());
    }
    
    @Test
    public void testSetPosition() {
        // 말 위치 설정 테스트
        testPiece.setPosition(5);
        assertEquals("말의 위치는 5여야 합니다", 5, testPiece.getPosition());
        assertEquals("말의 이전 위치는 -1이어야 합니다", -1, testPiece.getPreviousPosition());
        
        testPiece.setPosition(10);
        assertEquals("말의 위치는 10이어야 합니다", 10, testPiece.getPosition());
        assertEquals("말의 이전 위치는 5여야 합니다", 5, testPiece.getPreviousPosition());
    }
    
    @Test
    public void testHasFinished() {
        // 말이 완주했는지 확인
        assertFalse("말은 초기에 완주하지 않아야 합니다", testPiece.hasFinished());
        testPiece.setPosition(30);
        assertTrue("위치 30의 말은 완주한 것으로 간주되어야 합니다", testPiece.hasFinished());
    }
    
    @Test
    public void testSetCompleted() {
        // 완료 상태 설정 테스트
        assertFalse("말은 초기에 완료되지 않아야 합니다", testPiece.isCompleted());
        testPiece.setCompleted(true);
        assertTrue("말은 완료 상태로 설정되어야 합니다", testPiece.isCompleted());
    }
    
    @Test
    public void testStackPieces() {
        // 말 겹침 테스트
        Piece piece2 = new Piece(testPlayer, 1);
        
        // 초기 상태 확인
        assertFalse("말은 초기에 겹쳐지지 않아야 합니다", testPiece.isStacked());
        assertFalse("말은 초기에 겹침 말이 없어야 합니다", testPiece.hasStackedPieces());
        
        // 말 겹침 테스트
        testPiece.stackPiece(piece2);
        assertTrue("piece2는 겹쳐져야 합니다", piece2.isStacked());
        assertTrue("testPiece는 겹침 말이 있어야 합니다", testPiece.hasStackedPieces());
        assertEquals("piece2의 겹침 리더는 testPiece여야 합니다", testPiece, piece2.getStackLeader());
        assertTrue("testPiece의 겹침 말에는 piece2가 포함되어야 합니다", testPiece.getStackedPieces().contains(piece2));
        
        // 겹침 말과 함께 이동 테스트
        testPiece.setPosition(10);
        assertEquals("testPiece의 위치는 10이어야 합니다", 10, testPiece.getPosition());
        assertEquals("piece2의 위치도 10이어야 합니다", 10, piece2.getPosition());
        
        // 말 겹침 해제 테스트
        testPiece.unstackPiece(piece2);
        assertFalse("piece2는 더 이상 겹쳐지지 않아야 합니다", piece2.isStacked());
        assertFalse("testPiece는 더 이상 겹침 말이 없어야 합니다", testPiece.hasStackedPieces());
    }
    
    @Test
    public void testClearStackedPieces() {
        // 모든 겹침 말 제거 테스트
        Piece piece2 = new Piece(testPlayer, 1);
        Piece piece3 = new Piece(testPlayer, 2);
        
        testPiece.stackPiece(piece2);
        testPiece.stackPiece(piece3);
        
        assertTrue("testPiece는 겹침 말이 있어야 합니다", testPiece.hasStackedPieces());
        assertEquals("testPiece는 2개의 겹침 말이 있어야 합니다", 2, testPiece.getStackedPieces().size());
        
        testPiece.clearStackedPieces();
        assertFalse("testPiece는 더 이상 겹침 말이 없어야 합니다", testPiece.hasStackedPieces());
        assertFalse("piece2는 더 이상 겹쳐지지 않아야 합니다", piece2.isStacked());
        assertFalse("piece3는 더 이상 겹쳐지지 않아야 합니다", piece3.isStacked());
    }
} 