package com.xingyang.yutnori.ui.simple;

import com.xingyang.yutnori.model.*;

import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 简易版游戏棋盘，专为SimpleGameUI设计
 * 完全重新实现，确保所有位置可见
 */
public class SimpleBoardPanel extends JPanel {
    private Game game;
    private Board board;
    
    // UI 常量
    private static final int POSITION_SIZE = 40; // 棋盘位置标记的大小
    private static final int PIECE_SIZE = 30; // 棋子大小
    
    // 位置坐标缓存
    private Map<Integer, Point> scaledPositions;
    
    /**
     * 构造函数
     */
    public SimpleBoardPanel(Game game) {
        this.game = game;
        this.board = game.getBoard();
        this.scaledPositions = new HashMap<>();
        
        setBackground(new Color(250, 245, 220));
        setBorder(BorderFactory.createLineBorder(new Color(139, 69, 19), 2));
        
        // 添加鼠标监听器
        addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                // 只消费事件，不处理，防止点击棋盘导致掷骰子
                e.consume();
            }
        });
    }
    
    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        
        Graphics2D g2d = (Graphics2D) g;
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        
        // 绘制游戏板
        drawBoard(g2d);
        
        // 绘制棋子
        drawPieces(g2d);
    }
    
    /**
     * 绘制游戏板
     */
    private void drawBoard(Graphics2D g2d) {
        int width = getWidth();
        int height = getHeight();
        
        // 计算位置，确保棋盘完全显示
        // 使用更小的边距，确保下部位置可见
        int marginX = 50;
        int marginY = 50;
        int boardWidth = width - 2 * marginX;
        int boardHeight = height - 2 * marginY;
        
        // 绘制背景
        g2d.setColor(new Color(250, 245, 225));
        g2d.fillRect(0, 0, width, height);
        
        // 计算位置坐标 - 使用绝对坐标而不是百分比缩放
        // 这样可以确保位置按照预期排列
        calculatePositions(marginX, marginY, boardWidth, boardHeight);
        
        // 绘制路径
        drawPaths(g2d);
        
        // 绘制位置标记
        for (Map.Entry<Integer, Point> entry : scaledPositions.entrySet()) {
            int position = entry.getKey();
            Point point = entry.getValue();
            boolean isCorner = (position % 5 == 0); // 5, 10, 15, 20 是拐角
            
            drawPosition(g2d, point.x, point.y, position, isCorner);
        }
        
        // 移除图例绘制
        // drawLegend(g2d);
    }
    
    /**
     * 计算棋盘上各位置的坐标
     */
    private void calculatePositions(int marginX, int marginY, int boardWidth, int boardHeight) {
        scaledPositions.clear();
        
        // 主路径坐标 - 使用固定位置，确保完整显示
        int rows = 5;
        int cols = 5;
        int cellWidth = boardWidth / (cols - 1);
        int cellHeight = boardHeight / (rows - 1);
        
        // 顶部路径（5-9）- 从右到左
        for (int i = 0; i < 5; i++) {
            int pos = 5 + i;
            int x = marginX + boardWidth - i * cellWidth;
            int y = marginY;
            scaledPositions.put(pos, new Point(x, y));
        }
        
        // 左侧路径（10-14）- 从上到下
        for (int i = 0; i < 5; i++) {
            int pos = 10 + i;
            int x = marginX;
            int y = marginY + i * cellHeight;
            scaledPositions.put(pos, new Point(x, y));
        }
        
        // 底部路径（15-19）- 从左到右
        for (int i = 0; i < 5; i++) {
            int pos = 15 + i;
            int x = marginX + i * cellWidth;
            int y = marginY + boardHeight;
            scaledPositions.put(pos, new Point(x, y));
        }
        
        // 右侧路径（20,1-4）- 从下到上
        scaledPositions.put(20, new Point(marginX + boardWidth, marginY + boardHeight));
        for (int i = 0; i < 4; i++) {
            int pos = i + 1;
            int x = marginX + boardWidth;
            int y = marginY + boardHeight - (i + 1) * cellHeight;
            scaledPositions.put(pos, new Point(x, y));
        }
        
        // 棋盘中心点27
        int centerX = marginX + boardWidth/2;
        int centerY = marginY + boardHeight/2;
        scaledPositions.put(27, new Point(centerX, centerY));
        
        // 第一条对角线 - 红色路径 (5-21-22-27-24-15)
        Point pos5 = scaledPositions.get(5);
        Point pos27 = scaledPositions.get(27);
        Point pos15 = scaledPositions.get(15);
        
        // 从5到27的中间点
        scaledPositions.put(21, new Point(
            pos5.x - (pos5.x - pos27.x)/3,
            pos27.y - (pos27.y - pos5.y)/3*2
        ));
        
        scaledPositions.put(22, new Point(
            pos5.x - (pos5.x - pos27.x)/3*2,
            pos27.y - (pos27.y - pos5.y)/3
        ));
        
        // 从27到15的中间点
        scaledPositions.put(24, new Point(
            pos27.x - (pos27.x - pos15.x)/2,
            pos27.y + (pos15.y - pos27.y)/2
        ));
        
        // 第二条对角线 - 蓝色路径 (10-25-26-27-28-29-20)
        Point pos10 = scaledPositions.get(10);
        Point pos20 = scaledPositions.get(20);
        
        // 从10到27之间的点
        scaledPositions.put(25, new Point(
            pos10.x + (pos27.x - pos10.x)/3,
            pos10.y + (pos27.y - pos10.y)/3
        ));
        
        scaledPositions.put(26, new Point(
            pos10.x + (pos27.x - pos10.x)/3*2,
            pos10.y + (pos27.y - pos10.y)/3*2
        ));
        
        // 从27到20之间的点
        scaledPositions.put(28, new Point(
            pos27.x + (pos20.x - pos27.x)/3,
            pos27.y + (pos20.y - pos27.y)/3
        ));
        
        scaledPositions.put(29, new Point(
            pos27.x + (pos20.x - pos27.x)/3*2,
            pos27.y + (pos20.y - pos27.y)/3*2
        ));
    }
    
    /**
     * 绘制路径连线
     */
    private void drawPaths(Graphics2D g2d) {
        // 绘制主路径（棕色）
        g2d.setColor(new Color(139, 69, 19));
        g2d.setStroke(new BasicStroke(3f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
        
        // 连接主路径的各个点
        for (int i = 1; i <= 20; i++) {
            int next = (i % 20) + 1;
            if (i == 20) next = 1;
            
            Point start = scaledPositions.get(i);
            Point end = scaledPositions.get(next);
            
            if (start != null && end != null) {
                g2d.drawLine(start.x, start.y, end.x, end.y);
            }
        }
        
        // 绘制对角线路径1（红色） - 5 -> 21 -> 22 -> 27 -> 24 -> 15
        g2d.setColor(new Color(200, 0, 0));
        g2d.setStroke(new BasicStroke(2.5f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
        
        // 绘制红色对角线路径
        drawPathSegment(g2d, 5, 21);
        drawPathSegment(g2d, 21, 22);
        drawPathSegment(g2d, 22, 27);
        drawPathSegment(g2d, 27, 24);
        drawPathSegment(g2d, 24, 15);
        
        // 绘制对角线路径2（蓝色） - 10 -> 25 -> 26 -> 27 -> 28 -> 29 -> 20
        g2d.setColor(new Color(0, 100, 200));
        g2d.setStroke(new BasicStroke(2.5f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
        
        // 绘制蓝色对角线路径
        drawPathSegment(g2d, 10, 25);
        drawPathSegment(g2d, 25, 26);
        drawPathSegment(g2d, 26, 27);
        drawPathSegment(g2d, 27, 28);
        drawPathSegment(g2d, 28, 29);
        drawPathSegment(g2d, 29, 20);
    }
    
    /**
     * 绘制路径线段
     */
    private void drawPathSegment(Graphics2D g2d, int from, int to) {
        Point start = scaledPositions.get(from);
        Point end = scaledPositions.get(to);
        
        if (start != null && end != null) {
            // 对于涉及位置22的连接，使用更粗的线条
            if (from == 22 || to == 22) {
                Stroke originalStroke = g2d.getStroke();
                g2d.setStroke(new BasicStroke(3.5f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
                g2d.drawLine(start.x, start.y, end.x, end.y);
                g2d.setStroke(originalStroke);
            } else {
                g2d.drawLine(start.x, start.y, end.x, end.y);
            }
            
            // 绘制箭头
            drawArrow(g2d, start.x, start.y, end.x, end.y);
        }
    }
    
    /**
     * 绘制箭头
     */
    private void drawArrow(Graphics2D g2d, int x1, int y1, int x2, int y2) {
        double angle = Math.atan2(y2 - y1, x2 - x1);
        int arrowSize = 6;
        
        // 箭头点1
        int ax1 = (int)(x2 - arrowSize * Math.cos(angle - Math.PI/6));
        int ay1 = (int)(y2 - arrowSize * Math.sin(angle - Math.PI/6));
        
        // 箭头点2
        int ax2 = (int)(x2 - arrowSize * Math.cos(angle + Math.PI/6));
        int ay2 = (int)(y2 - arrowSize * Math.sin(angle + Math.PI/6));
        
        // 绘制箭头
        g2d.drawLine(x2, y2, ax1, ay1);
        g2d.drawLine(x2, y2, ax2, ay2);
    }
    
    /**
     * 绘制棋盘上的位置点
     */
    private void drawPosition(Graphics2D g2d, int x, int y, int position, boolean isCorner) {
        // 不同类型位置使用不同颜色
        Color fillColor;
        int size = isCorner ? POSITION_SIZE + 5 : POSITION_SIZE;
        
        if (position == 27) {
            // 中心点用粉色边框
            size += 5; // 中心点略大
            fillColor = new Color(200, 200, 255);
            // 绘制带边框的点
            g2d.setColor(new Color(255, 150, 150));
            g2d.setStroke(new BasicStroke(2.0f));
            g2d.drawOval(x - size/2 - 2, y - size/2 - 2, size + 4, size + 4);
        } else if (position == 22) {
            // 位置22使用醒目的黄色，与图片一致
            fillColor = new Color(255, 220, 100);
            size += 2;
        } else if (position == 23) {
            // 中心点用粉色
            fillColor = new Color(255, 150, 150);
            size += 5;
        } else if (position % 5 == 0) {
            // 拐角点用浅棕色
            fillColor = new Color(240, 200, 140);
        } else if (position >= 21 && position <= 29) {
            // 对角线路径点用浅蓝色
            fillColor = new Color(200, 200, 255);
        } else {
            // 普通点用米色
            fillColor = new Color(245, 222, 179);
        }
        
        // 绘制位置圆形
        g2d.setColor(fillColor);
        g2d.fillOval(x - size/2, y - size/2, size, size);
        
        // 绘制边框
        g2d.setColor(new Color(139, 69, 19));
        g2d.setStroke(new BasicStroke(1.5f));
        g2d.drawOval(x - size/2, y - size/2, size, size);
        
        // 绘制位置编号
        g2d.setFont(new Font("Arial", Font.BOLD, isCorner ? 14 : 12));
        g2d.setColor(new Color(80, 40, 0));
        String posStr = String.valueOf(position);
        FontMetrics fm = g2d.getFontMetrics();
        int textWidth = fm.stringWidth(posStr);
        int textHeight = fm.getAscent();
        g2d.drawString(posStr, x - textWidth/2, y + textHeight/2 - 1);
    }
    
    /**
     * 绘制棋子
     */
    private void drawPieces(Graphics2D g2d) {
        // 获取所有玩家
        List<Player> players = game.getPlayers();
        
        // 绘制所有棋子
        for (Player player : players) {
            // 设置玩家颜色
            Color playerColor = player.getColor();
            
            // 获取玩家的所有棋子
            List<Piece> pieces = player.getPieces();
            
            // 绘制每个棋子
            for (Piece piece : pieces) {
                // 获取棋子位置
                int position = piece.getPosition();
                
                // 如果棋子在棋盘上（不在家里也没有结束）
                if (position >= 0 && position <= 29) {
                    Point pos = scaledPositions.get(position);
                    if (pos != null) {
                        drawPiece(g2d, pos.x, pos.y, piece.getId(), playerColor);
                    }
                }
            }
        }
    }
    
    /**
     * 绘制单个棋子
     */
    private void drawPiece(Graphics2D g2d, int x, int y, int pieceId, Color color) {
        // 绘制棋子底色
        g2d.setColor(color);
        g2d.fillOval(x - PIECE_SIZE/2, y - PIECE_SIZE/2, PIECE_SIZE, PIECE_SIZE);
        
        // 绘制棋子边框
        g2d.setColor(Color.BLACK);
        g2d.setStroke(new BasicStroke(1.5f));
        g2d.drawOval(x - PIECE_SIZE/2, y - PIECE_SIZE/2, PIECE_SIZE, PIECE_SIZE);
        
        // 绘制棋子编号
        g2d.setColor(Color.WHITE);
        g2d.setFont(new Font("Arial", Font.BOLD, 12));
        String idStr = String.valueOf(pieceId + 1);
        FontMetrics fm = g2d.getFontMetrics();
        int textWidth = fm.stringWidth(idStr);
        g2d.drawString(idStr, x - textWidth/2, y + fm.getAscent()/2 - 1);
    }
    
    /**
     * 获取Game对象
     */
    public Game getGame() {
        return game;
    }
} 