package com.xingyang.yutnori.ui.interfaces;

import com.xingyang.yutnori.controller.GameController;
import com.xingyang.yutnori.model.Piece;
import com.xingyang.yutnori.model.Player;

/**
 * 游戏UI接口。
 * 定义了游戏用户界面必须实现的方法。
 * 不同UI实现（如Swing、JavaFX等）都应该实现这个接口。
 */
public interface GameUI {
    
    /**
     * 初始化UI
     * @param controller 游戏控制器
     */
    void initialize(GameController controller);
    
    /**
     * 显示游戏UI
     */
    void show();
    
    /**
     * 关闭游戏UI
     */
    void close();
    
    /**
     * 更新游戏状态显示
     */
    void updateGameState();
    
    /**
     * 更新当前玩家信息
     * @param currentPlayer 当前玩家
     */
    void updateCurrentPlayer(Player currentPlayer);
    
    /**
     * 更新掷棒结果显示
     * @param result 掷棒结果
     */
    void updateYutResult(int result);
    
    /**
     * 更新棋子位置显示
     * @param piece 移动的棋子
     */
    void updatePiecePosition(Piece piece);
    
    /**
     * 显示游戏结束信息
     * @param winner 获胜玩家
     */
    void showGameOver(Player winner);
    
    /**
     * 重置UI到初始状态
     */
    void resetUI();
} 