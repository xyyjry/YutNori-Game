package com.xingyang.yutnori.model;

import java.util.Random;

/**
 * Constants for Yut stick results.
 * 
 * In Yut Nori, the possible results from throwing the four sticks are:
 * - DO (도): Move 1 space
 * - GAE (개): Move 2 spaces
 * - GEOL (걸): Move 3 spaces
 * - YUT (윷): Move 4 spaces and throw again
 * - MO (모): Move 5 spaces and throw again
 * - BACKDO (백도): Move 1 space backwards
 */
public class YutSet {
    // Constants for the different possible throws
    public static final int DO = 1;      // 도 (Do): Move 1 space
    public static final int GAE = 2;     // 개 (Gae): Move 2 spaces
    public static final int GEOL = 3;    // 걸 (Geol): Move 3 spaces
    public static final int YUT = 4;     // 윷 (Yut): Move 4 spaces and throw again
    public static final int MO = 5;      // 모 (Mo): Move 5 spaces and throw again
    public static final int BACKDO = -1;  // 백도 (Backdo): Move 1 space backwards
    
    // Random number generator for throwing yut sticks
    private static final Random random = new Random();
    
    // Private constructor to prevent instantiation
    private YutSet() {
    }
    
    /**
     * Simulates throwing the Yut sticks and returns the result.
     * 
     * @return One of the constants representing the throw result
     */
    public static int throwYut() {
        // Probabilities based on traditional Yut Nori:
        // - BACKDO: ~5%
        // - DO: ~15%
        // - GAE: ~25%
        // - GEOL: ~35%
        // - YUT: ~15%
        // - MO: ~5%
        
        int rand = random.nextInt(100) + 1; // 1-100
        
        if (rand <= 5) {
            return BACKDO;
        } else if (rand <= 20) {
            return DO;
        } else if (rand <= 45) {
            return GAE;
        } else if (rand <= 80) {
            return GEOL;
        } else if (rand <= 95) {
            return YUT;
        } else {
            return MO;
        }
    }
    
    /**
     * Checks if a roll allows the player to throw again.
     * 
     * @param roll The roll result to check
     * @return True if the player can throw again, false otherwise
     */
    public static boolean isRethrowAllowed(int roll) {
        // Only allow re-throw for YUT(4) and MO(5)
        return roll == YUT || roll == MO;
    }
    
    /**
     * Gets the Korean name for a roll result.
     */
    public static String getRollName(int roll) {
        switch (roll) {
            case BACKDO: return "백도";
            case DO: return "도";
            case GAE: return "개";
            case GEOL: return "걸";
            case YUT: return "윷";
            case MO: return "모";
            default: return "알 수 없음";
        }
    }
} 