package com.xingyang.yutnori;

import com.xingyang.yutnori.controller.GameController;
import com.xingyang.yutnori.ui.cli.ConsoleGameUI;
import com.xingyang.yutnori.ui.interfaces.GameUI;
import com.xingyang.yutnori.ui.simple.SimpleGameUI;
import com.xingyang.yutnori.ui.swing.SwingGameUI;
import com.xingyang.yutnori.ui.UISelectionScreen;

import javax.swing.*;
import java.awt.*;
import java.util.Scanner;

/**
 * 游戏主程序类。
 * 允许用户选择不同的UI实现来运行游戏，展示MVC架构的优势。
 */
public class YutNoriGame {
    
    /**
     * 程序入口点
     */
    public static void main(String[] args) {
        try {
            // 设置UI外观为系统默认外观
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception e) {
            // 忽略异常
        }

        // 首先检查环境变量，看是否要直接启动特定UI
        String uiTypeEnv = System.getenv("YUT_NORI_UI_TYPE");
        int uiType = -1;
        
        if (uiTypeEnv != null && !uiTypeEnv.isEmpty()) {
            try {
                uiType = Integer.parseInt(uiTypeEnv);
                if (uiType >= 1 && uiType <= 3) {
                    System.out.println("从环境变量读取UI类型: " + 
                                     (uiType == 1 ? "Swing图形界面" : 
                                      uiType == 2 ? "命令行界面" : "简易图形界面"));
                } else {
                    uiType = -1; // 重置为无效值
                }
            } catch (NumberFormatException e) {
                // 忽略无效的环境变量值
            }
        }
        
        // 如果没有指定环境变量，显示UI选择界面
        if (uiType == -1) {
            try {
                // 显示自定义UI选择界面
                UISelectionScreen selectionScreen = new UISelectionScreen();
                uiType = selectionScreen.waitForSelection();
                
                // 如果用户关闭了窗口，直接退出
                if (uiType == -1) {
                    System.out.println("用户取消选择，程序退出。");
                    System.exit(0);
                    return;
                }
            } catch (Exception e) {
                System.out.println("无法显示UI选择界面: " + e.getMessage());
                System.exit(1);
                return;
            }
        }
        
        // 创建游戏控制器
        GameController controller = new GameController();
        
        // 根据用户选择创建对应的UI
        GameUI gameUI = createUI(uiType);
        
        // 初始化UI
        gameUI.initialize(controller);
        
        // 显示UI
        gameUI.show();
    }
    
    /**
     * 根据用户选择创建相应的UI实现
     * @param uiType UI类型代码
     * @return 创建的GameUI实例
     */
    private static GameUI createUI(int uiType) {
        switch (uiType) {
            case 1:
                System.out.println("启动Swing图形界面...");
                return new SwingGameUI();
            case 2:
                System.out.println("启动命令行界面...");
                return new ConsoleGameUI();
            case 3:
                System.out.println("启动简易图形界面...");
                return new SimpleGameUI();
            default:
                System.out.println("未知界面类型，默认使用Swing图形界面...");
                return new SwingGameUI();
        }
    }
} 