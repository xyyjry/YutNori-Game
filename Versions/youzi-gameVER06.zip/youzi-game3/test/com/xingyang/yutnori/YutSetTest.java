import org.junit.Test;
import static org.junit.Assert.*;

import com.xingyang.yutnori.model.YutSet;

/**
 * 윷놀이 게임의 윷 세트 테스트 클래스
 * 윷 던지기 논리를 테스트합니다
 */
public class YutSetTest {
    
    @Test
    public void testThrowYut() {
        // 윷 던지기 결과가 유효한지 확인
        for (int i = 0; i < 100; i++) {
            int result = YutSet.throwYut();
            assertTrue("윷 던지기 결과는 유효해야 합니다", 
                result == YutSet.BACKDO || 
                result == YutSet.DO || 
                result == YutSet.GAE || 
                result == YutSet.GEOL || 
                result == YutSet.YUT || 
                result == YutSet.MO);
        }
    }
    
    @Test
    public void testIsRethrowAllowed() {
        // 윷과 모에서만 다시 던지기 가능 확인
        assertTrue("윷은 다시 던질 수 있어야 합니다", YutSet.isRethrowAllowed(YutSet.YUT));
        assertTrue("모는 다시 던질 수 있어야 합니다", YutSet.isRethrowAllowed(YutSet.MO));
        
        // 다른 결과에서는 다시 던지기 불가능 확인
        assertFalse("도는 다시 던질 수 없어야 합니다", YutSet.isRethrowAllowed(YutSet.DO));
        assertFalse("개는 다시 던질 수 없어야 합니다", YutSet.isRethrowAllowed(YutSet.GAE));
        assertFalse("걸은 다시 던질 수 없어야 합니다", YutSet.isRethrowAllowed(YutSet.GEOL));
        assertFalse("백도는 다시 던질 수 없어야 합니다", YutSet.isRethrowAllowed(YutSet.BACKDO));
    }
    
    @Test
    public void testGetRollName() {
        // 윷 던지기 결과의 한글 이름 확인
        assertEquals("BACKDO는 '백도'를 반환해야 합니다", "백도", YutSet.getRollName(YutSet.BACKDO));
        assertEquals("DO는 '도'를 반환해야 합니다", "도", YutSet.getRollName(YutSet.DO));
        assertEquals("GAE는 '개'를 반환해야 합니다", "개", YutSet.getRollName(YutSet.GAE));
        assertEquals("GEOL은 '걸'을 반환해야 합니다", "걸", YutSet.getRollName(YutSet.GEOL));
        assertEquals("YUT은 '윷'을 반환해야 합니다", "윷", YutSet.getRollName(YutSet.YUT));
        assertEquals("MO는 '모'를 반환해야 합니다", "모", YutSet.getRollName(YutSet.MO));
    }
} 