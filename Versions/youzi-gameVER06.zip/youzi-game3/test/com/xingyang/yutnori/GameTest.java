import org.junit.Test;
import org.junit.Before;
import static org.junit.Assert.*;

import com.xingyang.yutnori.model.Game;
import com.xingyang.yutnori.model.Player;
import com.xingyang.yutnori.model.Piece;
import com.xingyang.yutnori.model.YutSet;
import com.xingyang.yutnori.model.Board;

import java.awt.Color;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;

/**
 * 윷놀이 게임 컨트롤러 테스트 클래스
 * 게임 제어 논리 및 규칙을 테스트합니다
 */
public class GameTest {
    
    private Game game;
    private List<Player> players;
    private Player player1;
    private Player player2;
    
    @Before
    public void setUp() {
        // 테스트용 게임 설정
        players = new ArrayList<>();
        player1 = new Player("Player 1", Color.RED);
        player2 = new Player("Player 2", Color.BLUE);
        players.add(player1);
        players.add(player2);
        game = new Game(players);
    }
    
    @Test
    public void testGameInitialization() {
        // 게임 초기화 테스트
        assertFalse("게임은 초기에 종료되지 않아야 합니다", game.isGameOver());
        assertNull("초기 상태에서는 승자가 없어야 합니다", game.getWinner());
        assertEquals("플레이어 1이 첫 번째 차례여야 합니다", player1, game.getCurrentPlayer());
        assertFalse("초기 상태에서는 윷을 던지지 않아야 합니다", game.hasRolled());
        assertEquals("사용 가능한 윷 결과가 없어야 합니다", 0, game.getAvailableRolls().size());
    }
    
    @Test
    public void testHandleThrowResult() {
        // 윷 던지기 결과 처리 테스트
        game.handleThrowResult(YutSet.DO);
        assertTrue("윷을 던진 후에는 던졌음을 표시해야 합니다", game.hasRolled());
        assertEquals("현재 윷 결과는 DO여야 합니다", YutSet.DO, game.getCurrentRoll());
        assertEquals("사용 가능한 윷 결과는 1개여야 합니다", 1, game.getAvailableRolls().size());
        assertFalse("DO 결과는 다시 던질 수 없어야 합니다", game.isReThrowAllowed());
        
        // 윷이나 모를 던진 경우 테스트
        game = new Game(players); // 게임 초기화
        game.handleThrowResult(YutSet.YUT);
        assertTrue("윷을 던진 후에는 던졌음을 표시해야 합니다", game.hasRolled());
        assertEquals("현재 윷 결과는 YUT이어야 합니다", YutSet.YUT, game.getCurrentRoll());
        assertTrue("YUT 결과는 다시 던질 수 있어야 합니다", game.isReThrowAllowed());
    }
    
    @Test
    public void testMovePiece() {
        // 말 이동 테스트
        Piece piece = player1.getPiece(0);
        game.handleThrowResult(YutSet.DO);
        
        // 말 이동
        boolean moved = game.movePiece(piece, YutSet.DO);
        assertTrue("말은 이동에 성공해야 합니다", moved);
        assertEquals("말은 위치 1로 이동해야 합니다", 1, piece.getPosition());
        
        // 사용한 윷 결과는 제거되어야 함
        assertEquals("사용한 윷 결과는 제거되어야 합니다", 0, game.getAvailableRolls().size());
    }
    
    @Test
    public void testEndTurn() {
        // 턴 종료 테스트
        assertEquals("초기 플레이어는 플레이어 1이어야 합니다", player1, game.getCurrentPlayer());
        game.endTurn();
        assertEquals("턴을 종료하면 플레이어 2로 변경되어야 합니다", player2, game.getCurrentPlayer());
        game.endTurn();
        assertEquals("다시 턴을 종료하면 플레이어 1로 돌아와야 합니다", player1, game.getCurrentPlayer());
    }
    
    @Test
    public void testSelectRoll() {
        // 윷 결과 선택 테스트
        game.handleThrowResult(YutSet.DO);
        game.handleThrowResult(YutSet.GAE);
        
        assertEquals("현재 윷 결과는 GAE여야 합니다", YutSet.GAE, game.getCurrentRoll());
        
        boolean selected = game.selectRoll(YutSet.DO);
        assertTrue("사용 가능한 윷 결과를 선택할 수 있어야 합니다", selected);
        assertEquals("선택한 윷 결과로 현재 결과가 변경되어야 합니다", YutSet.DO, game.getCurrentRoll());
        
        selected = game.selectRoll(YutSet.GEOL);
        assertFalse("사용할 수 없는 윷 결과는 선택할 수 없어야 합니다", selected);
    }
    
    @Test
    public void testCanMove() {
        // 말의 이동 가능 여부 테스트
        Piece piece = player1.getPiece(0);
        
        // 윷을 던지기 전에는 이동할 수 없음
        assertFalse("윷을 던지기 전에는 이동할 수 없어야 합니다", game.canMove(piece, YutSet.DO));
        
        game.handleThrowResult(YutSet.DO);
        assertTrue("윷을 던진 후에는 자신의 말을 이동할 수 있어야 합니다", game.canMove(piece, YutSet.DO));
        
        // 다른 플레이어의 말은 이동할 수 없음
        Piece opponentPiece = player2.getPiece(0);
        assertFalse("상대방의 말은 이동할 수 없어야 합니다", game.canMove(opponentPiece, YutSet.DO));
    }
    
    @Test
    public void testDiagonalPathMovement() {
        // 대각선 경로 이동 테스트를 위한 설정
        Piece piece = player1.getPiece(0);
        
        // 말을 위치 5로 이동
        piece.setPosition(5);
        
        // 대각선 경로로 이동
        game.handleThrowResult(YutSet.DO);
        boolean moved = game.movePiece(piece, YutSet.DO, Board.PathType.DIAGONAL_RIGHT);
        
        assertTrue("대각선 경로로 이동에 성공해야 합니다", moved);
        assertEquals("위치 5에서 대각선 경로로 1칸 이동하면 위치 21에 도착해야 합니다", 21, piece.getPosition());
    }
    
    @Test
    public void testGameOver() {
        // 게임 종료 테스트
        // 플레이어 1의 모든 말을 완주 지점으로 이동
        for (Piece piece : player1.getPieces()) {
            piece.setPosition(30);
            piece.setCompleted(true);  // 명시적으로 말의 완료 상태 설정
        }
        
        // 반사적으로 checkForWinner 메소드 호출
        try {
            Method checkForWinnerMethod = Game.class.getDeclaredMethod("checkForWinner");
            checkForWinnerMethod.setAccessible(true);
            checkForWinnerMethod.invoke(game);
        } catch (Exception e) {
            fail("checkForWinner 메소드 호출에 실패했습니다: " + e.getMessage());
        }
        
        assertTrue("모든 말이 완주하면 게임이 종료되어야 합니다", game.isGameOver());
        assertEquals("승자는 플레이어 1이어야 합니다", player1, game.getWinner());
    }
} 