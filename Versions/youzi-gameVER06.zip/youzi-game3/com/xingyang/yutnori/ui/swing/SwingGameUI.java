package com.xingyang.yutnori.ui.swing;

import com.xingyang.yutnori.controller.GameController;
import com.xingyang.yutnori.controller.GameStateListener;
import com.xingyang.yutnori.model.Piece;
import com.xingyang.yutnori.model.Player;
import com.xingyang.yutnori.ui.GameBoard;
import com.xingyang.yutnori.ui.YutStickPanel;
import com.xingyang.yutnori.ui.interfaces.GameUI;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.border.EmptyBorder;

/**
 * 基于Swing的游戏UI实现。
 * 这个类实现了GameUI接口，并使用Swing组件构建用户界面。
 */
public class SwingGameUI implements GameUI, GameStateListener {
    // 控制器
    private GameController controller;
    
    // Swing组件
    private JFrame mainFrame;
    private GameBoard gameBoard;
    private YutStickPanel yutStickPanel;
    private JButton newGameButton;
    private JButton endTurnButton;
    private JPanel controlPanel;
    private JLabel statusLabel;
    
    /**
     * 构造函数
     */
    public SwingGameUI() {
        // 创建主窗口
        mainFrame = new JFrame("한국 전통 게임 윷놀이 (Yut Nori)");
        mainFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        mainFrame.setMinimumSize(new Dimension(1350, 900));
    }
    
    @Override
    public void initialize(GameController controller) {
        this.controller = controller;
        
        // 注册为游戏状态监听器
        controller.addGameStateListener(this);
        
        // 使用控制器中的游戏实例初始化游戏板
        gameBoard = new GameBoard(controller.getGame());
        
        // 创建组件
        createComponents();
        
        // 布局组件
        layoutComponents();
        
        // 设置事件监听器
        setupEventListeners();
    }
    
    @Override
    public void show() {
        // 显示窗口
        mainFrame.setSize(1450, 950);
        mainFrame.setLocationRelativeTo(null);
        mainFrame.setVisible(true);
    }
    
    @Override
    public void close() {
        mainFrame.dispose();
    }
    
    @Override
    public void updateGameState() {
        // 更新整个游戏状态
        Player currentPlayer = controller.getGame().getCurrentPlayer();
        statusLabel.setText("현재 플레이어: " + currentPlayer.getName());
        
        // 更新按钮状态
        updateButtonStates();
        
        // 重绘游戏板
        gameBoard.repaint();
    }
    
    @Override
    public void updateCurrentPlayer(Player currentPlayer) {
        statusLabel.setText("현재 플레이어: " + currentPlayer.getName());
        updateButtonStates();
    }
    
    @Override
    public void updateYutResult(int result) {
        // 通过YutStickPanel更新掷棒结果
        yutStickPanel.setLastResult(result);
        yutStickPanel.repaint();
        
        // 更新按钮状态
        updateButtonStates();
    }
    
    @Override
    public void updatePiecePosition(Piece piece) {
        // 重绘游戏板以显示更新的棋子位置
        gameBoard.repaint();
    }
    
    @Override
    public void showGameOver(Player winner) {
        // 创建自定义对话框，而不是使用标准的JOptionPane
        JDialog gameOverDialog = new JDialog(mainFrame, "게임 종료!", true);
        gameOverDialog.setSize(400, 300);
        gameOverDialog.setLocationRelativeTo(mainFrame);
        gameOverDialog.setResizable(false);
        
        // 创建面板
        JPanel panel = new JPanel(new BorderLayout(10, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        panel.setBackground(new Color(250, 245, 220));
        
        // 标题标签
        JLabel titleLabel = new JLabel("게임 종료!", JLabel.CENTER);
        titleLabel.setFont(new Font("Malgun Gothic", Font.BOLD, 28));
        titleLabel.setForeground(new Color(139, 69, 19));
        panel.add(titleLabel, BorderLayout.NORTH);
        
        // 胜利信息
        JLabel winnerLabel = new JLabel(winner.getName() + " 승리했습니다!", JLabel.CENTER);
        winnerLabel.setFont(new Font("Malgun Gothic", Font.BOLD, 24));
        winnerLabel.setForeground(winner.getColor());
        panel.add(winnerLabel, BorderLayout.CENTER);
        
        // 按钮面板
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 10));
        buttonPanel.setOpaque(false);
        
        // 新游戏按钮
        JButton newGameButton = createStyledButton("새 게임 (New Game)", new Color(100, 180, 100));
        newGameButton.addActionListener(e -> {
            // 重置游戏
            controller.resetGame();
            // 关闭对话框
            gameOverDialog.dispose();
        });
        
        // 退出按钮
        JButton exitButton = createStyledButton("종료 (退出)", new Color(180, 100, 100));
        exitButton.addActionListener(e -> {
            // 关闭对话框
            gameOverDialog.dispose();
            // 关闭游戏
            System.exit(0);
        });
        
        buttonPanel.add(newGameButton);
        buttonPanel.add(exitButton);
        panel.add(buttonPanel, BorderLayout.SOUTH);
        
        gameOverDialog.add(panel);
        gameOverDialog.setVisible(true);
    }
    
    @Override
    public void resetUI() {
        // 重置UI组件到初始状态
        yutStickPanel.reset();
        statusLabel.setText("현재 플레이어: " + controller.getGame().getCurrentPlayer().getName());
        endTurnButton.setEnabled(false);
        gameBoard.repaint();
    }
    
    // GameStateListener接口实现
    
    @Override
    public void onGameReset() {
        resetUI();
    }
    
    @Override
    public void onYutThrown(int result) {
        updateYutResult(result);
    }
    
    @Override
    public void onRollSelected(int roll) {
        // 更新按钮状态
        updateButtonStates();
    }
    
    @Override
    public void onPieceMoved(Piece piece) {
        updatePiecePosition(piece);
        
        // 检查游戏是否结束
        if (controller.getGame().isGameOver()) {
            showGameOver(controller.getGame().getWinner());
        }
    }
    
    @Override
    public void onTurnEnded() {
        updateCurrentPlayer(controller.getGame().getCurrentPlayer());
    }
    
    @Override
    public void onGameOver(Player winner) {
        showGameOver(winner);
    }
    
    /**
     * 创建UI组件
     */
    private void createComponents() {
        // 创建掷棒面板
        yutStickPanel = new YutStickPanel(gameBoard);
        
        // 创建控制按钮
        newGameButton = createStyledButton("새 게임 (New Game)", new Color(100, 180, 100));
        endTurnButton = createStyledButton("턴 끝내기 (End Turn)", new Color(180, 100, 100));
        endTurnButton.setEnabled(false);
        
        // 创建状态标签
        statusLabel = new JLabel("현재 플레이어: " + controller.getGame().getCurrentPlayer().getName());
        statusLabel.setFont(new Font("SansSerif", Font.BOLD, 16));
        
        // 创建控制面板
        controlPanel = new JPanel();
        controlPanel.setLayout(new GridLayout(0, 1, 10, 10));
        controlPanel.setBorder(new EmptyBorder(15, 15, 15, 15));
        controlPanel.setBackground(new Color(245, 240, 220));
    }
    
    /**
     * 布局UI组件
     */
    private void layoutComponents() {
        // 设置主窗口布局
        mainFrame.setLayout(new BorderLayout());
        
        // 创建页眉面板
        JPanel headerPanel = createHeaderPanel();
        mainFrame.add(headerPanel, BorderLayout.NORTH);
        
        // 创建主内容面板
        JPanel mainPanel = new JPanel(new BorderLayout(20, 0));
        mainPanel.setBackground(new Color(245, 235, 215));
        mainPanel.setBorder(BorderFactory.createEmptyBorder(5, 10, 5, 10));
        
        // 创建游戏板包装面板
        JPanel gameBoardWrapper = new JPanel(new GridBagLayout());
        gameBoardWrapper.setBackground(new Color(245, 235, 215));
        
        // 添加游戏板到包装面板
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.fill = GridBagConstraints.NONE;
        gbc.anchor = GridBagConstraints.CENTER;
        gameBoardWrapper.add(gameBoard, gbc);
        
        // 创建右侧控制面板
        JPanel rightPanel = new JPanel();
        rightPanel.setLayout(new BoxLayout(rightPanel, BoxLayout.Y_AXIS));
        rightPanel.setBackground(new Color(245, 240, 220));
        rightPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        rightPanel.setPreferredSize(new Dimension(380, 600));
        
        // 添加掷棒面板到右侧面板
        yutStickPanel.setAlignmentX(Component.CENTER_ALIGNMENT);
        rightPanel.add(yutStickPanel);
        rightPanel.add(Box.createVerticalStrut(20));
        
        // 添加状态标签
        statusLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        rightPanel.add(statusLabel);
        rightPanel.add(Box.createVerticalStrut(20));
        
        // 添加控制按钮到控制面板
        controlPanel.add(newGameButton);
        controlPanel.add(Box.createVerticalStrut(10));
        controlPanel.add(endTurnButton);
        
        // 添加控制面板到右侧面板
        controlPanel.setAlignmentX(Component.CENTER_ALIGNMENT);
        rightPanel.add(controlPanel);
        
        // 添加到主面板
        mainPanel.add(gameBoardWrapper, BorderLayout.CENTER);
        mainPanel.add(rightPanel, BorderLayout.EAST);
        
        // 添加主面板到主窗口
        mainFrame.add(mainPanel, BorderLayout.CENTER);
        
        // 添加页脚
        JPanel footerPanel = createFooterPanel();
        mainFrame.add(footerPanel, BorderLayout.SOUTH);
    }
    
    /**
     * 设置事件监听器
     */
    private void setupEventListeners() {
        // 新游戏按钮事件
        newGameButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                controller.resetGame();
            }
        });
        
        // 结束回合按钮事件
        endTurnButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                controller.endTurn();
            }
        });
        
        // 掷棒面板事件
        yutStickPanel.addYutThrowListener(new YutStickPanel.YutThrowListener() {
            @Override
            public void onYutThrown(int result) {
                controller.handleThrowResult(result);
            }
        });
        
        // Add listener to the game board for additional debugging
        gameBoard.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                // Let the game board handle the clicks, we just add logging
                System.out.println("Mouse clicked on game board at: " + e.getX() + ", " + e.getY());
            }
        });
    }
    
    /**
     * 创建页眉面板
     */
    private JPanel createHeaderPanel() {
        JPanel headerPanel = new JPanel();
        headerPanel.setBackground(new Color(235, 225, 205));
        headerPanel.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(255, 0, 0), 2),
            BorderFactory.createEmptyBorder(10, 10, 10, 10)
        ));
        
        JLabel titleLabel = new JLabel("윷을 던져주세요 (Please Throw Yut Sticks)");
        titleLabel.setFont(new Font("Malgun Gothic", Font.BOLD, 24));
        headerPanel.add(titleLabel);
        
        return headerPanel;
    }
    
    /**
     * 创建页脚面板
     */
    private JPanel createFooterPanel() {
        JPanel footerPanel = new JPanel();
        footerPanel.setBackground(new Color(235, 225, 205));
        footerPanel.setBorder(BorderFactory.createEmptyBorder(8, 8, 8, 8));
        
        JLabel copyrightLabel = new JLabel("© " + java.time.Year.now().getValue() + " Xingyang. MVC架构实现");
        copyrightLabel.setFont(new Font("SansSerif", Font.PLAIN, 12));
        footerPanel.add(copyrightLabel);
        return footerPanel;
    }
    
    /**
     * 创建样式化按钮
     */
    private JButton createStyledButton(String text, Color color) {
        JButton button = new JButton(text);
        button.setFont(new Font("SansSerif", Font.BOLD, 16));
        button.setBackground(color);
        button.setForeground(Color.WHITE);
        button.setFocusPainted(false);
        button.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(Color.DARK_GRAY, 1),
            BorderFactory.createEmptyBorder(10, 10, 10, 10)
        ));
        
        // 添加悬停效果
        button.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                button.setBackground(color.brighter());
            }
            
            @Override
            public void mouseExited(MouseEvent e) {
                button.setBackground(color);
            }
        });
        
        return button;
    }
    
    /**
     * 更新按钮状态
     */
    private void updateButtonStates() {
        boolean hasRolled = controller.getGame().hasRolled();
        boolean hasAvailableRolls = !controller.getGame().getAvailableRolls().isEmpty();
        
        endTurnButton.setEnabled(hasRolled);
        
        // 可以在这里添加更多按钮状态逻辑
    }
} 