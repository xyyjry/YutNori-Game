package com.xingyang.yutnori.ui.cli;

import com.xingyang.yutnori.controller.GameController;
import com.xingyang.yutnori.controller.GameStateListener;
import com.xingyang.yutnori.model.Board;
import com.xingyang.yutnori.model.Piece;
import com.xingyang.yutnori.model.Player;
import com.xingyang.yutnori.model.YutSet;
import com.xingyang.yutnori.ui.interfaces.GameUI;

import java.util.List;
import java.util.Scanner;

/**
 * 基于命令行的游戏UI实现。
 * 这个类实现了GameUI接口，提供了一个文本界面的游戏交互方式。
 * 这是第二种UI实现，证明了模型和控制器的可重用性。
 */
public class ConsoleGameUI implements GameUI, GameStateListener {
    // 控制器
    private GameController controller;
    
    // 用于控制台输入
    private Scanner scanner;
    
    // 控制游戏循环
    private boolean running;
    
    /**
     * 构造函数
     */
    public ConsoleGameUI() {
        scanner = new Scanner(System.in);
        running = false;
    }
    
    @Override
    public void initialize(GameController controller) {
        this.controller = controller;
        
        // 注册为游戏状态监听器
        controller.addGameStateListener(this);
    }
    
    @Override
    public void show() {
        // 显示欢迎信息
        System.out.println("===============================================");
        System.out.println("   한국 전통 윷놀이 (Korean Yut Nori Game)");
        System.out.println("   命令行界面版本");
        System.out.println("===============================================");
        
        // 显示初始游戏状态
        updateGameState();
        
        // 启动游戏循环
        running = true;
        gameLoop();
    }
    
    @Override
    public void close() {
        running = false;
        if (scanner != null) {
            scanner.close();
        }
        System.out.println("游戏已关闭。再见！");
    }
    
    /**
     * 游戏主循环
     */
    private void gameLoop() {
        while (running) {
            // 显示菜单
            displayMenu();
            
            // 获取用户输入
            String input = scanner.nextLine().trim();
            
            // 处理输入
            processCommand(input);
            
            // 检查游戏是否结束
            if (controller.getGame().isGameOver()) {
                showGameOver(controller.getGame().getWinner());
                running = false;
            }
        }
    }
    
    /**
     * 显示命令菜单
     */
    private void displayMenu() {
        System.out.println("\n--- 可用命令 ---");
        System.out.println("1. throw - 掷棒");
        System.out.println("2. move <棋子ID> <步数> - 移动棋子");
        System.out.println("3. end - 结束当前回合");
        System.out.println("4. status - 显示游戏状态");
        System.out.println("5. reset - 重置游戏");
        System.out.println("6. exit - 退出游戏");
        System.out.print("> ");
    }
    
    /**
     * 处理用户命令
     */
    private void processCommand(String command) {
        String[] parts = command.split("\\s+");
        String action = parts[0].toLowerCase();
        
        switch (action) {
            case "throw":
                handleThrowCommand();
                break;
            case "move":
                if (parts.length >= 3) {
                    try {
                        int pieceId = Integer.parseInt(parts[1]);
                        int roll = Integer.parseInt(parts[2]);
                        handleMoveCommand(pieceId, roll);
                    } catch (NumberFormatException e) {
                        System.out.println("错误：棋子ID和步数必须是数字");
                    }
                } else {
                    System.out.println("错误：移动命令格式应为 'move <棋子ID> <步数>'");
                }
                break;
            case "end":
                controller.endTurn();
                break;
            case "status":
                displayGameStatus();
                break;
            case "reset":
                controller.resetGame();
                break;
            case "exit":
                running = false;
                break;
            default:
                System.out.println("未知命令: " + action);
                break;
        }
    }
    
    /**
     * 处理掷棒命令
     */
    private void handleThrowCommand() {
        if (controller.getGame().hasRolled()) {
            System.out.println("你已经掷过棒了。请移动棋子或结束回合。");
            return;
        }
        
        // 模拟掷棒
        int result = YutSet.throwYut();
        controller.handleThrowResult(result);
    }
    
    /**
     * 处理移动棋子命令
     */
    private void handleMoveCommand(int pieceId, int roll) {
        if (!controller.getGame().hasRolled()) {
            System.out.println("请先掷棒。");
            return;
        }
        
        List<Integer> availableRolls = controller.getGame().getAvailableRolls();
        if (!availableRolls.contains(roll)) {
            System.out.println("错误：没有可用的 " + roll + " 步数。可用步数: " + availableRolls);
            return;
        }
        
        Player currentPlayer = controller.getGame().getCurrentPlayer();
        List<Piece> pieces = currentPlayer.getPieces();
        
        if (pieceId < 0 || pieceId >= pieces.size()) {
            System.out.println("错误：无效的棋子ID。有效范围: 0-" + (pieces.size() - 1));
            return;
        }
        
        Piece piece = pieces.get(pieceId);
        boolean success = controller.movePiece(piece, roll);
        
        if (!success) {
            System.out.println("无法移动棋子。请检查移动是否有效。");
        }
    }
    
    /**
     * 显示详细的游戏状态
     */
    private void displayGameStatus() {
        System.out.println("\n=== 游戏状态 ===");
        
        // 显示当前玩家
        Player currentPlayer = controller.getGame().getCurrentPlayer();
        System.out.println("当前玩家: " + currentPlayer.getName());
        
        // 显示可用的掷棒结果
        List<Integer> availableRolls = controller.getGame().getAvailableRolls();
        System.out.println("可用步数: " + availableRolls);
        
        // 显示棋子位置
        List<Player> players = controller.getGame().getPlayers();
        for (Player player : players) {
            System.out.println("\n" + player.getName() + " 的棋子:");
            List<Piece> pieces = player.getPieces();
            for (int i = 0; i < pieces.size(); i++) {
                Piece piece = pieces.get(i);
                String position = piece.getPosition() == -1 ? "起点" : String.valueOf(piece.getPosition());
                String status = piece.isHome() ? "在家" : (piece.isComplete() ? "已完成" : "在棋盘上");
                System.out.println("  棋子 " + i + ": 位置=" + position + ", 状态=" + status);
            }
        }
        
        System.out.println("=================");
    }
    
    @Override
    public void updateGameState() {
        // 显示基本游戏状态
        Player currentPlayer = controller.getGame().getCurrentPlayer();
        System.out.println("\n当前回合: " + currentPlayer.getName());
    }
    
    @Override
    public void updateCurrentPlayer(Player currentPlayer) {
        System.out.println("\n--- 回合切换 ---");
        System.out.println("当前玩家: " + currentPlayer.getName());
    }
    
    @Override
    public void updateYutResult(int result) {
        System.out.println("\n掷棒结果: " + result + " (" + YutSet.getRollName(result) + ")");
    }
    
    @Override
    public void updatePiecePosition(Piece piece) {
        String position = piece.getPosition() == -1 ? "起点" : String.valueOf(piece.getPosition());
        String status = piece.isHome() ? "在家" : (piece.isComplete() ? "已完成" : "在棋盘上");
        System.out.println("棋子移动: 所有者=" + piece.getOwner().getName() + 
                         ", 位置=" + position + 
                         ", 状态=" + status);
    }
    
    @Override
    public void showGameOver(Player winner) {
        System.out.println("\n============================");
        System.out.println("    游戏结束! 获胜者: " + winner.getName());
        System.out.println("============================");
    }
    
    @Override
    public void resetUI() {
        System.out.println("\n游戏已重置!");
        updateGameState();
    }
    
    // GameStateListener接口实现
    
    @Override
    public void onGameReset() {
        resetUI();
    }
    
    @Override
    public void onYutThrown(int result) {
        updateYutResult(result);
    }
    
    @Override
    public void onRollSelected(int roll) {
        System.out.println("选择了掷棒结果: " + roll);
    }
    
    @Override
    public void onPieceMoved(Piece piece) {
        updatePiecePosition(piece);
    }
    
    @Override
    public void onTurnEnded() {
        System.out.println("回合结束");
        updateCurrentPlayer(controller.getGame().getCurrentPlayer());
    }
    
    @Override
    public void onGameOver(Player winner) {
        showGameOver(winner);
    }
} 