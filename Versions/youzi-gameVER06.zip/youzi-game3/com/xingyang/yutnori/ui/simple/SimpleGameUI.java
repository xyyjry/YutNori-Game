package com.xingyang.yutnori.ui.simple;

import com.xingyang.yutnori.controller.GameController;
import com.xingyang.yutnori.controller.GameStateListener;
import com.xingyang.yutnori.model.Board;
import com.xingyang.yutnori.model.Game;
import com.xingyang.yutnori.model.Piece;
import com.xingyang.yutnori.model.Player;
import com.xingyang.yutnori.model.YutSet;
import com.xingyang.yutnori.ui.interfaces.GameUI;
import com.xingyang.yutnori.ui.GameBoard;

import javax.swing.*;
import javax.swing.border.Border;
import javax.swing.border.TitledBorder;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.awt.geom.RoundRectangle2D;
import java.awt.geom.AffineTransform;

/**
 * 简单的游戏UI实现。
 * 这个类提供了一个极简的游戏界面，但仍然使用MVC架构。
 */
public class SimpleGameUI implements GameUI, GameStateListener {
    // 控制器
    private GameController controller;
    
    // Swing组件
    private JFrame mainFrame;
    private JPanel gamePanel;
    private JPanel playerPanel;
    private SimpleBoardPanel boardPanel;  // 使用自定义的SimpleBoardPanel而不是GameBoard
    private JButton throwButton;
    private JButton endTurnButton;
    private JLabel resultLabel;
    private JLabel statusLabel;
    
    // 玩家棋子按钮
    private JButton[][] pieceButtons;
    
    // 动画和游戏化元素
    private Timer pulseTimer;
    private int pulseCounter = 0;
    private JLabel turnIndicator;
    private JProgressBar gameProgressBar;
    
    // 游戏主题颜色 - 韩国传统配色
    private final Color BACKGROUND_COLOR = new Color(245, 245, 240);  // 淡米色背景
    private final Color PANEL_COLOR = new Color(235, 235, 230);       // 更淡的米色面板
    private final Color HEADER_COLOR = new Color(0, 114, 114);        // 韩国传统青绿色
    private final Color ACCENT_COLOR = new Color(38, 70, 83);         // 深蓝色强调色
    private final Color BUTTON_COLOR = new Color(231, 111, 81);       // 橙红色按钮
    private final Color BUTTON_TEXT_COLOR = new Color(255, 255, 255); // 白色文本
    private final Color PLAYER1_COLOR = new Color(42, 157, 143);      // 玩家1颜色（青绿）
    private final Color PLAYER2_COLOR = new Color(231, 111, 81);      // 玩家2颜色（橙红）
    
    // 添加游戏引导提示和闪烁效果
    private Timer buttonHighlightTimer;
    private boolean isButtonHighlighted = false;
    private JPanel startHintPanel;
    private boolean hasShownTutorial = false;
    
    // 添加全局调试标志
    private static final boolean DEBUG = false;
    
    /**
     * 构造函数
     */
    public SimpleGameUI() {
        mainFrame = new JFrame("윷놀이 (Yut Nori)");
        // 设置关闭动作为退出程序
        mainFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        mainFrame.setSize(1300, 800); // 增加窗口宽度
        mainFrame.setResizable(true);
        mainFrame.setMinimumSize(new Dimension(1200, 750)); // 增加最小宽度
        
        // 添加窗口关闭监听器，确保程序真正退出
        mainFrame.addWindowListener(new java.awt.event.WindowAdapter() {
            @Override
            public void windowClosing(java.awt.event.WindowEvent windowEvent) {
                // 强制完全退出程序
                System.exit(0);
            }
        });
        
        // 设置脉冲动画计时器
        pulseTimer = new Timer(50, e -> {
            pulseCounter++;
            if (pulseCounter > 1000) pulseCounter = 0;
            if (turnIndicator != null) turnIndicator.repaint();
        });
        pulseTimer.start();
    }
    
    @Override
    public void initialize(GameController controller) {
        this.controller = controller;
        controller.addGameStateListener(this);
        
        createComponents();
        layoutComponents();
        setupEventListeners();
        
        // 确保窗口居中显示
        mainFrame.setLocationRelativeTo(null);
        
        // 添加初始游戏引导
        initializeGameTutorial();
        
        // 确保只有点击掷骰子按钮才能掷骰子
        boardPanel.setFocusable(false); // 让棋盘区域不获取焦点
    }
    
    /**
     * 创建UI组件
     */
    private void createComponents() {
        // 使用主题背景
        gamePanel = new BackgroundPanel();
        gamePanel.setLayout(new BorderLayout(10, 10));
        gamePanel.setBackground(BACKGROUND_COLOR);
        
        // 创建棋盘面板 - 使用自定义的SimpleBoardPanel而不是GameBoard
        boardPanel = new SimpleBoardPanel(controller.getGame());
        boardPanel.setPreferredSize(new Dimension(700, 600));
        
        // 创建玩家面板 - 使用主题边框和布局
        playerPanel = new JPanel();
        playerPanel.setLayout(new BoxLayout(playerPanel, BoxLayout.Y_AXIS)); // 垂直布局
        playerPanel.setBackground(PANEL_COLOR);
        playerPanel.setBorder(createFancyBorder("플레이어 말", ACCENT_COLOR));
        playerPanel.setPreferredSize(new Dimension(250, 400)); // 调整尺寸
        
        // 创建棋子按钮
        List<Player> players = controller.getGame().getPlayers();
        pieceButtons = new JButton[players.size()][4]; // 每个玩家4个棋子
        
        // 使用自定义玩家颜色
        Color[] playerColors = {
            PLAYER1_COLOR,  // 青绿色 (玩家1)
            PLAYER2_COLOR   // 橙红色 (玩家2)
        };
        
        // 为每个玩家创建面板和按钮
        for (int i = 0; i < players.size(); i++) {
            Player player = players.get(i);
            JPanel playerPiecePanel = new JPanel();
            playerPiecePanel.setLayout(new GridLayout(2, 2, 10, 10));
            playerPiecePanel.setBackground(PANEL_COLOR);
            
            // 创建玩家标题栏
            String title = player.getName();
            Border playerBorder = createPlayerBorder(title, playerColors[i]);
            playerPiecePanel.setBorder(playerBorder);
            
            for (int j = 0; j < 4; j++) {
                pieceButtons[i][j] = createStyledButton("말 " + (j + 1), playerColors[i]);
                
                final int playerIndex = i;
                final int pieceIndex = j;
                
                pieceButtons[i][j].addActionListener(e -> {
                    if (controller.getGame().getCurrentPlayer() == player &&
                        controller.getGame().hasRolled() &&
                        !controller.getGame().getAvailableRolls().isEmpty()) {
                        
                        Piece piece = player.getPieces().get(pieceIndex);
                        
                        // 获取当前可用的所有掷棒结果
                        List<Integer> availableRolls = controller.getGame().getAvailableRolls();
                        int roll = availableRolls.get(0); // 默认使用第一个结果
                        
                        // 如果有多个结果，弹出选择对话框
                        if (availableRolls.size() > 1) {
                            roll = showRollSelectionDialog(availableRolls);
                            if (roll == -1) return; // 用户取消选择
                        }
                        
                        // 检查是否有可能的路径选择（如果棋子在特殊位置）
                        if (piece.getPosition() == 5 || piece.getPosition() == 10 || piece.getPosition() == 15) {
                            Board.PathType pathType = showPathSelectionDialog();
                            if (pathType != null) {
                                if (controller.movePiece(piece, roll, pathType)) {
                                    updatePieceButtons();
                                    boardPanel.repaint();
                                    playMoveSound();
                                    
                                    // 检查是否应该自动结束回合
                                    if (controller.getGame().getAvailableRolls().isEmpty() && !controller.getGame().isReThrowAllowed()) {
                                        handleEndTurn();
                                    }
                                } else {
                                    showErrorMessage("윷을 움직일 수 없습니다!");
                                }
                            }
                        } else {
                            // 普通移动
                            if (controller.movePiece(piece, roll)) {
                                updatePieceButtons();
                                boardPanel.repaint();
                                playMoveSound();
                                
                                // 检查是否应该自动结束回合
                                if (controller.getGame().getAvailableRolls().isEmpty() && !controller.getGame().isReThrowAllowed()) {
                                    handleEndTurn();
                                }
                            } else {
                                showErrorMessage("윷을 움직일 수 없습니다!");
                            }
                        }
                    }
                });
                
                playerPiecePanel.add(pieceButtons[i][j]);
            }
            
            playerPanel.add(playerPiecePanel);
            
            // 添加空白间隔
            if (i < players.size() - 1) {
                playerPanel.add(Box.createRigidArea(new Dimension(0, 20)));
            }
        }
        
        // 创建掷骰子按钮 - 更醒目的样式
        throwButton = createGameButton("윷 던지기", BUTTON_COLOR, 50);
        
        // 创建结束回合按钮
        endTurnButton = createGameButton("턴 종료 (End Turn)", new Color(100, 100, 100), 50);
        endTurnButton.setEnabled(false);
        
        // 创建游戏状态标签 - 更美观的样式
        resultLabel = new JLabel("게임을 시작합니다", JLabel.CENTER);
        resultLabel.setFont(new Font("Malgun Gothic", Font.BOLD, 16));
        resultLabel.setForeground(ACCENT_COLOR);
        resultLabel.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(HEADER_COLOR, 1, true),
            BorderFactory.createEmptyBorder(10, 15, 10, 15)
        ));
        resultLabel.setOpaque(true);
        resultLabel.setBackground(new Color(245, 245, 240));
        
        // 创建当前玩家显示
        statusLabel = new JLabel("현재 플레이어: " + controller.getGame().getCurrentPlayer().getName(), JLabel.CENTER);
        statusLabel.setFont(new Font("Malgun Gothic", Font.BOLD, 16));
        statusLabel.setForeground(Color.WHITE);
        statusLabel.setBorder(BorderFactory.createEmptyBorder(8, 15, 8, 15));
        statusLabel.setOpaque(true);
        statusLabel.setBackground(controller.getGame().getCurrentPlayer().getColor());
        
        // 创建回合指示器
        turnIndicator = new PulsingLabel("현재 턴", controller.getGame().getCurrentPlayer().getColor());
        
        // 创建游戏进度条
        gameProgressBar = new JProgressBar(0, 100);
        gameProgressBar.setValue(0);
        gameProgressBar.setStringPainted(true);
        gameProgressBar.setString("게임 진행도");
        gameProgressBar.setForeground(ACCENT_COLOR);
        gameProgressBar.setFont(new Font("Malgun Gothic", Font.BOLD, 12));
        gameProgressBar.setBorder(BorderFactory.createEmptyBorder(5, 0, 5, 0));
        
        // 设置棋盘防止点击事件影响掷骰子
        setupBoardPanel();
    }
    
    /**
     * 创建带样式的游戏按钮
     */
    private JButton createGameButton(String text, Color color, int height) {
        JButton button = new JButton(text);
        button.setFont(new Font("Malgun Gothic", Font.BOLD, 16));
        button.setBackground(color);
        button.setForeground(BUTTON_TEXT_COLOR);
        button.setFocusPainted(false);
        button.setBorderPainted(true);
        button.setPreferredSize(new Dimension(160, height));
        
        // 创建圆角边框
        button.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(color.darker(), 1),
            BorderFactory.createEmptyBorder(8, 15, 8, 15)
        ));
        
        return button;
    }
    
    /**
     * 创建美化的棋子按钮
     */
    private JButton createStyledButton(String text, Color color) {
        JButton button = new JButton(text);
        button.setFont(new Font("Malgun Gothic", Font.BOLD, 14));
        button.setBackground(color);
        button.setForeground(Color.WHITE);
        button.setFocusPainted(false);
        
        // 创建内阴影效果的边框
        button.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(color.darker().darker(), 1),
            BorderFactory.createEmptyBorder(8, 8, 8, 8)
        ));
        
        return button;
    }
    
    /**
     * 创建玩家面板边框
     */
    private Border createPlayerBorder(String title, Color color) {
        TitledBorder titledBorder = BorderFactory.createTitledBorder(
            BorderFactory.createLineBorder(color, 3),
            title
        );
        titledBorder.setTitleFont(new Font("Malgun Gothic", Font.BOLD, 16));
        titledBorder.setTitleColor(color);
        titledBorder.setTitlePosition(TitledBorder.ABOVE_TOP);
        titledBorder.setTitleJustification(TitledBorder.CENTER);
        
        return BorderFactory.createCompoundBorder(
            titledBorder,
            BorderFactory.createEmptyBorder(15, 10, 10, 10)
        );
    }
    
    /**
     * 创建装饰性边框
     */
    private Border createFancyBorder(String title, Color color) {
        TitledBorder titledBorder = BorderFactory.createTitledBorder(
            BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(color, 1),
                BorderFactory.createLineBorder(color.brighter(), 1)
            ),
            title
        );
        titledBorder.setTitleFont(new Font("Malgun Gothic", Font.BOLD, 16));
        titledBorder.setTitleColor(color);
        
        return BorderFactory.createCompoundBorder(
            titledBorder,
            BorderFactory.createEmptyBorder(10, 10, 10, 10)
        );
    }
    
    /**
     * 显示路径选择对话框
     */
    private Board.PathType showPathSelectionDialog() {
        // 获取当前棋子及其位置信息
        Piece selectedPiece = null;
        Player currentPlayer = controller.getGame().getCurrentPlayer();
        
        // 尝试找到当前选中的棋子
        for (Piece piece : currentPlayer.getPieces()) {
            if (controller.getGame().getBoard().isJunction(piece.getPosition())) {
                selectedPiece = piece;
                break;
            }
        }
        
        // 如果没找到在路口位置的棋子，返回默认路径
        if (selectedPiece == null) {
            System.out.println("没有找到在路口位置的棋子，使用默认路径");
            return Board.PathType.MAIN_PATH;
        }
        
        int position = selectedPiece.getPosition();
        
        // 使用Board.getAvailablePaths获取可用路径选项
        Map<Board.PathType, Integer> availablePaths = 
            controller.getGame().getBoard().getAvailablePaths(position);
            
        if (availablePaths.isEmpty() || availablePaths.size() == 1) {
            // 如果没有选择或只有一个选择，直接返回
            return availablePaths.isEmpty() ? 
                Board.PathType.MAIN_PATH : availablePaths.keySet().iterator().next();
        }
        
        // 创建自定义对话框，样式更加美观
        JDialog dialog = new JDialog(mainFrame, "경로 선택 (Path Selection)", true);
        dialog.setLayout(new BorderLayout());
        dialog.setSize(350, 250);
        dialog.setLocationRelativeTo(mainFrame);
        
        // 对话框内容面板
        JPanel contentPanel = new JPanel(new BorderLayout(10, 15));
        contentPanel.setBackground(PANEL_COLOR);
        contentPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        
        // 添加标题
        JLabel titleLabel = new JLabel("이동 경로를 선택하세요 (Choose Path)", JLabel.CENTER);
        titleLabel.setFont(new Font("Malgun Gothic", Font.BOLD, 18));
        titleLabel.setForeground(ACCENT_COLOR);
        contentPanel.add(titleLabel, BorderLayout.NORTH);
        
        // 创建按钮面板 - 根据可用路径数量动态创建
        JPanel buttonPanel = new JPanel(new GridLayout(availablePaths.size(), 1, 0, 15));
        buttonPanel.setOpaque(false);
        
        final Board.PathType[] result = new Board.PathType[1];
        
        // 为每个可用路径创建按钮
        for (Map.Entry<Board.PathType, Integer> entry : availablePaths.entrySet()) {
            Board.PathType pathType = entry.getKey();
            Integer nextPosition = entry.getValue();
            
            // 根据路径类型设置不同颜色和名称
            Color buttonColor;
            String pathName;
            
            switch (pathType) {
                case MAIN_PATH:
                    buttonColor = new Color(139, 69, 19);  // 棕色
                    pathName = "메인 경로 (Main Path)";
                    break;
                case DIAGONAL_LEFT:
                    buttonColor = new Color(0, 100, 200);  // 蓝色
                    pathName = "왼쪽 대각선 (Left Diagonal)";
                    break;
                case DIAGONAL_RIGHT:
                    buttonColor = new Color(200, 0, 0);    // 红色
                    pathName = "오른쪽 대각선 (Right Diagonal)";
                    break;
                case CENTER_PATH:
                    buttonColor = new Color(100, 100, 200); // 蓝紫色
                    pathName = "중앙 경로 (Center Path)";
                    break;
                default:
                    buttonColor = new Color(100, 100, 100); // 灰色
                    pathName = "기타 경로 (Other Path)";
            }
            
            // 创建带有路径信息和目标位置的按钮
            JButton pathButton = createGameButton(pathName + " → " + nextPosition, buttonColor, 40);
            pathButton.addActionListener(e -> {
                result[0] = pathType;
                dialog.dispose();
            });
            
            buttonPanel.add(pathButton);
        }
        
        contentPanel.add(buttonPanel, BorderLayout.CENTER);
        dialog.add(contentPanel);
        
        dialog.setVisible(true);
        return result[0];
    }
    
    /**
     * 显示骰子结果选择对话框
     */
    private int showRollSelectionDialog(List<Integer> availableRolls) {
        // 创建自定义对话框，样式更加美观
        JDialog dialog = new JDialog(mainFrame, "윷 결과 선택", true);
        dialog.setLayout(new BorderLayout());
        dialog.setSize(350, 300);
        dialog.setLocationRelativeTo(mainFrame);
        
        // 对话框内容面板
        JPanel contentPanel = new JPanel(new BorderLayout(10, 15));
        contentPanel.setBackground(PANEL_COLOR);
        contentPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        
        // 添加标题
        JLabel titleLabel = new JLabel("사용할 윷 결과를 선택하세요", JLabel.CENTER);
        titleLabel.setFont(new Font("Malgun Gothic", Font.BOLD, 18));
        titleLabel.setForeground(ACCENT_COLOR);
        contentPanel.add(titleLabel, BorderLayout.NORTH);
        
        // 创建按钮面板
        JPanel buttonPanel = new JPanel(new GridLayout(availableRolls.size(), 1, 0, 10));
        buttonPanel.setOpaque(false);
        
        final int[] result = new int[] { -1 };
        
        // 为每个可用结果创建一个按钮
        for (Integer roll : availableRolls) {
            String resultName = YutSet.getRollName(roll);
            Color buttonColor;
            
            // 根据点数设置不同颜色
            switch (roll) {
                case YutSet.DO: buttonColor = new Color(200, 200, 200); break;
                case YutSet.GAE: buttonColor = new Color(150, 200, 150); break;
                case YutSet.GEOL: buttonColor = new Color(150, 150, 200); break;
                case YutSet.YUT: buttonColor = new Color(200, 150, 150); break;
                case YutSet.MO: buttonColor = new Color(200, 200, 150); break;
                default: buttonColor = new Color(220, 220, 220);
            }
            
            JButton rollButton = createGameButton(roll + " (" + resultName + ")", buttonColor, 40);
            rollButton.addActionListener(e -> {
                result[0] = roll;
                dialog.dispose();
            });
            
            buttonPanel.add(rollButton);
        }
        
        contentPanel.add(buttonPanel, BorderLayout.CENTER);
        dialog.add(contentPanel);
        
        dialog.setVisible(true);
        return result[0];
    }
    
    /**
     * 显示错误消息
     */
    private void showErrorMessage(String message) {
        JOptionPane.showMessageDialog(
            mainFrame,
            message,
            "오류",
            JOptionPane.ERROR_MESSAGE
        );
    }
    
    /**
     * 播放移动音效（简单实现，实际可以使用音频API）
     */
    private void playMoveSound() {
        Toolkit.getDefaultToolkit().beep();
    }
    
    /**
     * 布局组件
     */
    private void layoutComponents() {
        // 使用边框布局
        mainFrame.setLayout(new BorderLayout(10, 10));
        
        // 顶部面板 - 显示当前玩家和游戏进度，使用更小更现代的风格
        JPanel topPanel = new JPanel(new BorderLayout(15, 0));
        topPanel.setBackground(HEADER_COLOR);
        topPanel.setBorder(BorderFactory.createEmptyBorder(8, 15, 8, 15));
        
        // 创建玩家信息显示区域，更精简
        JPanel playerInfoPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 0));
        playerInfoPanel.setOpaque(false);
        
        // 玩家标签用更简洁的风格
        statusLabel.setPreferredSize(new Dimension(200, 30));
        statusLabel.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(Color.WHITE, 1),
            BorderFactory.createEmptyBorder(5, 10, 5, 10)
        ));
        playerInfoPanel.add(statusLabel);
        
        // 添加当前玩家标签
        topPanel.add(playerInfoPanel, BorderLayout.WEST);
        
        // 游戏进度显示更简洁的样式
        JPanel progressPanel = new JPanel(new BorderLayout());
        progressPanel.setOpaque(false);
        progressPanel.setBorder(BorderFactory.createEmptyBorder(5, 0, 5, 0));
        
        gameProgressBar.setPreferredSize(new Dimension(200, 20));
        progressPanel.add(gameProgressBar, BorderLayout.CENTER);
        
        // 添加游戏进度
        topPanel.add(progressPanel, BorderLayout.EAST);
        
        // 底部控制面板 - 包含按钮和动画效果，使用更现代的水平居中布局
        JPanel controlPanel = new JPanel();
        controlPanel.setBackground(PANEL_COLOR);
        controlPanel.setBorder(BorderFactory.createEmptyBorder(15, 10, 15, 10));
        
        // 使用更现代的FlowLayout，居中对齐
        controlPanel.setLayout(new FlowLayout(FlowLayout.CENTER, 30, 0));
        
        // 按钮使用更圆润的样式
        throwButton.setBorder(createRoundedBorder(BUTTON_COLOR, 20, 1));
        endTurnButton.setBorder(createRoundedBorder(new Color(100, 100, 100), 20, 1));
        
        controlPanel.add(throwButton);
        controlPanel.add(endTurnButton);
        
        // 中央面板 - 包含游戏区域，确保棋盘完整显示
        JPanel centerPanel = new JPanel(new BorderLayout(10, 10));
        centerPanel.setBackground(BACKGROUND_COLOR);
        centerPanel.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));
        
        // 添加结果标签到中央面板顶部，改为更精简的风格
        resultLabel.setBorder(createRoundedBorder(HEADER_COLOR, 10, 1));
        resultLabel.setPreferredSize(new Dimension(0, 40));
        resultLabel.setText("게임을 시작하려면 '윷 던지기' 버튼을 클릭하세요");
        resultLabel.setFont(new Font("Malgun Gothic", Font.BOLD, 16));
        centerPanel.add(resultLabel, BorderLayout.NORTH);
        
        // 主游戏区域 - 包含棋盘和玩家面板
        JPanel gameAreaPanel = new JPanel(new BorderLayout(15, 0));
        gameAreaPanel.setOpaque(false);
        
        // 创建左侧面板 - 简化布局，去掉大色块
        JPanel leftPanel = new JPanel();
        leftPanel.setLayout(new BoxLayout(leftPanel, BoxLayout.Y_AXIS));
        leftPanel.setOpaque(false);
        leftPanel.setBorder(BorderFactory.createEmptyBorder(0, 5, 0, 5));
        leftPanel.setPreferredSize(new Dimension(220, 0)); // 增加左侧面板宽度以容纳完整说明
        
        // 添加游戏说明到左侧面板
        JPanel instructionPanel = createInstructionPanel();
        instructionPanel.setAlignmentX(Component.CENTER_ALIGNMENT);
        leftPanel.add(instructionPanel);
        leftPanel.add(Box.createVerticalStrut(20)); // 空白间隔
        
        // 添加左侧面板
        gameAreaPanel.add(leftPanel, BorderLayout.WEST);
        
        // 创建一个包含棋盘的面板，确保居中显示
        JPanel boardContainerPanel = new JPanel(new BorderLayout());
        boardContainerPanel.setOpaque(false);
        boardContainerPanel.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));
        
        // 棋盘的尺寸是关键 - 确保完整显示所有内容
        boardPanel.setMinimumSize(new Dimension(700, 600)); // 匹配SimpleBoardPanel中定义的新尺寸
        boardContainerPanel.add(boardPanel, BorderLayout.CENTER);
        
        // 添加棋盘面板到游戏区域中央
        gameAreaPanel.add(boardContainerPanel, BorderLayout.CENTER);
        
        // 创建右侧面板 - 包含玩家棋子，垂直排列
        JPanel rightPanel = new JPanel();
        rightPanel.setLayout(new BoxLayout(rightPanel, BoxLayout.Y_AXIS));
        rightPanel.setOpaque(false);
        rightPanel.setBorder(BorderFactory.createEmptyBorder(0, 5, 0, 5));
        rightPanel.setPreferredSize(new Dimension(200, 0)); // 减小右侧面板宽度
        
        // 添加回合指示器
        turnIndicator.setAlignmentX(Component.CENTER_ALIGNMENT);
        rightPanel.add(turnIndicator);
        rightPanel.add(Box.createVerticalStrut(10)); // 空白间隔
        
        // 添加玩家面板
        playerPanel.setAlignmentX(Component.CENTER_ALIGNMENT);
        rightPanel.add(playerPanel);
        
        // 添加右侧面板到游戏区域
        gameAreaPanel.add(rightPanel, BorderLayout.EAST);
        
        // 添加游戏区域到中央面板
        centerPanel.add(gameAreaPanel, BorderLayout.CENTER);
        
        // 添加所有面板到主窗口
        mainFrame.add(topPanel, BorderLayout.NORTH);
        mainFrame.add(centerPanel, BorderLayout.CENTER);
        mainFrame.add(controlPanel, BorderLayout.SOUTH);
    }
    
    /**
     * 创建圆角边框
     */
    private Border createRoundedBorder(Color color, int radius, int thickness) {
        return BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(color, thickness),
            BorderFactory.createEmptyBorder(5, 15, 5, 15)
        );
    }
    
    /**
     * 设置事件监听器
     */
    private void setupEventListeners() {
        // 添加按钮悬停效果
        throwButton.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                if (throwButton.isEnabled()) {
                    throwButton.setBackground(new Color(255, 215, 80)); // 更亮的黄色
                }
            }
            
            @Override
            public void mouseExited(MouseEvent e) {
                if (throwButton.isEnabled()) {
                    throwButton.setBackground(new Color(255, 204, 0)); // 恢复黄色
                }
            }
        });
        
        // 掷棒按钮事件
        throwButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // 调用handleThrow方法处理掷骰子逻辑
                handleThrow();
                
                // 停止按钮闪烁
                if (buttonHighlightTimer != null && buttonHighlightTimer.isRunning()) {
                    buttonHighlightTimer.stop();
                    throwButton.setBackground(BUTTON_COLOR);
                    throwButton.setBorder(createRoundedBorder(BUTTON_COLOR, 20, 1));
                }
            }
        });
        
        // 结束回合按钮悬停效果
        endTurnButton.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                if (endTurnButton.isEnabled()) {
                    endTurnButton.setBackground(new Color(220, 220, 220)); // 更亮的灰色
                }
            }
            
            @Override
            public void mouseExited(MouseEvent e) {
                if (endTurnButton.isEnabled()) {
                    endTurnButton.setBackground(new Color(200, 200, 200)); // 恢复灰色
                }
            }
        });
        
        // 结束回合按钮事件
        endTurnButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                handleEndTurn();
            }
        });
    }
    
    /**
     * 更新按钮状态
     */
    private void updateButtonStates() {
        boolean hasRolled = controller.getGame().hasRolled();
        boolean hasAvailableRolls = !controller.getGame().getAvailableRolls().isEmpty();
        boolean reThrowAllowed = controller.getGame().isReThrowAllowed();
        
        // 只有在没有可用掷棒结果时才能结束回合
        endTurnButton.setEnabled(hasRolled && (!hasAvailableRolls || !reThrowAllowed));
        
        // 只有在没有掷过棒或允许重新掷棒且没有可用结果时才能掷棒
        throwButton.setEnabled(!hasRolled || (reThrowAllowed && !hasAvailableRolls));
        
        // 更新棋子按钮
        updatePieceButtons();
        
        // 更新当前玩家标签，添加醒目的颜色提示
        Player currentPlayer = controller.getGame().getCurrentPlayer();
        int playerIndex = controller.getGame().getPlayers().indexOf(currentPlayer);
        Color playerColor = (playerIndex == 0) ? 
            new Color(220, 80, 80) : new Color(70, 130, 180);
        
        statusLabel.setText("현재 플레이어: " + currentPlayer.getName());
        statusLabel.setForeground(playerColor);
    }
    
    /**
     * 更新棋子按钮状态
     */
    private void updatePieceButtons() {
        List<Player> players = controller.getGame().getPlayers();
        Player currentPlayer = controller.getGame().getCurrentPlayer();
        boolean canMove = controller.getGame().hasRolled() && 
                        !controller.getGame().getAvailableRolls().isEmpty();
        
        for (int i = 0; i < players.size(); i++) {
            Player player = players.get(i);
            boolean isCurrentPlayer = (player == currentPlayer);
            
            for (int j = 0; j < 4; j++) {
                Piece piece = player.getPieces().get(j);
                int position = piece.getPosition();
                
                // 更新按钮文本显示位置 - 修改：完成的棋子(位置30)不显示"완"文字
                String posText = position == -1 ? "집" : 
                               position == 30 ? "" : 
                               String.valueOf(position);
                pieceButtons[i][j].setText("말 " + (j+1) + (posText.isEmpty() ? "" : " (" + posText + ")"));
                
                // 设置按钮状态 - 修改：所有棋子都可以点击，不仅仅是在家里的
                boolean canMovePiece = isCurrentPlayer && canMove && position < 30; // 允许所有未完成的棋子移动
                pieceButtons[i][j].setEnabled(canMovePiece);
                
                // 高亮显示当前玩家的棋子
                if (isCurrentPlayer) {
                    pieceButtons[i][j].setBorder(BorderFactory.createLineBorder(Color.YELLOW, 2));
                } else {
                    pieceButtons[i][j].setBorder(UIManager.getBorder("Button.border"));
                }
                
                // 棋子样式设置
                if (position == 30) {
                    // 到达终点的棋子 - 改为灰色且不透明度降低
                    pieceButtons[i][j].setBackground(new Color(200, 200, 200, 100));
                    pieceButtons[i][j].setForeground(new Color(100, 100, 100));
                    pieceButtons[i][j].setOpaque(true);
                } else if (position >= 0) {
                    // 已经在棋盘上的棋子 - 半透明显示
                    pieceButtons[i][j].setBackground(new Color(
                        player.getColor().getRed(),
                        player.getColor().getGreen(),
                        player.getColor().getBlue(),
                        100)); // 设置为半透明
                    pieceButtons[i][j].setForeground(Color.DARK_GRAY);
                    pieceButtons[i][j].setOpaque(true);
                } else {
                    // 家里的棋子 - 正常显示
                    pieceButtons[i][j].setBackground(player.getColor());
                    pieceButtons[i][j].setForeground(Color.WHITE);
                    pieceButtons[i][j].setOpaque(true);
                }
            }
        }
    }
    
    @Override
    public void show() {
        mainFrame.setLocationRelativeTo(null);
        mainFrame.setVisible(true);
        
        // 添加窗口大小变化监听，确保提示面板覆盖整个窗口
        mainFrame.addComponentListener(new java.awt.event.ComponentAdapter() {
            @Override
            public void componentResized(java.awt.event.ComponentEvent e) {
                if (startHintPanel != null && startHintPanel.isVisible()) {
                    startHintPanel.setBounds(0, 0, mainFrame.getWidth(), mainFrame.getHeight());
                }
            }
        });
    }
    
    @Override
    public void close() {
        if (buttonHighlightTimer != null && buttonHighlightTimer.isRunning()) {
            buttonHighlightTimer.stop();
        }
        mainFrame.dispose();
    }
    
    // GameStateListener接口实现
    @Override
    public void updateGameState() {
        Player currentPlayer = controller.getGame().getCurrentPlayer();
        statusLabel.setText("현재 플레이어: " + currentPlayer.getName());
        updateButtonStates();
        boardPanel.repaint();
    }
    
    @Override
    public void updateCurrentPlayer(Player currentPlayer) {
        statusLabel.setText("현재 플레이어: " + currentPlayer.getName());
        updateButtonStates();
        boardPanel.repaint();
    }
    
    @Override
    public void updateYutResult(int result) {
        String resultName = YutSet.getRollName(result);
        resultLabel.setText("윷 결과: " + result + " (" + resultName + ")");
        updateButtonStates();
    }
    
    @Override
    public void updatePiecePosition(Piece piece) {
        updatePieceButtons();
        boardPanel.repaint();
    }
    
    @Override
    public void resetUI() {
        resultLabel.setText("게임을 시작합니다");
        statusLabel.setText("현재 플레이어: " + controller.getGame().getCurrentPlayer().getName());
        updateButtonStates();
        boardPanel.repaint();
    }
    
    @Override
    public void onGameReset() {
        resetUI();
    }
    
    @Override
    public void onYutThrown(int result) {
        updateYutResult(result);
    }
    
    @Override
    public void onRollSelected(int roll) {
        updateButtonStates();
    }
    
    @Override
    public void onPieceMoved(Piece piece) {
        updatePiecePosition(piece);
        
        // 检查游戏是否结束
        if (controller.getGame().isGameOver()) {
            showGameOver(controller.getGame().getWinner());
        }
    }
    
    @Override
    public void onTurnEnded() {
        updateCurrentPlayer(controller.getGame().getCurrentPlayer());
    }
    
    @Override
    public void showGameOver(Player winner) {
        // 创建自定义对话框，而不是使用标准的JOptionPane
        JDialog gameOverDialog = new JDialog(mainFrame, "게임 종료!", true);
        gameOverDialog.setSize(400, 300);
        gameOverDialog.setLocationRelativeTo(mainFrame);
        gameOverDialog.setResizable(false);
        
        // 创建面板
        JPanel panel = new JPanel(new BorderLayout(10, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        panel.setBackground(new Color(250, 245, 220));
        
        // 标题标签
        JLabel titleLabel = new JLabel("게임 종료!", JLabel.CENTER);
        titleLabel.setFont(new Font("Malgun Gothic", Font.BOLD, 28));
        titleLabel.setForeground(new Color(139, 69, 19));
        panel.add(titleLabel, BorderLayout.NORTH);
        
        // 胜利信息
        JLabel winnerLabel = new JLabel(winner.getName() + " 승리했습니다!", JLabel.CENTER);
        winnerLabel.setFont(new Font("Malgun Gothic", Font.BOLD, 24));
        winnerLabel.setForeground(winner.getColor());
        panel.add(winnerLabel, BorderLayout.CENTER);
        
        // 按钮面板
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 10));
        buttonPanel.setOpaque(false);
        
        // 新游戏按钮
        JButton newGameButton = createGameButton("새 게임 (New Game)", BUTTON_COLOR, 50);
        newGameButton.addActionListener(e -> {
            // 重置游戏
            controller.resetGame();
            // 关闭对话框
            gameOverDialog.dispose();
        });
        
        // 退出按钮
        JButton exitButton = createGameButton("종료 (Exit)", new Color(100, 100, 100), 50);
        exitButton.addActionListener(e -> {
            // 关闭对话框
            gameOverDialog.dispose();
            // 关闭游戏
            System.exit(0);
        });
        
        buttonPanel.add(newGameButton);
        buttonPanel.add(exitButton);
        panel.add(buttonPanel, BorderLayout.SOUTH);
        
        gameOverDialog.add(panel);
        gameOverDialog.setVisible(true);
    }
    
    /**
     * 动态背景面板
     */
    private class BackgroundPanel extends JPanel {
        private Image patternImage;
        
        public BackgroundPanel() {
            super();
            setOpaque(true);
        }
        
        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            Graphics2D g2d = (Graphics2D) g;
            
            // 设置抗锯齿
            g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            
            // 绘制淡色背景
            int width = getWidth();
            int height = getHeight();
            
            // 创建渐变背景 - 使用更温和的颜色
            GradientPaint backgroundGradient = new GradientPaint(
                0, 0, BACKGROUND_COLOR,
                0, height, new Color(235, 235, 225)
            );
            g2d.setPaint(backgroundGradient);
            g2d.fillRect(0, 0, width, height);
            
            // 绘制韩国传统太极图案背景
            drawKoreanPatterns(g2d, width, height);
            
            // 添加装饰性边框
            g2d.setColor(new Color(0, 114, 114, 20));
            g2d.setStroke(new BasicStroke(2));
            g2d.drawRoundRect(10, 10, width - 20, height - 20, 15, 15);
        }
        
        /**
         * 绘制韩国传统图案
         */
        private void drawKoreanPatterns(Graphics2D g2d, int width, int height) {
            // 使用半透明效果
            Composite originalComposite = g2d.getComposite();
            g2d.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 0.05f));
            
            // 太极图案间隔
            int patternSize = 100;
            
            for (int x = 0; x < width; x += patternSize) {
                for (int y = 0; y < height; y += patternSize) {
                    if ((x + y) % (patternSize * 2) == 0) {
                        // 简化的太极图案
                        drawTaegeuk(g2d, x, y, patternSize);
                    } else {
                        // 绘制四角花纹
                        drawFlowerPattern(g2d, x, y, patternSize);
                    }
                }
            }
            
            // 恢复原始设置
            g2d.setComposite(originalComposite);
        }
        
        /**
         * 绘制太极图案
         */
        private void drawTaegeuk(Graphics2D g2d, int x, int y, int size) {
            int radius = size / 2;
            int centerX = x + radius;
            int centerY = y + radius;
            
            // 绘制太极的两部分
            g2d.setColor(new Color(0, 114, 114));  // 青色部分
            g2d.fillArc(x, y, size, size, 90, 180);
            
            g2d.setColor(new Color(231, 111, 81));  // 橙红部分
            g2d.fillArc(x, y, size, size, 270, 180);
            
            // 绘制小圆点
            int smallRadius = radius / 3;
            g2d.setColor(new Color(231, 111, 81));
            g2d.fillOval(centerX - smallRadius/2, centerY - radius/2, smallRadius, smallRadius);
            
            g2d.setColor(new Color(0, 114, 114));
            g2d.fillOval(centerX - smallRadius/2, centerY + radius/3, smallRadius, smallRadius);
        }
        
        /**
         * 绘制花纹图案
         */
        private void drawFlowerPattern(Graphics2D g2d, int x, int y, int size) {
            int radius = size / 2;
            int centerX = x + radius;
            int centerY = y + radius;
            
            // 绘制几何图案 - 韩国传统图案中常见的四方连续纹样
            g2d.setColor(new Color(38, 70, 83, 50));
            
            for (int i = 0; i < 4; i++) {
                // 计算每个角的坐标
                double angle = Math.PI / 2 * i;
                int x1 = (int)(centerX + radius * 0.8 * Math.cos(angle));
                int y1 = (int)(centerY + radius * 0.8 * Math.sin(angle));
                
                // 绘制小四边形
                int smallSize = radius / 4;
                g2d.fillRect(x1 - smallSize/2, y1 - smallSize/2, smallSize, smallSize);
                
                // 连接到中心
                g2d.setStroke(new BasicStroke(1));
                g2d.drawLine(centerX, centerY, x1, y1);
            }
            
            // 中心点
            g2d.fillOval(centerX - radius/8, centerY - radius/8, radius/4, radius/4);
        }
    }
    
    /**
     * 脉冲效果标签
     */
    private class PulsingLabel extends JLabel {
        private Color baseColor;
        
        public PulsingLabel(String text, Color color) {
            super(text, JLabel.CENTER);
            this.baseColor = color;
            setFont(new Font("Malgun Gothic", Font.BOLD, 16));
            setForeground(Color.WHITE);
            setOpaque(false);
            setBorder(BorderFactory.createEmptyBorder(10, 0, 10, 0));
            setPreferredSize(new Dimension(200, 40));
        }
        
        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2d = (Graphics2D) g;
            g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            
            // 计算脉冲效果 - 更平滑的动画
            float pulse = (float) Math.sin(pulseCounter * 0.08) * 0.1f + 0.9f;
            
            // 创建脉冲颜色
            Color pulseColor = new Color(
                Math.min(255, (int)(baseColor.getRed() * pulse)),
                Math.min(255, (int)(baseColor.getGreen() * pulse)),
                Math.min(255, (int)(baseColor.getBlue() * pulse))
            );
            
            // 绘制背景
            int width = getWidth();
            int height = getHeight();
            
            // 创建圆角矩形
            RoundRectangle2D rect = new RoundRectangle2D.Float(0, 0, width, height, 20, 20);
            
            // 渐变填充
            GradientPaint gradient = new GradientPaint(
                0, 0, pulseColor,
                0, height, pulseColor.darker()
            );
            g2d.setPaint(gradient);
            g2d.fill(rect);
            
            // 绘制边框
            g2d.setColor(Color.WHITE);
            g2d.setStroke(new BasicStroke(1.5f));
            g2d.draw(rect);
            
            // 添加装饰性花纹 - 简化的韩国传统图案
            int patternSize = 10;
            g2d.setColor(new Color(255, 255, 255, 40));
            
            for (int x = 5; x < width - 5; x += patternSize) {
                for (int y = 5; y < height - 5; y += patternSize) {
                    if ((x + y) % (patternSize * 2) == 0) {
                        g2d.fillRect(x, y, 2, 2);
                    }
                }
            }
            
            super.paintComponent(g);
        }
    }
    
    /**
     * 初始化游戏引导，帮助新玩家理解如何开始游戏
     */
    private void initializeGameTutorial() {
        // 创建掷骰子按钮闪烁效果
        buttonHighlightTimer = new Timer(500, e -> {
            isButtonHighlighted = !isButtonHighlighted;
            if (throwButton != null) {
                if (isButtonHighlighted) {
                    throwButton.setBackground(BUTTON_COLOR.brighter());
                    throwButton.setBorder(BorderFactory.createCompoundBorder(
                        BorderFactory.createLineBorder(Color.YELLOW, 3),
                        BorderFactory.createEmptyBorder(6, 15, 6, 15)
                    ));
                } else {
                    throwButton.setBackground(BUTTON_COLOR);
                    throwButton.setBorder(createRoundedBorder(BUTTON_COLOR, 20, 1));
                }
            }
        });
        buttonHighlightTimer.start();
        
        // 创建开始游戏提示面板
        startHintPanel = new JPanel();
        startHintPanel.setLayout(new BorderLayout());
        startHintPanel.setBackground(new Color(0, 0, 0, 180));
        
        JPanel hintContentPanel = new JPanel();
        hintContentPanel.setLayout(new BoxLayout(hintContentPanel, BoxLayout.Y_AXIS));
        hintContentPanel.setOpaque(false);
        hintContentPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        
        JLabel hintTitle = new JLabel("게임 방법", JLabel.CENTER);
        hintTitle.setFont(new Font("Malgun Gothic", Font.BOLD, 24));
        hintTitle.setForeground(Color.WHITE);
        hintTitle.setAlignmentX(Component.CENTER_ALIGNMENT);
        
        JLabel hintText = new JLabel("<html><div style='text-align: center; width: 400px;'>" +
                "<p>1. 먼저 아래쪽에 있는 <span style='color:yellow;'>윷 던지기</span> 버튼을 클릭하세요.</p>" +
                "<p>2. 윷 결과에 따라 움직일 말을 선택하세요.</p>" +
                "<p>3. 모든 말이 도착점에 도달하면 승리합니다!</p>" +
                "</div></html>");
        hintText.setFont(new Font("Malgun Gothic", Font.PLAIN, 16));
        hintText.setForeground(Color.WHITE);
        hintText.setAlignmentX(Component.CENTER_ALIGNMENT);
        
        JButton startButton = new JButton("게임 시작");
        startButton.setFont(new Font("Malgun Gothic", Font.BOLD, 16));
        startButton.setBackground(BUTTON_COLOR);
        startButton.setForeground(Color.WHITE);
        startButton.setFocusPainted(false);
        startButton.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(BUTTON_COLOR.darker(), 1),
            BorderFactory.createEmptyBorder(8, 20, 8, 20)
        ));
        startButton.setAlignmentX(Component.CENTER_ALIGNMENT);
        startButton.addActionListener(e -> {
            mainFrame.getLayeredPane().remove(startHintPanel);
            mainFrame.revalidate();
            mainFrame.repaint();
            hasShownTutorial = true;
            // 设置焦点到掷骰子按钮
            throwButton.requestFocusInWindow();
            // 更新标签以指导用户下一步操作
            resultLabel.setText("시작하려면 '윷 던지기' 버튼을 클릭하세요 ⬇️");
        });
        
        hintContentPanel.add(hintTitle);
        hintContentPanel.add(Box.createVerticalStrut(20));
        hintContentPanel.add(hintText);
        hintContentPanel.add(Box.createVerticalStrut(30));
        hintContentPanel.add(startButton);
        
        startHintPanel.add(hintContentPanel, BorderLayout.CENTER);
        
        // 在显示主界面后显示引导
        SwingUtilities.invokeLater(() -> {
            if (mainFrame != null && mainFrame.isVisible()) {
                mainFrame.getLayeredPane().add(startHintPanel, JLayeredPane.POPUP_LAYER);
                startHintPanel.setBounds(0, 0, mainFrame.getWidth(), mainFrame.getHeight());
                startHintPanel.setVisible(true);
            }
        });
    }
    
    /**
     * 更新当前游戏动作提示标签
     */
    private void updateCurrentActionLabel() {
        if (resultLabel != null) {
            String message;
            if (!controller.getGame().hasRolled()) {
                message = "시작하려면 '윷 던지기' 버튼을 클릭하세요 ⬇️";
                
                // 突出显示掷骰子按钮，如果用户还没有掷过骰子
                if (!hasShownTutorial) {
                    hasShownTutorial = true;
                } else if (buttonHighlightTimer != null && !buttonHighlightTimer.isRunning()) {
                    buttonHighlightTimer.start();
                }
            } else if (!controller.getGame().getAvailableRolls().isEmpty()) {
                message = "말을 선택하여 이동하세요";
                // 停止按钮闪烁
                if (buttonHighlightTimer != null && buttonHighlightTimer.isRunning()) {
                    buttonHighlightTimer.stop();
                    throwButton.setBackground(BUTTON_COLOR);
                    throwButton.setBorder(createRoundedBorder(BUTTON_COLOR, 20, 1));
                }
            } else if (controller.getGame().getCurrentRoll() == YutSet.YUT || controller.getGame().getCurrentRoll() == YutSet.MO) {
                String rollName = controller.getGame().getCurrentRoll() == YutSet.YUT ? "윷" : "모";
                message = rollName + "이 나왔습니다! 다시 던지세요!";
            } else {
                message = "'턴 종료' 버튼을 클릭하여 턴을 마치세요";
            }
            resultLabel.setText(message);
            resultLabel.setFont(new Font("Malgun Gothic", Font.BOLD, 16));
        }
    }
    
    // 为棋盘添加一个特殊的防点击处理方法
    private void setupBoardPanel() {
        // 添加属性变更监听器，处理SimpleBoardPanel发出的pieceClicked事件
        boardPanel.addPropertyChangeListener("pieceClicked", evt -> {
            if (evt.getNewValue() instanceof Piece) {
                Piece clickedPiece = (Piece) evt.getNewValue();
                System.out.println("SimpleGameUI收到棋子点击事件: " + clickedPiece.getId() + " 在位置: " + clickedPiece.getPosition());
                
                // 只有在已经掷过骰子且有可用移动步数时才处理
                if (controller.getGame().hasRolled() && !controller.getGame().getAvailableRolls().isEmpty()) {
                    System.out.println("处理棋子点击: 棋子ID=" + clickedPiece.getId() + " 位置=" + clickedPiece.getPosition());
                    handlePieceClick(clickedPiece);
                } else {
                    System.out.println("不处理点击：尚未掷骰子或没有可用点数");
                }
            }
        });
    }
    
    /**
     * 处理棋子点击事件
     */
    private void handlePieceClick(Piece piece) {
        Game game = controller.getGame();
        
        // 确保是当前玩家的棋子
        if (piece.getOwner() != game.getCurrentPlayer()) {
            System.out.println("Cannot move: piece belongs to " + piece.getOwner().getName() + 
                             " but current player is " + game.getCurrentPlayer().getName());
            return;
        }
        
        // 如果棋子已完成，不允许移动
        if (piece.isCompleted()) {
            System.out.println("Cannot move: piece is already completed");
            return;
        }
        
        // 确保玩家已经掷过骰子
        if (!game.hasRolled() || game.getAvailableRolls().isEmpty()) {
            System.out.println("Cannot move: player has not rolled or no available moves");
            return;
        }
        
        // 如果有多个可用掷骰子结果，显示选择对话框
        if (game.getAvailableRolls().size() > 1) {
            int selectedRoll = showRollSelectionDialog(game.getAvailableRolls());
            if (selectedRoll != -1) {
                movePieceWithRoll(piece, selectedRoll);
            }
        } else if (!game.getAvailableRolls().isEmpty()) {
            // 只有一个可用的掷骰子结果
            int roll = game.getAvailableRolls().get(0);
            movePieceWithRoll(piece, roll);
        }
    }
    
    /**
     * 使用指定的骰子点数移动棋子
     */
    private void movePieceWithRoll(Piece piece, int roll) {
        if (piece == null || roll == 0) return;
        
        // 检查移动是否有效
        Game game = controller.getGame();
        Board board = game.getBoard();
        int currentPos = piece.getPosition();
        boolean isAtJunction = board.isJunction(currentPos);
        
        // 特殊处理位置25 - 强制使用DIAGONAL_LEFT路径
        if (currentPos == 25) {
            System.out.println("特殊处理位置25，强制使用DIAGONAL_LEFT路径");
            if (game.movePiece(piece, roll, Board.PathType.DIAGONAL_LEFT)) {
                updatePieceButtons();
                boardPanel.repaint();
                playMoveSound();
                
                // 检查是否应该自动结束回合
                if (game.getAvailableRolls().isEmpty() && !game.isReThrowAllowed()) {
                    handleEndTurn();
                }
            } else {
                showErrorMessage("윷을 움직일 수 없습니다!");
            }
            return;
        }
        
        // 如果当前位置是交叉路口，检查是否已有路径选择
        if (isAtJunction) {
            Map<Board.PathType, Integer> paths = board.getAvailablePaths(currentPos);
            
            // 检查棋子是否已经有针对该位置的路径选择
            Board.PathType savedPathType = piece.getPathSelection(currentPos);
            
            if (savedPathType != null && paths.containsKey(savedPathType)) {
                // 使用已保存的路径选择
                System.out.println("Using saved path " + savedPathType + " for piece " + piece.getId() + 
                                " at position " + currentPos);
                
                // 使用保存的路径移动棋子
                if (game.movePiece(piece, roll, savedPathType)) {
                    if (DEBUG) System.out.println("移动成功: 新位置=" + piece.getPosition());
                    updatePieceButtons();
                    boardPanel.repaint();
                    playMoveSound();
                    
                    // 检查是否应该自动结束回合
                    if (game.getAvailableRolls().isEmpty() && !game.isReThrowAllowed()) {
                        handleEndTurn();
                    }
                } else {
                    if (DEBUG) System.out.println("移动失败");
                    showErrorMessage("윷을 움직일 수 없습니다!");
                }
                return;
            } else if (paths.size() > 1) {
                // 显示路径选择对话框
                Board.PathType chosenPath = showPathSelectionDialog();
                if (chosenPath != null) {
                    if (DEBUG) System.out.println("在交叉点" + currentPos + "选择路径: " + chosenPath);
                    
                    // 保存路径选择以备将来使用
                    piece.setPathSelection(currentPos, chosenPath);
                    
                    // 使用选定的路径移动棋子
                    if (game.movePiece(piece, roll, chosenPath)) {
                        if (DEBUG) System.out.println("移动成功: 新位置=" + piece.getPosition());
                        updatePieceButtons();
                        boardPanel.repaint();
                        playMoveSound();
                        
                        // 检查是否应该自动结束回合
                        if (game.getAvailableRolls().isEmpty() && !game.isReThrowAllowed()) {
                            handleEndTurn();
                        }
                    } else {
                        if (DEBUG) System.out.println("移动失败");
                        showErrorMessage("윷을 움직일 수 없습니다!");
                    }
                }
                return;
            }
        } 
        
        // 计算下一个位置
        int nextPosition = board.getNextPosition(currentPos, roll);
        boolean willReachJunction = board.isJunction(nextPosition) && !isAtJunction;
        
        // 如果下一个位置是交叉点，先移动到交叉点，再选择路径
        if (willReachJunction) {
            // 先移动到路口位置
            boolean moveSuccess = game.movePiece(piece, roll);
            if (!moveSuccess) {
                showErrorMessage("윷을 움직일 수 없습니다!");
                return;
            }
            
            // 更新UI
            updatePieceButtons();
            boardPanel.repaint();
            
            // 检查是否需要选择路径
            Map<Board.PathType, Integer> availablePaths = board.getAvailablePaths(piece.getPosition());
            if (availablePaths.size() > 1) {
                // 检查是否已有保存的路径选择
                Board.PathType savedPathType = piece.getPathSelection(piece.getPosition());
                
                if (savedPathType != null && availablePaths.containsKey(savedPathType)) {
                    // 使用保存的路径选择
                    System.out.println("Using saved path " + savedPathType + " for junction " + piece.getPosition());
                    game.setPiecePathType(piece, savedPathType);
                } else {
                    // 显示路径选择对话框
                    Board.PathType chosenPath = showPathSelectionDialog();
                    if (chosenPath != null) {
                        // 保存路径选择以备将来使用
                        piece.setPathSelection(piece.getPosition(), chosenPath);
                        // 设置路径类型，但不再移动（已经移动到了交叉点）
                        game.setPiecePathType(piece, chosenPath);
                    }
                }
                
                updatePieceButtons();
                boardPanel.repaint();
            }
        } else {
            // 普通移动，没有路口
            if (game.movePiece(piece, roll)) {
                updatePieceButtons();
                boardPanel.repaint();
                playMoveSound();
            } else {
                showErrorMessage("윷을 움직일 수 없습니다!");
            }
        }
        
        // 检查是否应该自动结束回合
        if (game.getAvailableRolls().isEmpty() && !game.isReThrowAllowed()) {
            handleEndTurn();
        }
    }
    
    /**
     * 处理骰子掷出事件
     */
    private void handleThrow() {
        // 检查是否已经掷过骰子
        if (controller.getGame().hasRolled()) {
            return;
        }
        
        // 获取掷骰子结果
        int result = YutSet.throwYut();
        
        // 显示掷骰子动画效果
        showYutThrowingAnimation(result);
        
        controller.handleThrowResult(result);
        String resultName = controller.getGame().getRollName(result);
        
        // 更新提示信息
        statusLabel.setText("掷骰子结果: " + resultName + " (" + result + ")");
        
        // 使投掷按钮不可用，直到完成移动
        throwButton.setEnabled(false);
        
        // 使结束回合按钮可用
        endTurnButton.setEnabled(true);
        
        // 刷新棋盘显示
        boardPanel.repaint();
    }
    
    /**
     * 显示掷骰子动画
     * @param finalResult 最终掷棒结果
     */
    private void showYutThrowingAnimation(int finalResult) {
        // 创建一个模态对话框
        JDialog throwDialog = new JDialog(mainFrame, "Throwing Yut Sticks", true);
        throwDialog.setLayout(new BorderLayout());
        throwDialog.setSize(500, 450); // 增加高度，为按钮和结果提供更多空间
        throwDialog.setLocationRelativeTo(mainFrame);
        throwDialog.setDefaultCloseOperation(JDialog.DO_NOTHING_ON_CLOSE);
        
        // 主面板
        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.Y_AXIS));
        mainPanel.setBackground(BACKGROUND_COLOR);
        mainPanel.setBorder(BorderFactory.createEmptyBorder(15, 20, 15, 20));
        
        // 创建标题标签
        JLabel titleLabel = new JLabel("Throwing Sticks...", JLabel.CENTER);
        titleLabel.setFont(new Font("Malgun Gothic", Font.BOLD, 20));
        titleLabel.setForeground(ACCENT_COLOR);
        titleLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        mainPanel.add(titleLabel);
        mainPanel.add(Box.createVerticalStrut(10)); // 添加垂直间隔
        
        // 创建动画面板
        JPanel animationPanel = new JPanel() {
            private long startTime = System.currentTimeMillis();
            private final int totalSticks = 4;
            private final int[] stickStates = new int[totalSticks];
            // 根据最终结果计算正反面数量
            private final int[] finalStickStates = getFinalStickStates(finalResult);
            private boolean buttonAdded = false;
            
            {
                // 初始化动画计时器
                Timer timer = new Timer(50, e -> repaint());
                timer.start();
            }
            
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2d = (Graphics2D) g;
                g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                
                int width = getWidth();
                int height = getHeight();
                
                // 绘制背景
                g2d.setColor(new Color(250, 240, 230));
                g2d.fillRect(0, 0, width, height);
                
                // 计算动画阶段
                long elapsed = System.currentTimeMillis() - startTime;
                double phase = (elapsed % 1000) / 1000.0;
                
                // 掷棒的动态角度和高度
                double angle = 360 * phase;
                
                // 绘制四根棍子
                int stickWidth = 20;
                int stickLength = 120;
                int padding = 30;
                int startX = (width - (totalSticks * (stickWidth + padding) - padding)) / 2;
                
                // 更新棍子状态 - 在动画阶段随机变化，结束阶段显示最终结果
                if (elapsed < 2000) {
                    if (elapsed % 200 < 50) {
                        for (int i = 0; i < totalSticks; i++) {
                            stickStates[i] = (int)(Math.random() * 2); // 0或1表示正面或反面
                        }
                    }
                    
                    // 动画阶段更新标题
                    SwingUtilities.invokeLater(() -> {
                        titleLabel.setText("Throwing Sticks...");
                    });
                } else {
                    // 动画结束后使用最终结果
                    System.arraycopy(finalStickStates, 0, stickStates, 0, totalSticks);
                    
                    // 更新标题为结果
                    SwingUtilities.invokeLater(() -> {
                        titleLabel.setText("Result");
                    });
                }
                
                // 绘制每根棍子
                for (int i = 0; i < totalSticks; i++) {
                    int x = startX + i * (stickWidth + padding);
                    int y = height / 2;
                    
                    // 根据动画阶段调整显示
                    if (elapsed < 2000) {
                        // 正在抛掷阶段 - 棍子在空中旋转
                        double stickAngle = angle + (i * 30);
                        double stickPhase = Math.sin(Math.toRadians(stickAngle));
                        int stickY = y - (int)(50 * stickPhase);
                        
                        // 绘制旋转的棍子
                        g2d.rotate(Math.toRadians(stickAngle), x + stickWidth/2, stickY);
                        g2d.setColor(new Color(210, 180, 140));
                        g2d.fillRoundRect(x, stickY - stickLength/2, stickWidth, stickLength, 10, 10);
                        
                        // 绘制棍子标记
                        g2d.setColor(stickStates[i] == 0 ? Color.BLACK : new Color(200, 0, 0));
                        g2d.fillOval(x + stickWidth/4, stickY - 15, stickWidth/2, 30);
                        g2d.setTransform(new AffineTransform()); // 重置变换
                    } else {
                        // 掷棒结束，显示最终结果
                        g2d.setColor(new Color(210, 180, 140));
                        
                        if (stickStates[i] == 0) {
                            // 平放 - 正面朝上
                            g2d.fillRoundRect(x, y - stickWidth/2, stickLength, stickWidth, 10, 10);
                            g2d.setColor(Color.BLACK);
                            g2d.drawString("앞", x + stickLength/2 - 5, y + 5);
                        } else {
                            // 竖放 - 背面朝上
                            g2d.fillRoundRect(x, y - stickLength/2, stickWidth, stickLength, 10, 10);
                            g2d.setColor(new Color(200, 0, 0));
                            g2d.drawString("뒤", x + 3, y + 5);
                        }
                    }
                }
                
                // 显示最终结果标签和确认按钮
                if (elapsed >= 2000 && !buttonAdded) {
                    buttonAdded = true;
                    SwingUtilities.invokeLater(() -> {
                        // 添加结果标签
                        String resultName = YutSet.getRollName(finalResult);
                        
                        // 创建结果面板
                        JPanel resultPanel = new JPanel();
                        resultPanel.setLayout(new BoxLayout(resultPanel, BoxLayout.Y_AXIS));
                        resultPanel.setOpaque(false);
                        resultPanel.setBorder(BorderFactory.createEmptyBorder(15, 0, 15, 0));
                        
                        // 创建结果标签，设置为大号字体
                        JLabel resultLabel = new JLabel("Result: " + resultName + " (" + finalResult + " steps)", JLabel.CENTER);
                        resultLabel.setFont(new Font("Malgun Gothic", Font.BOLD, 24));
                        resultLabel.setForeground(BUTTON_COLOR);
                        resultLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
                        
                        resultPanel.add(resultLabel);
                        mainPanel.add(resultPanel);
                        
                        // 添加按钮面板
                        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
                        buttonPanel.setOpaque(false);
                        
                        JButton confirmButton = new JButton("Confirm");
                        confirmButton.setFont(new Font("Malgun Gothic", Font.BOLD, 16));
                        confirmButton.setBackground(BUTTON_COLOR);
                        confirmButton.setForeground(Color.WHITE);
                        confirmButton.setFocusPainted(false);
                        confirmButton.setBorder(BorderFactory.createCompoundBorder(
                            BorderFactory.createLineBorder(BUTTON_COLOR.darker(), 1),
                            BorderFactory.createEmptyBorder(8, 20, 8, 20)
                        ));
                        
                        confirmButton.addActionListener(e -> {
                            Timer timer = (Timer) getClientProperty("timer");
                            if (timer != null) {
                                timer.stop();
                            }
                            throwDialog.dispose();
                        });
                        
                        buttonPanel.add(confirmButton);
                        mainPanel.add(Box.createVerticalStrut(10)); // 添加间隔
                        mainPanel.add(buttonPanel);
                        
                        // 重绘对话框
                        throwDialog.revalidate();
                        throwDialog.repaint();
                    });
                }
            }
            
            /**
             * 根据最终结果获取棒子状态
             * 0表示正面朝上（平放），1表示背面朝上（竖放）
             */
            private int[] getFinalStickStates(int result) {
                int[] states = new int[totalSticks];
                // 根据结果设置棒子状态
                switch (result) {
                    case YutSet.DO: // 1步 - 1个背面朝上
                        states[0] = 1;
                        break;
                    case YutSet.GAE: // 2步 - 2个背面朝上
                        states[0] = 1;
                        states[1] = 1;
                        break;
                    case YutSet.GEOL: // 3步 - 3个背面朝上
                        states[0] = 1;
                        states[1] = 1;
                        states[2] = 1;
                        break;
                    case YutSet.YUT: // 4步 - 4个正面朝上
                        // 所有都是0，默认值已经是正面朝上
                        break;
                    case YutSet.MO: // 5步 - 全部背面朝上
                        states[0] = 1;
                        states[1] = 1;
                        states[2] = 1;
                        states[3] = 1;
                        break;
                    case YutSet.BACKDO: // 后退1步 - 特殊情况
                        states[0] = 1;
                        states[1] = 1;
                        states[2] = 1;
                        break;
                }
                return states;
            }
        };
        
        // 存储计时器引用以便之后停止
        Timer animTimer = new Timer(50, e -> animationPanel.repaint());
        animationPanel.putClientProperty("timer", animTimer);
        animTimer.start();
        
        animationPanel.setPreferredSize(new Dimension(400, 200));
        mainPanel.add(animationPanel);
        
        throwDialog.add(mainPanel);
        throwDialog.pack();
        throwDialog.setLocationRelativeTo(mainFrame);
        
        // 在另一个线程中显示对话框，防止阻塞UI
        new Thread(() -> {
            throwDialog.setVisible(true);
        }).start();
    }
    
    /**
     * 处理回合结束事件
     */
    private void handleEndTurn() {
        // 结束当前玩家的回合
        controller.endTurn();
        
        // 更新状态提示
        String currentPlayerName = controller.getGame().getCurrentPlayer().getName();
        statusLabel.setText(currentPlayerName + " 的回合");
        
        // 重置按钮状态
        throwButton.setEnabled(true);
        endTurnButton.setEnabled(false);
        
        // 刷新棋盘显示
        boardPanel.repaint();
    }
    
    /**
     * 创建左侧说明面板
     */
    private JPanel createInstructionPanel() {
        JPanel panel = new JPanel();
        panel.setLayout(new BorderLayout());
        panel.setBackground(new Color(250, 240, 230));
        panel.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(139, 69, 19), 2),
                BorderFactory.createEmptyBorder(10, 10, 10, 10)
        ));
        
        // 标题
        JLabel titleLabel = new JLabel("윷놀이 게임", JLabel.CENTER);
        titleLabel.setFont(new Font("Malgun Gothic", Font.BOLD, 18));
        titleLabel.setForeground(new Color(139, 69, 19));
        panel.add(titleLabel, BorderLayout.NORTH);
        
        // 游戏说明文本区域
        JTextArea instructionArea = new JTextArea();
        instructionArea.setEditable(false);
        instructionArea.setLineWrap(true);
        instructionArea.setWrapStyleWord(true);
        instructionArea.setFont(new Font("Malgun Gothic", Font.PLAIN, 14));
        instructionArea.setBackground(new Color(253, 245, 230));
        instructionArea.setText(
                "윷을 던져 말을 움직이는 한국 전통 게임입니다.\n\n" +
                "- 윷 던지기: 이동할 칸 수 결정\n" +
                "- 말 이동: 윷 결과에 따라 움직임\n" +
                "- 턴 종료: 다음 플레이어에게 턴 넘김\n\n" +
                "윷 결과:\n" +
                "- 도(Do): 1칸 이동\n" +
                "- 개(Gae): 2칸 이동\n" +
                "- 걸(Geol): 3칸 이동\n" +
                "- 윷(Yut): 4칸 이동, 한 번 더\n" +
                "- 모(Mo): 5칸 이동, 한 번 더\n" +
                "- 백도(BackDo): 1칸 뒤로 이동"
        );
        
        JScrollPane scrollPane = new JScrollPane(instructionArea);
        scrollPane.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));
        panel.add(scrollPane, BorderLayout.CENTER);
        
        return panel;
    }
    
    @Override
    public void onGameOver(Player winner) {
        showGameOver(winner);
    }
} 