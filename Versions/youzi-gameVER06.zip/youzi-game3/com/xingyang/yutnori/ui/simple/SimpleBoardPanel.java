package com.xingyang.yutnori.ui.simple;

import com.xingyang.yutnori.model.*;

import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 简易版游戏棋盘，专为SimpleGameUI设计
 * 完全重新实现，确保所有位置可见
 */
public class SimpleBoardPanel extends JPanel {
    // 添加调试标志
    private static final boolean DEBUG = false;
    
    private Game game;
    private Board board;
    
    // UI 常量
    private static final int POSITION_SIZE = 40; // 棋盘位置标记的大小
    private static final int PIECE_SIZE = 30; // 棋子大小
    
    // 位置坐标缓存
    private Map<Integer, Point> scaledPositions;
    
    // 添加防止循环绘制的标志
    private boolean isDrawingPieces = false;

    // 添加防止重绘循环的标志
    private boolean isRepainting = false;
    
    /**
     * 构造函数
     */
    public SimpleBoardPanel(Game game) {
        this.game = game;
        this.board = game.getBoard();
        this.scaledPositions = new HashMap<>();
        
        setBackground(new Color(250, 245, 220));
        setBorder(BorderFactory.createLineBorder(new Color(139, 69, 19), 2));
        
        // 添加鼠标监听器
        addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                handleMouseClick(e.getX(), e.getY());
                // 阻止事件继续传播
                e.consume();
            }
        });
    }
    
    /**
     * 处理鼠标点击事件，用于检测玩家是否点击了棋子
     */
    private void handleMouseClick(int mouseX, int mouseY) {
        if (DEBUG) {
            System.out.println("鼠标点击: x=" + mouseX + ", y=" + mouseY);
        }
        
        // 如果游戏已结束或还没有掷骰子，不处理点击
        if (game.isGameOver() || !game.hasRolled() || game.getAvailableRolls().isEmpty()) {
            if (DEBUG) {
                System.out.println("游戏状态不允许移动: 游戏结束=" + game.isGameOver() + 
                                  ", 已掷骰子=" + game.hasRolled() + 
                                  ", 可用点数=" + game.getAvailableRolls().isEmpty());
            }
            return;
        }
        
        Player currentPlayer = game.getCurrentPlayer();
        if (DEBUG) {
            System.out.println("当前玩家: " + currentPlayer.getName());
        }
        
        // 先检查是否点击了特定位置
        boolean pieceClicked = false;
        for (Map.Entry<Integer, Point> entry : scaledPositions.entrySet()) {
            int position = entry.getKey();
            Point point = entry.getValue();
            
            // 计算鼠标点击和位置中心的距离
            double distance = Math.sqrt(Math.pow(mouseX - point.x, 2) + Math.pow(mouseY - point.y, 2));
            
            // 增大点击检测范围
            if (distance <= POSITION_SIZE) {
                if (DEBUG) {
                    System.out.println("点击位置 " + position + " 距离: " + distance);
                }
                
                // 获取该位置的所有棋子
                List<Piece> piecesAtPosition = game.getPiecesAtPosition(position);
                if (DEBUG) {
                    System.out.println("位置 " + position + " 有 " + piecesAtPosition.size() + " 个棋子");
                }
                
                // 找到当前玩家的棋子
                for (Piece piece : piecesAtPosition) {
                    if (DEBUG) {
                        System.out.println("检查棋子 ID=" + piece.getId() + " 所有者=" + piece.getOwner().getName());
                    }
                    
                    if (piece.getOwner() == currentPlayer) {
                        // 找到当前玩家的棋子，通知父组件处理棋子移动
                        if (DEBUG) {
                            System.out.println("触发棋子点击事件: 棋子ID=" + piece.getId() + 
                                              ", 位置=" + piece.getPosition());
                        }
                        firePropertyChange("pieceClicked", null, piece);
                        pieceClicked = true;
                        return;
                    }
                }
            }
        }
        
        // 如果没有点击到棋盘上的棋子，尝试检查家里的棋子
        if (!pieceClicked && DEBUG) {
            System.out.println("没有点击到棋盘上的棋子，尝试从家里选择");
        }
    }
    
    @Override
    protected void paintComponent(Graphics g) {
        // 检查是否正在绘制中以防止重绘循环
        if (isRepainting) {
            return;
        }
        
        try {
            isRepainting = true;
            super.paintComponent(g);
            
            Graphics2D g2d = (Graphics2D) g;
            g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            
            // 绘制游戏板
            drawBoard(g2d);
            
            // 绘制棋子
            drawPieces(g2d);
        } finally {
            isRepainting = false;
        }
    }
    
    /**
     * 绘制游戏板
     */
    private void drawBoard(Graphics2D g2d) {
        int width = getWidth();
        int height = getHeight();
        
        // 计算适合画板的正方形边长
        int boardSide = Math.min(width, height) - 100; // 减去100为边距
        
        // 计算边距，使棋盘居中
        int marginX = (width - boardSide) / 2;
        int marginY = (height - boardSide) / 2;
        
        // 绘制背景
        g2d.setColor(new Color(252, 248, 240)); // 米黄色背景
        g2d.fillRect(0, 0, width, height);
        
        // 绘制棋盘底色 - 略微暗色的背景
        g2d.setColor(new Color(242, 235, 220));
        g2d.fillRoundRect(marginX - 10, marginY - 10, boardSide + 20, boardSide + 20, 20, 20);
        
        // 绘制棋盘边框
        g2d.setColor(new Color(139, 69, 19)); // 棕色
        g2d.setStroke(new BasicStroke(3.0f));
        g2d.drawRoundRect(marginX - 10, marginY - 10, boardSide + 20, boardSide + 20, 20, 20);
        
        // 计算位置坐标
        calculatePositions(marginX, marginY, boardSide);
        
        // 绘制路径
        drawPaths(g2d);
        
        // 绘制位置标记
        for (Map.Entry<Integer, Point> entry : scaledPositions.entrySet()) {
            int position = entry.getKey();
            Point point = entry.getValue();
            boolean isCorner = (position % 5 == 0 || position == 20); // 5, 10, 15, 20 是拐角
            
            drawPosition(g2d, point.x, point.y, position, isCorner);
        }
        
        // 绘制棋盘装饰 - 添加一些韩国风格的图案
        drawBoardDecorations(g2d, marginX, marginY, boardSide);
    }
    
    /**
     * 绘制棋盘装饰
     */
    private void drawBoardDecorations(Graphics2D g2d, int x, int y, int size) {
        // 设置透明度
        Composite originalComposite = g2d.getComposite();
        g2d.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 0.1f));
        
        // 绘制中心图案
        int centerX = x + size / 2;
        int centerY = y + size / 2;
        
        // 简化的太极图案
        g2d.setColor(new Color(0, 100, 150));
        g2d.fillArc(centerX - 60, centerY - 60, 120, 120, 0, 180);
        g2d.setColor(new Color(200, 50, 50));
        g2d.fillArc(centerX - 60, centerY - 60, 120, 120, 180, 180);
        
        // 四角花纹
        int cornerSize = 40;
        g2d.setColor(new Color(0, 100, 0));
        // 左上角花纹
        drawFlowerPattern(g2d, x + 40, y + 40, cornerSize);
        // 右上角花纹
        drawFlowerPattern(g2d, x + size - 40, y + 40, cornerSize);
        // 左下角花纹
        drawFlowerPattern(g2d, x + 40, y + size - 40, cornerSize);
        // 右下角花纹
        drawFlowerPattern(g2d, x + size - 40, y + size - 40, cornerSize);
        
        // 恢复原始透明度
        g2d.setComposite(originalComposite);
    }
    
    /**
     * 绘制花纹图案
     */
    private void drawFlowerPattern(Graphics2D g2d, int x, int y, int size) {
        // 简化的韩国传统四方连续纹样
        int halfSize = size / 2;
        
        // 绘制中心点
        g2d.fillOval(x - 3, y - 3, 6, 6);
        
        // 绘制四片花瓣
        for (int i = 0; i < 4; i++) {
            double angle = Math.PI / 2 * i;
            int x1 = (int)(x + halfSize * Math.cos(angle));
            int y1 = (int)(y + halfSize * Math.sin(angle));
            g2d.fillOval(x1 - 5, y1 - 5, 10, 10);
            g2d.drawLine(x, y, x1, y1);
        }
    }
    
    /**
     * 计算棋盘上各位置的坐标
     */
    private void calculatePositions(int marginX, int marginY, int boardSize) {
        scaledPositions.clear();
        
        // 网格的间距 - 棋盘分为5x5的网格，共需6个点（角点重叠）
        int gridSize = boardSize / 5; // 5个间隔，6个点
        
        // 计算棋盘顶点坐标
        int topLeftX = marginX;
        int topLeftY = marginY;
        int topRightX = marginX + boardSize;
        int topRightY = marginY;
        int bottomLeftX = marginX;
        int bottomLeftY = marginY + boardSize;
        int bottomRightX = marginX + boardSize;
        int bottomRightY = marginY + boardSize;
        
        // 定义中心点 - 改为23
        int centerX = marginX + boardSize / 2;
        int centerY = marginY + boardSize / 2;
        
        // 放置外围位置点 - 顺时针排列
        
        // 顶部点（5-10）- 从右到左，共6个点
        for (int i = 0; i < 6; i++) {
            int pos = 5 + i;
            int x = topRightX - i * gridSize;
            int y = topLeftY;
            scaledPositions.put(pos, new Point(x, y));
        }
        
        // 左侧点（10-15）- 从上到下，共6个点（包含10和15两个拐角点）
        for (int i = 0; i < 6; i++) {
            int pos = 10 + i;
            int x = topLeftX;
            int y = topLeftY + i * gridSize;
            scaledPositions.put(pos, new Point(x, y));
        }
        
        // 底部点（15-20）- 从左到右，共6个点（包含15和20两个拐角点）
        for (int i = 0; i < 6; i++) {
            int pos = 15 + i;
            int x = bottomLeftX + i * gridSize;
            int y = bottomLeftY;
            scaledPositions.put(pos, new Point(x, y));
        }
        
        // 右侧点（20-5）- 从下到上，共6个点（包含20和5两个拐角点）
        for (int i = 0; i < 6; i++) {
            int pos;
            if (i == 0) {
                pos = 20; // 右下角点
            } else {
                pos = i; // 1,2,3,4,5
            }
            int x = topRightX;
            int y = bottomRightY - i * gridSize;
            scaledPositions.put(pos, new Point(x, y));
        }
        
        // 中心点 - 使用23作为中心点
        scaledPositions.put(23, new Point(centerX, centerY));
        
        // 第一条对角线 - 右上到左下 (5-21-22-23-24-25-15)
        Point pos5 = scaledPositions.get(5);
        Point pos15 = scaledPositions.get(15);
        
        // 计算5到23之间的点
        scaledPositions.put(21, new Point(
            pos5.x - (pos5.x - centerX) / 3,
            pos5.y + (centerY - pos5.y) / 3
        ));
        
        // 位置22 - 在21和23之间
        scaledPositions.put(22, new Point(
            pos5.x - (pos5.x - centerX) * 2 / 3,
            pos5.y + (centerY - pos5.y) * 2 / 3
        ));
        
        // 计算23到15之间的点
        scaledPositions.put(24, new Point(
            centerX - (centerX - pos15.x) / 3,
            centerY + (pos15.y - centerY) / 3
        ));
        
        // 添加25点 - 在24和15之间
        scaledPositions.put(25, new Point(
            centerX - (centerX - pos15.x) * 2 / 3,
            centerY + (pos15.y - centerY) * 2 / 3
        ));

        // 第二条对角线 - 左上到右下 (10-26-27-23-28-29-20)
        Point pos10 = scaledPositions.get(10);
        Point pos20 = scaledPositions.get(20);
        
        // 计算10到23之间的点
        scaledPositions.put(26, new Point(
            pos10.x + (centerX - pos10.x) / 3,
            pos10.y + (centerY - pos10.y) / 3
        ));
        
        // 添加27点，在26和23之间
        scaledPositions.put(27, new Point(
            pos10.x + (centerX - pos10.x) * 2 / 3,
            pos10.y + (centerY - pos10.y) * 2 / 3
        ));
        
        // 计算23到20之间的点
        scaledPositions.put(28, new Point(
            centerX + (pos20.x - centerX) / 3,
            centerY + (pos20.y - centerY) / 3
        ));
        
        scaledPositions.put(29, new Point(
            centerX + (pos20.x - centerX) * 2 / 3,
            centerY + (pos20.y - centerY) * 2 / 3
        ));
    }
    
    /**
     * 绘制路径连线
     */
    private void drawPaths(Graphics2D g2d) {
        // 绘制主路径（棕色）
        g2d.setColor(new Color(139, 69, 19));
        g2d.setStroke(new BasicStroke(3f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
        
        // 主路径连接 - 顺时针绘制外围路径
        // 连接顶部 5->6->7->8->9->10
        for (int i = 5; i <= 9; i++) {
            drawPathSegment(g2d, i, i+1);
        }
        
        // 连接左侧 10->11->12->13->14->15
        for (int i = 10; i <= 14; i++) {
            drawPathSegment(g2d, i, i+1);
        }
        
        // 连接底部 15->16->17->18->19->20
        for (int i = 15; i <= 19; i++) {
            drawPathSegment(g2d, i, i+1);
        }
        
        // 连接右侧 20->1->2->3->4->5
        drawPathSegment(g2d, 20, 1);
        for (int i = 1; i <= 4; i++) {
            drawPathSegment(g2d, i, i+1);
        }
        
        // 绘制第一条对角线路径（红色） - 5 -> 21 -> 22 -> 23 -> 24 -> 25 -> 15
        g2d.setColor(new Color(200, 0, 0));
        g2d.setStroke(new BasicStroke(2.5f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
        
        drawPathSegment(g2d, 5, 21);
        drawPathSegment(g2d, 21, 22);
        drawPathSegment(g2d, 22, 23);
        drawPathSegment(g2d, 23, 24);
        drawPathSegment(g2d, 24, 25);
        drawPathSegment(g2d, 25, 15);
        
        // 绘制第二条对角线路径（蓝色） - 10 -> 26 -> 27 -> 23 -> 28 -> 29 -> 20
        g2d.setColor(new Color(0, 100, 200));
        g2d.setStroke(new BasicStroke(2.5f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
        
        drawPathSegment(g2d, 10, 26);
        drawPathSegment(g2d, 26, 27);
        drawPathSegment(g2d, 27, 23);
        drawPathSegment(g2d, 23, 28);
        drawPathSegment(g2d, 28, 29);
        drawPathSegment(g2d, 29, 20);
    }
    
    /**
     * 绘制路径线段
     */
    private void drawPathSegment(Graphics2D g2d, int from, int to) {
        Point start = scaledPositions.get(from);
        Point end = scaledPositions.get(to);
        
        if (start != null && end != null) {
            // 对于涉及位置22的连接，使用更粗的线条
            if (from == 22 || to == 22) {
                Stroke originalStroke = g2d.getStroke();
                g2d.setStroke(new BasicStroke(3.5f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
                g2d.drawLine(start.x, start.y, end.x, end.y);
                g2d.setStroke(originalStroke);
            } else {
                g2d.drawLine(start.x, start.y, end.x, end.y);
            }
            
            // 绘制箭头
            drawArrow(g2d, start.x, start.y, end.x, end.y);
        }
    }
    
    /**
     * 绘制箭头
     */
    private void drawArrow(Graphics2D g2d, int x1, int y1, int x2, int y2) {
        double angle = Math.atan2(y2 - y1, x2 - x1);
        int arrowSize = 6;
        
        // 箭头点1
        int ax1 = (int)(x2 - arrowSize * Math.cos(angle - Math.PI/6));
        int ay1 = (int)(y2 - arrowSize * Math.sin(angle - Math.PI/6));
        
        // 箭头点2
        int ax2 = (int)(x2 - arrowSize * Math.cos(angle + Math.PI/6));
        int ay2 = (int)(y2 - arrowSize * Math.sin(angle + Math.PI/6));
        
        // 绘制箭头
        g2d.drawLine(x2, y2, ax1, ay1);
        g2d.drawLine(x2, y2, ax2, ay2);
    }
    
    /**
     * 绘制棋盘上的位置点
     */
    private void drawPosition(Graphics2D g2d, int x, int y, int position, boolean isCorner) {
        // 调整位置大小
        int size = POSITION_SIZE;
        Color fillColor;
        Color borderColor;
        float borderThickness = 1.5f;
        
        // 根据位置类型设置不同的显示样式
        if (position == 22) {
            // 位置22更醒目，用黄色，加大尺寸
            size = POSITION_SIZE + 10;
            fillColor = Color.YELLOW;
            borderColor = Color.ORANGE;
            borderThickness = 2.5f;
        } else if (position == 23) {
            // 中心点用淡紫色
            size = POSITION_SIZE + 5;
            fillColor = new Color(210, 180, 250);
            borderColor = new Color(160, 130, 200);
            borderThickness = 2.0f;
        } else if (isCorner) { 
            // 角落位置（5,10,15,20）用浅蓝色
            size = POSITION_SIZE + 3;
            fillColor = new Color(180, 210, 250);
            borderColor = new Color(100, 150, 200);
        } else if (position >= 21 && position <= 29) {
            // 对角线路径用浅紫色
            fillColor = new Color(240, 220, 250);
            borderColor = new Color(200, 180, 210);
        } else {
            // 主路径用浅灰色
            fillColor = new Color(240, 240, 240);
            borderColor = new Color(180, 180, 180);
        }
        
        // 绘制位置圆形背景
        g2d.setColor(fillColor);
        g2d.fillOval(x - size/2, y - size/2, size, size);
        
        // 绘制边框
        g2d.setStroke(new BasicStroke(borderThickness));
        g2d.setColor(borderColor);
        g2d.drawOval(x - size/2, y - size/2, size, size);
        
        // 绘制位置编号
        g2d.setColor(Color.BLACK);
        g2d.setFont(new Font("Arial", Font.BOLD, 16));
        String posText = String.valueOf(position);
        FontMetrics metrics = g2d.getFontMetrics();
        int textWidth = metrics.stringWidth(posText);
        int textHeight = metrics.getHeight();
        g2d.drawString(posText, x - textWidth/2, y + textHeight/4);
        
        // 如果是当前玩家可选择的位置，添加高亮边框
        List<Piece> pieces = game.getPiecesAtPosition(position);
        Player currentPlayer = game.getCurrentPlayer();
        boolean isCurrentPlayerPiece = false;
        
        for (Piece piece : pieces) {
            if (piece.getOwner() == currentPlayer && game.hasRolled()) {
                isCurrentPlayerPiece = true;
                break;
            }
        }
        
        if (isCurrentPlayerPiece) {
            g2d.setColor(currentPlayer.getColor());
            g2d.setStroke(new BasicStroke(3.0f));
            g2d.drawOval(x - size/2 - 5, y - size/2 - 5, size + 10, size + 10);
        }
    }
    
    /**
     * 绘制棋子
     */
    private void drawPieces(Graphics2D g2d) {
        // 获取所有玩家
        List<Player> players = game.getPlayers();
        
        // 防止过度重绘导致性能问题的标志
        if (isDrawingPieces) {
            return;
        }
        
        try {
            isDrawingPieces = true;
            // 绘制所有棋子
            for (Player player : players) {
                // 设置玩家颜色
                Color playerColor = player.getColor();
                
                // 获取玩家的所有棋子
                List<Piece> pieces = player.getPieces();
                
                // 绘制每个棋子
                for (Piece piece : pieces) {
                    // 获取棋子位置
                    int position = piece.getPosition();
                    
                    // 如果棋子在棋盘上（不在家里也没有结束）
                    if (position >= 0 && position <= 29) {
                        Point pos = scaledPositions.get(position);
                        if (pos != null) {
                            drawPiece(g2d, pos.x, pos.y, piece.getId(), playerColor);
                        }
                    }
                }
            }
        } finally {
            isDrawingPieces = false;
        }
    }
    
    /**
     * 绘制单个棋子
     */
    private void drawPiece(Graphics2D g2d, int x, int y, int pieceId, Color color) {
        // 移除所有调试输出语句，提高性能
        
        // 保存原始设置
        Composite originalComposite = g2d.getComposite();
        Stroke originalStroke = g2d.getStroke();
        
        // 绘制棋子底色
        g2d.setColor(color);
        g2d.fillOval(x - PIECE_SIZE/2, y - PIECE_SIZE/2, PIECE_SIZE, PIECE_SIZE);
        
        // 添加光泽效果
        Paint originalPaint = g2d.getPaint();
        GradientPaint gradient = new GradientPaint(
            x - PIECE_SIZE/4, y - PIECE_SIZE/4, new Color(255, 255, 255, 180),
            x + PIECE_SIZE/4, y + PIECE_SIZE/4, new Color(255, 255, 255, 0)
        );
        g2d.setPaint(gradient);
        g2d.fillOval(x - PIECE_SIZE/2, y - PIECE_SIZE/2, PIECE_SIZE, PIECE_SIZE);
        g2d.setPaint(originalPaint);
        
        // 绘制棋子边框
        g2d.setStroke(new BasicStroke(2.0f));
        g2d.setColor(new Color(0, 0, 0, 100));
        g2d.drawOval(x - PIECE_SIZE/2, y - PIECE_SIZE/2, PIECE_SIZE, PIECE_SIZE);
        
        // 绘制棋子编号
        g2d.setColor(Color.WHITE);
        g2d.setFont(new Font("Arial", Font.BOLD, 14));
        String idStr = String.valueOf(pieceId + 1);
        FontMetrics fm = g2d.getFontMetrics();
        int textWidth = fm.stringWidth(idStr);
        
        // 创建白色圆形背景
        int textSize = 16;
        g2d.setColor(new Color(0, 0, 0, 80));
        g2d.fillOval(x - textSize/2, y - textSize/2, textSize, textSize);
        
        // 绘制文本
        g2d.setColor(Color.WHITE);
        g2d.drawString(idStr, x - textWidth/2, y + fm.getAscent()/2 - 1);
        
        // 恢复原始设置
        g2d.setComposite(originalComposite);
        g2d.setStroke(originalStroke);
    }
    
    /**
     * 获取Game对象
     */
    public Game getGame() {
        return game;
    }
} 