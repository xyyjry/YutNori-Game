package com.xingyang.yutnori.model;

import java.awt.Point;
import java.util.HashMap;
import java.util.Map;
import com.xingyang.yutnori.model.YutSet;

/**
 * Represents the game board in the Yut game.
 * Defines the positions and paths for moving pieces.
 */
public class Board {
    // Board positions
    private Map<Integer, Point> positions;
    
    // Path type enum
    public enum PathType {
        MAIN_PATH,       // Main circular path
        DIAGONAL_LEFT,   // Left diagonal path
        DIAGONAL_RIGHT,  // Right diagonal path
        CORNER_PATH,     // Corner shortcut path
        CENTER_PATH      // Center path
    }
    
    // Path mappings for different path types
    private Map<PathType, Map<Integer, Integer>> pathMaps;
    
    // Special path mappings for shortcuts
    private Map<Integer, Integer> specialPaths;
    
    // Normal direct paths for standard movement
    private Map<Integer, Integer> mainPathDirections;
    
    // Reverse direction mappings for BackDo movement
    private Map<Integer, Integer> reverseDirections;
    
    // Add class field for tracking diagonal path
    private boolean cameFromPosition5Diagonal = false;
    
    // 添加全局调试标志
    private static final boolean DEBUG = false;
    
    /**
     * Constructs and initializes the game board.
     * Sets up the positions and special paths.
     */
    public Board() {
        initializePositions();
        initializePaths();
        initializeSpecialPaths();
        initializeMainPathDirections();
    }
    
    /**
     * Initializes the positions on the board.
     * Each position is mapped to a coordinate for display.
     */
    private void initializePositions() {
        positions = new HashMap<>();
        
        // Board size and margins
        int boardSize = 800;
        int margin = 100;
        int gameArea = boardSize - (2 * margin);
        int step = gameArea / 5;  // Back to 5 steps to maintain original size
        
        // Base coordinates
        int baseX = margin;
        int baseY = margin;
        
        // Top row - right to left (5->10)
        positions.put(5, new Point(baseX + 5*step, baseY));          // Top right
        positions.put(6, new Point(baseX + 4*step, baseY));
        positions.put(7, new Point(baseX + 3*step, baseY));
        positions.put(8, new Point(baseX + 2*step, baseY));
        positions.put(9, new Point(baseX + step, baseY));
        positions.put(10, new Point(baseX, baseY));                  // Top left
        
        // Right side - top to bottom (5->20)
        positions.put(4, new Point(baseX + 5*step, baseY + step));
        positions.put(3, new Point(baseX + 5*step, baseY + 2*step));
        positions.put(2, new Point(baseX + 5*step, baseY + 3*step));
        positions.put(1, new Point(baseX + 5*step, baseY + 4*step));  // Remove the horizontal offset to align with positions 20 and 5
        positions.put(20, new Point(baseX + 5*step, baseY + 5*step)); // Bottom right
        
        // Left side - top to bottom (10->15)
        positions.put(11, new Point(baseX, baseY + step));
        positions.put(12, new Point(baseX, baseY + 2*step));
        positions.put(13, new Point(baseX, baseY + 3*step));
        positions.put(14, new Point(baseX, baseY + 4*step));
        positions.put(15, new Point(baseX, baseY + 5*step));        // Bottom left
        
        // Bottom row - left to right (15->20)
        positions.put(16, new Point(baseX + step, baseY + 5*step));
        positions.put(17, new Point(baseX + 2*step, baseY + 5*step));
        positions.put(18, new Point(baseX + 3*step, baseY + 5*step));
        positions.put(19, new Point(baseX + 4*step, baseY + 5*step));
        
        // Center point (23) - Made larger like previous position 24
        positions.put(23, new Point(baseX + (5*step)/2, baseY + (5*step)/2));
        
        // First diagonal path: 10 -> 26 -> 27 -> 23 -> 28 -> 29 -> 20
        positions.put(26, new Point(
            baseX + step,
            baseY + step
        ));
        positions.put(27, new Point(
            baseX + 2*step,
            baseY + 2*step
        ));
        positions.put(28, new Point(
            baseX + 3*step,
            baseY + 3*step
        ));
        positions.put(29, new Point(
            baseX + 4*step,
            baseY + 4*step
        ));
        
        // Second diagonal path: 15 -> 25 -> 24 -> 23 -> 22 -> 21 -> 5
        positions.put(25, new Point(
            baseX + step,
            baseY + 4*step
        ));
        positions.put(24, new Point(
            baseX + 2*step,
            baseY + 3*step
        ));
        positions.put(22, new Point(
            baseX + 3*step,
            baseY + 2*step
        ));
        positions.put(21, new Point(
            baseX + 4*step + 10,  // 向右偏移10个像素
            baseY + step - 10     // 向上偏移10个像素
        ));
        
        // Goal position (30) - slightly offset from position 20
        positions.put(30, new Point(
            baseX + (int)(5.5*step),
            baseY + (int)(5.5*step)
        ));
    }
    
    /**
     * Initializes the paths on the board.
     */
    private void initializePaths() {
        pathMaps = new HashMap<>();
        
        // Initialize main path
        Map<Integer, Integer> mainPath = new HashMap<>();
        mainPath.put(-1, 1);    // From home to start
        mainPath.put(1, 2);
        mainPath.put(2, 3);
        mainPath.put(3, 4);
        mainPath.put(4, 5);
        mainPath.put(5, 6);     // Junction point - can go straight or diagonal
        mainPath.put(6, 7);
        mainPath.put(7, 8);
        mainPath.put(8, 9);
        mainPath.put(9, 10);
        mainPath.put(10, 11);   // Junction point
        mainPath.put(11, 12);
        mainPath.put(12, 13);
        mainPath.put(13, 14);
        mainPath.put(14, 15);
        mainPath.put(15, 16);   // Junction point
        mainPath.put(16, 17);
        mainPath.put(17, 18);
        mainPath.put(18, 19);
        mainPath.put(19, 20);
        mainPath.put(20, 1);    // Complete circuit
        // Add direct path from position 20 to position 5 (for visual straight line)
        mainPath.put(20, 5);    // Direct vertical connection
        pathMaps.put(PathType.MAIN_PATH, mainPath);
        
        // Initialize right diagonal path (from position 5)
        Map<Integer, Integer> diagonalRight = new HashMap<>();
        diagonalRight.put(5, 21);   // Start of right diagonal
        diagonalRight.put(21, 22);
        diagonalRight.put(22, 23);  // 确保这个映射存在
        diagonalRight.put(23, 24);  // 确保这个映射存在
        diagonalRight.put(24, 25);
        // 修正: 将 25->15 的连接从右对角线移除，改为左对角线的一部分
        pathMaps.put(PathType.DIAGONAL_RIGHT, diagonalRight);
        
        // 打印右对角线路径映射，调试使用
        System.out.println("Right Diagonal Path Mappings:");
        diagonalRight.forEach((from, to) -> 
            System.out.println("From " + from + " to " + to));
        
        // Initialize left diagonal path (from position 10)
        Map<Integer, Integer> diagonalLeft = new HashMap<>();
        diagonalLeft.put(10, 26);   // Start of left diagonal
        diagonalLeft.put(26, 27);
        diagonalLeft.put(27, 23);   // Connects to center
        diagonalLeft.put(23, 28);
        diagonalLeft.put(28, 29);
        diagonalLeft.put(29, 20);   // Connect back to main path
        // 添加新的连接: 从位置15到25的左对角线路径
        diagonalLeft.put(15, 25);
        // 添加新的连接: 从位置25到15的左对角线返回路径
        diagonalLeft.put(25, 15);
        pathMaps.put(PathType.DIAGONAL_LEFT, diagonalLeft);
        
        // 打印左对角线路径映射，调试使用
        System.out.println("Left Diagonal Path Mappings:");
        diagonalLeft.forEach((from, to) -> 
            System.out.println("From " + from + " to " + to));
        
        // Initialize reverse directions for BackDo
        reverseDirections = new HashMap<>();
        for (Map.Entry<Integer, Integer> entry : mainPath.entrySet()) {
            if (entry.getKey() != -1) {  // Skip home position
                reverseDirections.put(entry.getValue(), entry.getKey());
            }
        }
        for (Map.Entry<Integer, Integer> entry : diagonalRight.entrySet()) {
            reverseDirections.put(entry.getValue(), entry.getKey());
        }
        for (Map.Entry<Integer, Integer> entry : diagonalLeft.entrySet()) {
            reverseDirections.put(entry.getValue(), entry.getKey());
        }
    }
    
    /**
     * Initializes the special paths on the board.
     */
    private void initializeSpecialPaths() {
        specialPaths = new HashMap<>();
        
        // Main circle path (clockwise from 20)
        specialPaths.put(-1, 20);  // From home to start
        specialPaths.put(20, 1);   // 20 -> 1
        specialPaths.put(1, 2);
        specialPaths.put(2, 3);
        specialPaths.put(3, 4);
        specialPaths.put(4, 5);
        specialPaths.put(5, 6);
        specialPaths.put(6, 7);
        specialPaths.put(7, 8);
        specialPaths.put(8, 9);
        specialPaths.put(9, 10);
        specialPaths.put(10, 11);
        specialPaths.put(11, 12);
        specialPaths.put(12, 13);
        specialPaths.put(13, 14);
        specialPaths.put(14, 15);
        specialPaths.put(15, 16);
        specialPaths.put(16, 17);
        specialPaths.put(17, 18);
        specialPaths.put(18, 19);
        specialPaths.put(19, 20);  // Back to start/end
    }
    
    /**
     * Initializes the normal path mappings for standard movement
     */
    private void initializeMainPathDirections() {
        mainPathDirections = new HashMap<>();
        
        // Main circle path (clockwise from 20)
        mainPathDirections.put(-1, 1);    // From home to start position
        mainPathDirections.put(1, 2);     // 1 -> 2
        mainPathDirections.put(2, 3);     // 2 -> 3
        mainPathDirections.put(3, 4);     // 3 -> 4
        mainPathDirections.put(4, 5);     // 4 -> 5
        mainPathDirections.put(5, 6);     // 5 -> 6
        mainPathDirections.put(6, 7);     // 6 -> 7
        mainPathDirections.put(7, 8);     // 7 -> 8
        mainPathDirections.put(8, 9);     // 8 -> 9
        mainPathDirections.put(9, 10);    // 9 -> 10
        mainPathDirections.put(10, 11);   // 10 -> 11
        mainPathDirections.put(11, 12);   // 11 -> 12
        mainPathDirections.put(12, 13);   // 12 -> 13
        mainPathDirections.put(13, 14);   // 13 -> 14
        mainPathDirections.put(14, 15);   // 14 -> 15
        mainPathDirections.put(15, 16);   // 15 -> 16
        mainPathDirections.put(16, 17);   // 16 -> 17
        mainPathDirections.put(17, 18);   // 17 -> 18
        mainPathDirections.put(18, 19);   // 18 -> 19
        mainPathDirections.put(19, 20);   // 19 -> 20
        mainPathDirections.put(20, 1);    // 20 -> 1 (complete circuit)
        
        // Print out all paths for debugging
        System.out.println("=== Main Path Directions ===");
        mainPathDirections.forEach((from, to) -> 
            System.out.println("From " + from + " to " + to));
    }
    
    /**
     * Gets the path map for a specific path type
     */
    public Map<Integer, Integer> getPathMap(PathType type) {
        return pathMaps.get(type);
    }
    
    /**
     * Gets the next position after moving a specified number of steps.
     * 
     * @param currentPosition The current position
     * @param roll The number of steps to move (can be negative for BackDo)
     * @return The next position
     */
    public int getNextPosition(int currentPosition, int roll) {
        if (DEBUG) {
            System.out.println("Getting next position: from " + currentPosition + " moving " + roll + " steps");
        }
        
        // Invalid roll, maintain current position
        if (roll == 0) {
            return currentPosition;
        }
        
        // Handle BackDo (backward movement) special case
        if (roll == YutSet.BACKDO) {
            // Cannot move backward from home
            if (currentPosition == -1) {
                if (DEBUG) {
                    System.out.println("Cannot move backward from home position");
                }
                return currentPosition;
            }
            
            // Use reverse directions map for backward movement
            Integer backPos = reverseDirections.get(currentPosition);
            
            // 特殊处理位置1向后移动的情况
            if (currentPosition == 1) {
                backPos = 20;  // 从位置1向后移动应该到达位置20
            }
            
            // 특수路径位置的反向处理
            if (backPos == null) {
                // 尝试确定当前位置在哪条特殊路径上
                // 对角线左路径: 26, 27, 23, 28, 29
                // 对角线右路径: 21, 22, 23, 24, 25
                
                if (currentPosition == 23) {
                    // 中心位置特殊处理，可能来自多个路径
                    // 默认返回位置27(左对角线路径)
                    backPos = 27;
                } else if (currentPosition >= 26 && currentPosition <= 29) {
                    // 左对角线路径
                    if (currentPosition == 26) return 10;  // 回到起点
                    else if (currentPosition == 27) return 26;
                    else if (currentPosition == 28) return 23;
                    else if (currentPosition == 29) return 28;
                } else if (currentPosition >= 21 && currentPosition <= 25) {
                    // 右对角线路径
                    if (currentPosition == 21) return 5;   // 回到起点
                    else if (currentPosition == 22) return 21;
                    else if (currentPosition == 24) return 23;
                    else if (currentPosition == 25) return 24;
                }
            }
            
            if (backPos != null) {
                if (DEBUG) {
                    System.out.println("Backward movement from " + currentPosition + " to " + backPos);
                }
                return backPos;
            }
            return currentPosition;
        }
        
        if (currentPosition == -1) {
            // 修复问题：骰子点数为1时应该只到达位置1
            if (roll == 1) {
                return 1;  // 骰子为1，直接返回位置1
            }
            
            int nextPos = 1;  // Start from position 1
            System.out.println("Starting from home, moving through positions:");
            System.out.println("0: position " + nextPos);
            
            // Move the full number of steps
            for (int i = 1; i < roll; i++) {
                Integer next = mainPathDirections.get(nextPos);
                if (next == null) {
                    System.out.println("Error: No next position found from " + nextPos);
                    break;
                }
                nextPos = next;
                System.out.println(i + ": position " + nextPos);
            }
            
            System.out.println("Final position from home: " + nextPos);
            return nextPos;
        }
        
        int currentPos = currentPosition;
        int stepsLeft = roll;
        PathType currentPath = PathType.MAIN_PATH;
        boolean passedPosition20 = false;
        boolean startedFromPosition1orHigher = currentPos >= 1; // Check if we started from position 1 or higher
        
        System.out.println("Starting movement from position " + currentPos + 
                         " with " + stepsLeft + " steps on path " + currentPath);
        
        // 특殊处理对角线路径位置
        if (currentPos >= 21 && currentPos <= 25) {
            // 在右对角线路径上，使用对角线路径计算
            currentPath = PathType.DIAGONAL_RIGHT;
        } else if (currentPos >= 26 && currentPos <= 29) {
            // 在左对角线路径上，使用左对角线路径计算
            currentPath = PathType.DIAGONAL_LEFT;
        }
        
        // 对于在对角线路径上的位置，使用特定路径的逻辑
        if (currentPath == PathType.DIAGONAL_RIGHT || currentPath == PathType.DIAGONAL_LEFT) {
            Map<Integer, Integer> pathMap = pathMaps.get(currentPath);
            for (int i = 0; i < stepsLeft; i++) {
                if (pathMap.containsKey(currentPos)) {
                    currentPos = pathMap.get(currentPos);
                } else {
                    System.out.println("No valid next position found from " + currentPos);
                    break;
                }
            }
            return currentPos;
        }
        
        // 常规的路径移动逻辑
        for (int i = 0; i < stepsLeft; i++) {
            if (mainPathDirections.containsKey(currentPos)) {
                int prevPos = currentPos;
                currentPos = mainPathDirections.get(currentPos);
                
                // 检测是否经过了位置20
                if (prevPos == 19 && currentPos == 20) {
                    passedPosition20 = true;
                }
                // 如果从位置20继续移动到位置1，也视为经过了一圈
                else if (prevPos == 20 && currentPos == 1 && startedFromPosition1orHigher) {
                    passedPosition20 = true;
                    System.out.println("Passed position 20 and continuing to position 1 - completing circuit");
                }
            } else {
                // 处理特殊路径
                System.out.println("No valid next position found from " + currentPos);
                break;
            }
        }
        
        // 修改完成条件:
        // 1. 如果棋子到达位置20且之前从位置1或更高位置开始移动，标记为完成
        // 2. 如果棋子经过位置20并且完成了一圈，标记为完成
        if (currentPos == 20 && startedFromPosition1orHigher) {
            System.out.println("Piece completed a circuit and landed on position 20, marking as finished");
            return 30;  // 30表示完成
        }
        
        // 如果棋子经过位置20并继续移动(即现在在位置1-19)，也标记为完成
        if (passedPosition20 && currentPos >= 1 && currentPos <= 19 && startedFromPosition1orHigher) {
            System.out.println("Piece passed position 20 after completing a circuit, marking as finished");
            return 30;  // 30表示完成
        }
        
        return currentPos;
    }
    
    private int getPreviousPosition(int currentPosition) {
        if (currentPosition == 0) return 19;
        
        // Check if on a special path
        for (Map.Entry<Integer, Integer> entry : specialPaths.entrySet()) {
            if (entry.getValue() == currentPosition) {
                return entry.getKey();
            }
        }
        
        return currentPosition - 1;
    }
    
    /**
     * Gets the coordinate for a position on the board.
     * 
     * @param position The position to get coordinates for
     * @return The coordinates, or null if position is invalid
     */
    public Point getCoordinate(int position) {
        // Special validation for positions 8 and 9 which were potentially problematic
        if (position == 8 || position == 9) {
            Point result = positions.get(position);
            if (DEBUG) {
                System.out.println("Getting coordinates for special position: " + position);
                if (result != null) {
                    System.out.println("  Position " + position + " coordinates: (" + result.x + "," + result.y + ")");
                } else {
                    System.out.println("  ERROR: No coordinates found for position " + position);
                }
            }
            return result;
        }
        
        Point result = positions.get(position);
        if (result == null && DEBUG) {
            System.out.println("Warning: No coordinate found for position " + position);
        }
        return result;
    }
    
    public boolean isCorner(int position) {
        return position == 0 || position == 5 || position == 10 || 
               position == 15 || position == 20 || position == 23;
    }
    
    public boolean hasShortcut(int position) {
        return specialPaths.containsKey(position);
    }
    
    public int getShortcutDestination(int position) {
        return specialPaths.getOrDefault(position, -1);
    }
    
    public Map<Integer, Point> getPositions() {
        return positions;
    }
    
    /**
     * 检查位置是否是交叉路口（可以选择不同路径）
     * 位置5、10、15、20和23是特殊路口
     */
    public boolean isJunction(int position) {
        return position == 5 || position == 10 || position == 15 || position == 20 || position == 23;
    }

    /**
     * 根据指定路径类型，计算下一个位置
     */
    public int getNextPositionWithPath(int currentPos, int roll, PathType pathType) {
        // 减少日志输出，提高性能
        System.out.println("getNextPositionWithPath: position=" + currentPos + " roll=" + roll + " pathType=" + pathType);
        
        // 特殊处理家的位置
        if (currentPos == -1) {
            // 从家出发，永远沿着主路径
            return getNextPosition(currentPos, roll);
        }
        
        // 如果步数为0，直接返回当前位置
        if (roll == 0) {
            return currentPos;
        }
        
        // 如果是向后移动
        if (roll == YutSet.BACKDO) {
            int backPos = getNextPosition(currentPos, YutSet.BACKDO);
            return backPos;
        }
        
        // 特殊处理位置25：如果从位置25出发，应该能够移动到位置15
        if (currentPos == 25) {
            System.out.println("特殊处理：从位置25移动，强制使用DIAGONAL_LEFT路径类型");
            // 如果是位置25，强制使用LEFT_DIAGONAL路径
            pathType = PathType.DIAGONAL_LEFT;
            
            // 如果步数为1，直接返回位置15
            if (roll == 1) {
                System.out.println("Special case: Moving from position 25 directly to position 15");
                return 15;
            }
            
            // 如果步数大于1，先移动到位置15，然后继续在主路径上移动
            System.out.println("Special case: Moving from position 25 to position 15 first, then continue on MAIN_PATH for " + (roll-1) + " steps");
            // 从位置15开始，沿主路径移动剩余步数
            int result = getNextPositionWithPath(15, roll - 1, PathType.MAIN_PATH);
            System.out.println("Final result after special move from 25: " + result);
            return result;
        }
        
        // 记录当前路径和下一个位置
        int nextPos = currentPos;
        PathType currentPath = pathType;
        
        // 遍历每一步
        for (int i = 0; i < roll; i++) {
            // 先前进一步
            Map<Integer, Integer> pathMap = pathMaps.get(currentPath);
            
            if (pathMap.containsKey(nextPos)) {
                nextPos = pathMap.get(nextPos);
                System.out.println("Step " + (i+1) + ": Moving along path " + currentPath + " to position " + nextPos);
            } else {
                // 如果在当前路径上找不到下一个位置，检查是否应该切换路径
                boolean switchedPath = false;
                
                // 如果当前位置是路口，根据指定的路径类型决定下一步
                if (isJunction(nextPos)) {
                    // 根据路口位置和指定路径类型决定下一步
                    PathType junctionPath = getJunctionPath(nextPos, pathType);
                    if (junctionPath != null) {
                        currentPath = junctionPath;
                        Map<Integer, Integer> newPathMap = pathMaps.get(currentPath);
                        if (newPathMap.containsKey(nextPos)) {
                            nextPos = newPathMap.get(nextPos);
                            switchedPath = true;
                            System.out.println("Switched path at junction to " + junctionPath + ", now at position " + nextPos);
                        }
                    }
                }
                
                if (!switchedPath) {
                    System.out.println("No valid next position found from " + nextPos + " along path " + currentPath);
                    return nextPos; // 无法继续移动
                }
            }
        }
        
        return nextPos;
    }
    
    /**
     * 根据路口位置和指定路径类型获取下一路径
     */
    private PathType getJunctionPath(int position, PathType preferredPath) {
        // 根据位置和偏好路径确定实际路径
        switch (position) {
            case 5:  // 第一个路口，可以选择主路径或右对角线
                return preferredPath == PathType.DIAGONAL_RIGHT ? PathType.DIAGONAL_RIGHT : PathType.MAIN_PATH;
                
            case 10: // 第二个路口，可以选择主路径或左对角线
                return preferredPath == PathType.DIAGONAL_LEFT ? PathType.DIAGONAL_LEFT : PathType.MAIN_PATH;
                
            case 15: // 第三个路口，可以选择主路径或左对角线
                return preferredPath == PathType.DIAGONAL_LEFT ? PathType.DIAGONAL_LEFT : PathType.MAIN_PATH;
                
            case 20: // 第四个路口，可以选择主路径或左对角线
                return preferredPath == PathType.DIAGONAL_LEFT ? PathType.DIAGONAL_LEFT : PathType.MAIN_PATH;
                
            case 21: // 对角线路径上的位置，使用右对角线路径
            case 22: // 添加对位置22的处理，使用右对角线路径
                return PathType.DIAGONAL_RIGHT;
                
            case 24: // 对角线路径上的位置，使用右对角线路径
                return PathType.DIAGONAL_RIGHT;
                
            case 25: // 位置25修改为使用左对角线路径，强制返回位置15
                return PathType.DIAGONAL_LEFT;
                
            case 26: // 对角线路径上的位置，使用左对角线路径
            case 27: // 对角线路径上的位置，使用左对角线路径
                return PathType.DIAGONAL_LEFT;
                
            case 28: // 对角线路径上的位置，使用左对角线路径
            case 29: // 对角线路径上的位置，使用左对角线路径
                return PathType.DIAGONAL_LEFT;
                
            case 23: // 中心点，可以根据偏好选择不同路径
                if (preferredPath == PathType.DIAGONAL_RIGHT) return PathType.DIAGONAL_RIGHT;
                if (preferredPath == PathType.DIAGONAL_LEFT) return PathType.DIAGONAL_LEFT;
                return PathType.CENTER_PATH;
                
            default:
                return PathType.MAIN_PATH;  // 默认使用主路径
        }
    }

    /**
     * Gets available paths from a junction position with previous position context
     * @param position The current position
     * @param previousPosition The position we came from
     * @return Map of path type to next position
     */
    public Map<PathType, Integer> getAvailablePaths(int position, int previousPosition) {
        Map<PathType, Integer> availablePaths = new HashMap<>();
        
        // Position 10 and 23 special handling to prevent duplicate path selection
        if (position == 10) {
            // 10号位置只提供一个选择：根据来源选择继续的路径
            if (previousPosition == 9) {
                // 从主路径9到达10，继续走主路径
                Map<Integer, Integer> mainPath = pathMaps.get(PathType.MAIN_PATH);
                if (mainPath.containsKey(position)) {
                    availablePaths.put(PathType.MAIN_PATH, mainPath.get(position));
                }
            } else if (previousPosition == 26) {
                // 从左对角线路径26到达10，继续走左对角线
                Map<Integer, Integer> leftDiagonal = pathMaps.get(PathType.DIAGONAL_LEFT);
                if (leftDiagonal.containsKey(position)) {
                    availablePaths.put(PathType.DIAGONAL_LEFT, leftDiagonal.get(position));
                }
            } else {
                // 对于其他情况（如从家出发到达10），提供所有选项
                // 先提供主路径选项
                Map<Integer, Integer> mainPath = pathMaps.get(PathType.MAIN_PATH);
                if (mainPath.containsKey(position)) {
                    availablePaths.put(PathType.MAIN_PATH, mainPath.get(position));
                }
                
                // 再提供左对角线选项
                Map<Integer, Integer> leftDiagonal = pathMaps.get(PathType.DIAGONAL_LEFT);
                if (leftDiagonal.containsKey(position)) {
                    availablePaths.put(PathType.DIAGONAL_LEFT, leftDiagonal.get(position));
                }
            }
            return availablePaths;
        }
        
        if (position == 23) {
            // 23号位置中心点处理，根据来源选择继续的路径
            if (previousPosition == 22) {
                // 从右对角线到达23，继续走右对角线
                Map<Integer, Integer> rightDiagonal = pathMaps.get(PathType.DIAGONAL_RIGHT);
                if (rightDiagonal.containsKey(position)) {
                    availablePaths.put(PathType.DIAGONAL_RIGHT, rightDiagonal.get(position));
                }
            } else if (previousPosition == 27) {
                // 从左对角线到达23，继续走左对角线
                Map<Integer, Integer> leftDiagonal = pathMaps.get(PathType.DIAGONAL_LEFT);
                if (leftDiagonal.containsKey(position)) {
                    availablePaths.put(PathType.DIAGONAL_LEFT, leftDiagonal.get(position));
                }
            } else {
                // 对于其他情况，提供两个选项
                Map<Integer, Integer> leftDiagonal = pathMaps.get(PathType.DIAGONAL_LEFT);
                Map<Integer, Integer> rightDiagonal = pathMaps.get(PathType.DIAGONAL_RIGHT);
                
                if (leftDiagonal.containsKey(position)) {
                    availablePaths.put(PathType.DIAGONAL_LEFT, leftDiagonal.get(position));
                }
                if (rightDiagonal.containsKey(position)) {
                    availablePaths.put(PathType.DIAGONAL_RIGHT, rightDiagonal.get(position));
                }
            }
            return availablePaths;
        }
        
        // 其他位置使用原有的方法
        return getAvailablePaths(position);
    }

    /**
     * Gets available paths from a junction position (overloaded version for backward compatibility)
     * @param position The current position
     * @return Map of path type to next position, empty if not a junction
     */
    public Map<PathType, Integer> getAvailablePaths(int position) {
        Map<PathType, Integer> availablePaths = new HashMap<>();
        
        // Always check main path first
        Map<Integer, Integer> mainPath = pathMaps.get(PathType.MAIN_PATH);
        if (mainPath.containsKey(position)) {
            availablePaths.put(PathType.MAIN_PATH, mainPath.get(position));
        }
        
        // Check for diagonal paths at junctions
        if (position == 5) {
            // At position 5 - can go main path (5->6) or right diagonal (5->21)
            Map<Integer, Integer> rightDiagonal = pathMaps.get(PathType.DIAGONAL_RIGHT);
            if (rightDiagonal.containsKey(position)) {
                availablePaths.put(PathType.DIAGONAL_RIGHT, rightDiagonal.get(position));
            }
        } else if (position == 10) {
            // At position 10 - can go main path (10->11) or left diagonal (10->26)
            Map<Integer, Integer> leftDiagonal = pathMaps.get(PathType.DIAGONAL_LEFT);
            if (leftDiagonal.containsKey(position)) {
                availablePaths.put(PathType.DIAGONAL_LEFT, leftDiagonal.get(position));
            }
        } else if (position == 15) {
            // At position 15 - can go main path (15->16) or left diagonal (15->25)
            Map<Integer, Integer> leftDiagonal = pathMaps.get(PathType.DIAGONAL_LEFT);
            if (leftDiagonal.containsKey(position)) {
                availablePaths.put(PathType.DIAGONAL_LEFT, leftDiagonal.get(position));
            } else {
                // 在初始化的路径中可能没有设置，这里手动添加一个路径选项
                availablePaths.put(PathType.DIAGONAL_LEFT, 25);
                System.out.println("Adding manual left diagonal path option for position 15 -> 25");
            }
        } else if (position == 22) {
            // At position 22 - can continue on right diagonal path (22->23)
            Map<Integer, Integer> rightDiagonal = pathMaps.get(PathType.DIAGONAL_RIGHT);
            if (rightDiagonal.containsKey(position)) {
                availablePaths.put(PathType.DIAGONAL_RIGHT, rightDiagonal.get(position));
            }
        } else if (position == 23) {
            // At center - can go different directions
            Map<Integer, Integer> leftDiagonal = pathMaps.get(PathType.DIAGONAL_LEFT);
            Map<Integer, Integer> rightDiagonal = pathMaps.get(PathType.DIAGONAL_RIGHT);
            
            if (leftDiagonal.containsKey(position)) {
                availablePaths.put(PathType.DIAGONAL_LEFT, leftDiagonal.get(position));
            }
            if (rightDiagonal.containsKey(position)) {
                availablePaths.put(PathType.DIAGONAL_RIGHT, rightDiagonal.get(position));
            }
        } else if (position == 25) {
            // At position 25 - should be able to go to position 15 via left diagonal path
            Map<Integer, Integer> leftDiagonal = pathMaps.get(PathType.DIAGONAL_LEFT);
            if (leftDiagonal.containsKey(position)) {
                availablePaths.put(PathType.DIAGONAL_LEFT, leftDiagonal.get(position));
            } else {
                // 在初始化的路径中可能没有设置，这里手动添加一个路径选项
                availablePaths.put(PathType.DIAGONAL_LEFT, 15);
                System.out.println("Adding manual left diagonal path option for position 25 -> 15");
            }
        }
        
        return availablePaths;
    }
}    