package com.xingyang.yutnori.model;

import java.awt.Color;
import java.util.ArrayList;
import java.util.List;

/**
 * Represents a player in the Yut Nori game.
 * Each player has a name, color, and a set of pieces to move around the board.
 */
public class Player {
    private String name;
    private Color color;
    private List<Piece> pieces;
    private int pieceCount = 4;  // Default number of pieces per player
    private int id;
    private boolean isFirst;
    
    /**
     * Constructs a new player with the specified name and color.
     * 
     * @param id     玩家ID
     * @param name   玩家名称
     * @param color  玩家颜色
     * @param isFirst 是否先手
     */
    public Player(int id, String name, Color color, boolean isFirst) {
        this.id = id;
        // 如果传入名称为默认的英文，则替换为韩文名称
        if (name.equals("Player 1")) {
            this.name = "플레이어 1";
        } else if (name.equals("Player 2")) {
            this.name = "플레이어 2";
        } else if (name.equals("Player 3")) {
            this.name = "플레이어 3";
        } else if (name.equals("Player 4")) {
            this.name = "플레이어 4";
        } else {
            this.name = name;
        }
        this.color = color;
        this.isFirst = isFirst;
        this.pieces = new ArrayList<>();
        initializePieces();
    }
    
    /**
     * Constructs a new player with the specified name and color.
     * 
     * @param name The player's name
     * @param color The player's color
     */
    public Player(String name, Color color) {
        // 如果传入名称为默认的英文，则替换为韩文名称
        if (name.equals("Player 1")) {
            this.name = "플레이어 1";
        } else if (name.equals("Player 2")) {
            this.name = "플레이어 2";
        } else if (name.equals("Player 3")) {
            this.name = "플레이어 3";
        } else if (name.equals("Player 4")) {
            this.name = "플레이어 4";
        } else {
            this.name = name;
        }
        this.color = color;
        this.pieces = new ArrayList<>();
        
        // Create the pieces for this player
        initializePieces();
    }
    
    /**
     * 初始化玩家的棋子
     */
    private void initializePieces() {
        for (int i = 0; i < pieceCount; i++) {
            pieces.add(new Piece(this, i));
        }
    }
    
    /**
     * Gets the player's name.
     * 
     * @return The player's name
     */
    public String getName() {
        return name;
    }
    
    /**
     * Gets the player's color.
     * 
     * @return The player's color
     */
    public Color getColor() {
        return color;
    }
    
    /**
     * Gets the player's pieces.
     * 
     * @return A list of the player's pieces
     */
    public List<Piece> getPieces() {
        return pieces;
    }
    
    /**
     * Checks if all of the player's pieces have reached the end.
     * 
     * @return True if all pieces have reached the end, false otherwise
     */
    public boolean hasFinished() {
        for (Piece piece : pieces) {
            // A piece is finished if:
            // 1. It's at position 30 (marked as completed)
            // 2. It's at position 5 after completing a circuit
            if (piece.getPosition() != 30) {
                return false;
            }
        }
        return true;
    }
    
    /**
     * Gets the count of pieces that have reached the end.
     * 
     * @return The number of pieces that have finished
     */
    public int getFinishedPieceCount() {
        int count = 0;
        for (Piece piece : pieces) {
            if (piece.getPosition() == 30) {
                count++;
            }
        }
        return count;
    }
    
    /**
     * Gets a piece that can be moved with the given roll.
     * 
     * @param roll The roll result
     * @return A piece that can be moved, or null if none can be moved
     */
    public Piece getMovablePiece(int roll) {
        for (Piece piece : pieces) {
            if (piece.getPosition() < 30) {
                return piece;
            }
        }
        return null;
    }
    
    /**
     * Resets all pieces to their starting positions.
     */
    public void resetPieces() {
        for (Piece piece : pieces) {
            piece.setPosition(-1);  // -1 represents the starting position (off board)
            piece.clearStackedPieces();
        }
    }
    
    /**
     * Gets a piece by its ID.
     * 
     * @param pieceId The ID of the piece to get
     * @return The piece with the specified ID, or null if not found
     */
    public Piece getPiece(int pieceId) {
        for (Piece piece : pieces) {
            if (piece.getId() == pieceId) {
                return piece;
            }
        }
        return null;
    }
    
    @Override
    public String toString() {
        return name;
    }
} 