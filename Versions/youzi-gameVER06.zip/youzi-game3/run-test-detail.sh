#!/bin/bash

# 确保测试类名作为参数传入
if [ $# -eq 0 ]; then
    echo "用法: ./run-test-detail.sh [测试类名]"
    echo "示例: ./run-test-detail.sh GameTest"
    exit 1
fi

TEST_CLASS=$1

# 创建输出目录
mkdir -p test-out
mkdir -p test-bin

# 编译模型类
echo "编译模型类..."
javac -d test-bin com/xingyang/yutnori/model/*.java

# 编译测试类
echo "编译测试类..."
javac -d test-bin -cp test-bin:lib/junit-4.13.2.jar:lib/hamcrest-core-1.3.jar test/com/xingyang/yutnori/*.java

# 切换到test-bin目录运行单一测试
echo "运行测试: $TEST_CLASS..."
cd test-bin

# 使用JUnit TextListener来获取更详细的输出
java -cp .:../lib/junit-4.13.2.jar:../lib/hamcrest-core-1.3.jar org.junit.runner.JUnitCore $TEST_CLASS

# 返回原目录
cd .. 