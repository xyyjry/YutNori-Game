import org.junit.Test;
import org.junit.Before;
import static org.junit.Assert.*;

import com.xingyang.yutnori.model.Board;
import com.xingyang.yutnori.model.YutSet;

import java.awt.Point;
import java.util.Map;

/**
 * 윷놀이 게임 보드 테스트 클래스
 * 보드 경로 및 이동 논리를 테스트합니다
 */
public class BoardTest {
    
    private Board board;
    
    @Before
    public void setUp() {
        // 테스트용 보드 생성
        board = new Board();
    }
    
    @Test
    public void testInitialization() {
        // 보드 초기화 테스트
        assertNotNull("보드 위치 맵은 null이 아니어야 합니다", board.getPositions());
        
        // 주요 위치 확인
        Map<Integer, Point> positions = board.getPositions();
        assertNotNull("위치 1이 존재해야 합니다", positions.get(1));
        assertNotNull("위치 15가 존재해야 합니다", positions.get(15));
        assertNotNull("위치 20이 존재해야 합니다", positions.get(20));
        assertNotNull("중앙 위치(23)가 존재해야 합니다", positions.get(23));
        assertNotNull("종료 위치(30)가 존재해야 합니다", positions.get(30));
        
        // 대각선 경로 위치 테스트
        assertNotNull("대각선 경로 위치 21이 존재해야 합니다", positions.get(21));
        assertNotNull("대각선 경로 위치 22가 존재해야 합니다", positions.get(22));
        assertNotNull("대각선 경로 위치 26이 존재해야 합니다", positions.get(26));
        assertNotNull("대각선 경로 위치 29가 존재해야 합니다", positions.get(29));
    }
    
    @Test
    public void testMainPathMovement() {
        // 주 경로 이동 테스트
        assertEquals("시작점에서 1칸 이동하면 위치 1에 도착해야 합니다", 1, board.getNextPosition(-1, 1));
        assertEquals("위치 1에서 2칸 이동하면 위치 3에 도착해야 합니다", 3, board.getNextPosition(1, 2));
        assertEquals("위치 19에서 2칸 이동하면 위치 1에 도착해야 합니다", 1, board.getNextPosition(19, 2));
    }
    
    @Test
    public void testBackwardMovement() {
        // 백도(뒤로 이동) 테스트
        assertEquals("위치 5에서 백도하면 위치 4에 도착해야 합니다", 4, board.getNextPosition(5, YutSet.BACKDO));
        assertEquals("위치 1에서 백도하면 위치 20에 도착해야 합니다", 20, board.getNextPosition(1, YutSet.BACKDO));
        assertEquals("시작점에서는 백도할 수 없습니다", -1, board.getNextPosition(-1, YutSet.BACKDO));
    }
    
    @Test
    public void testJunctionPoints() {
        // 교차점 판정 테스트
        assertTrue("위치 5는 교차점이어야 합니다", board.isJunction(5));
        assertTrue("위치 10은 교차점이어야 합니다", board.isJunction(10));
        assertTrue("위치 15는 교차점이어야 합니다", board.isJunction(15));
        assertFalse("위치 7은 교차점이 아니어야 합니다", board.isJunction(7));
        assertFalse("위치 22는 교차점이 아니어야 합니다", board.isJunction(22));
    }
    
    @Test
    public void testDiagonalPathMovement() {
        // 위치 5에서의 대각선 경로 테스트
        int nextPos = board.getNextPosition(5, 1, Board.PathType.DIAGONAL_RIGHT);
        assertEquals("위치 5에서 대각선 경로로 1칸 이동하면 위치 21에 도착해야 합니다", 21, nextPos);
        
        nextPos = board.getNextPosition(5, 2, Board.PathType.DIAGONAL_RIGHT);
        assertEquals("위치 5에서 대각선 경로로 2칸 이동하면 위치 22에 도착해야 합니다", 22, nextPos);
        
        // 위치 10에서의 대각선 경로 테스트
        nextPos = board.getNextPosition(10, 1, Board.PathType.DIAGONAL_LEFT);
        assertEquals("위치 10에서 대각선 경로로 1칸 이동하면 위치 26에 도착해야 합니다", 26, nextPos);
        
        nextPos = board.getNextPosition(10, 2, Board.PathType.DIAGONAL_LEFT);
        assertEquals("위치 10에서 대각선 경로로 2칸 이동하면 위치 27에 도착해야 합니다", 27, nextPos);
    }
    
    @Test
    public void testCenterPosition() {
        // 중앙 위치(23) 도달 테스트
        int nextPos = board.getNextPosition(5, 3, Board.PathType.DIAGONAL_RIGHT);
        assertEquals("위치 5에서 대각선 경로로 3칸 이동하면 중앙 위치(23)에 도착해야 합니다", 23, nextPos);
        
        nextPos = board.getNextPosition(10, 3, Board.PathType.DIAGONAL_LEFT);
        assertEquals("위치 10에서 대각선 경로로 3칸 이동하면 중앙 위치(23)에 도착해야 합니다", 23, nextPos);
    }
    
    @Test
    public void testPathTypeSelection() {
        // 교차점에서 가능한 경로 유형 테스트
        Map<Board.PathType, Integer> paths = board.getAvailablePaths(5);
        assertNotNull("위치 5에서는 가능한 경로가 있어야 합니다", paths);
        assertTrue("위치 5에서는 주 경로를 사용할 수 있어야 합니다", paths.containsKey(Board.PathType.MAIN_PATH));
        assertTrue("위치 5에서는 대각선 경로를 사용할 수 있어야 합니다", paths.containsKey(Board.PathType.DIAGONAL_RIGHT));
        
        paths = board.getAvailablePaths(10);
        assertNotNull("위치 10에서는 가능한 경로가 있어야 합니다", paths);
        assertTrue("위치 10에서는 주 경로를 사용할 수 있어야 합니다", paths.containsKey(Board.PathType.MAIN_PATH));
        assertTrue("위치 10에서는 대각선 경로를 사용할 수 있어야 합니다", paths.containsKey(Board.PathType.DIAGONAL_LEFT));
    }
    
    @Test
    public void testCompletingCircuit() {
        // 경로 완주 테스트
        int nextPos = board.getNextPosition(19, 1);
        assertEquals("위치 19에서 1칸 이동하면 위치 30에 도착해야 합니다", 30, nextPos);
        
        nextPos = board.getNextPosition(20, 1);
        assertEquals("위치 20에서 1칸 이동하면 위치 1에 도착해야 합니다", 1, nextPos);
    }
} 