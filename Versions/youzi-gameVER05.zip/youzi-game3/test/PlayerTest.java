import org.junit.Test;
import org.junit.Before;
import static org.junit.Assert.*;

import com.xingyang.yutnori.model.Player;
import com.xingyang.yutnori.model.Piece;

import java.awt.Color;
import java.util.List;

/**
 * 윷놀이 게임의 플레이어 테스트 클래스
 * 플레이어 기능과 말 관리를 테스트합니다
 */
public class PlayerTest {
    
    private Player testPlayer;
    
    @Before
    public void setUp() {
        // 테스트용 플레이어 생성
        testPlayer = new Player("Player 1", Color.RED);
    }
    
    @Test
    public void testPlayerInitialization() {
        // 플레이어 초기화 테스트
        assertEquals("플레이어 이름은 한글 이름이어야 합니다", "플레이어 1", testPlayer.getName());
        assertEquals("플레이어 색상은 빨간색이어야 합니다", Color.RED, testPlayer.getColor());
        
        // 생성된 말 수 테스트
        List<Piece> pieces = testPlayer.getPieces();
        assertEquals("플레이어는 4개의 말을 가져야 합니다", 4, pieces.size());
        
        // 모든 말의 소유자 확인
        for (Piece piece : pieces) {
            assertEquals("말의 소유자는 testPlayer여야 합니다", testPlayer, piece.getOwner());
        }
    }
    
    @Test
    public void testGetPiece() {
        // ID로 말 가져오기 테스트
        Piece piece0 = testPlayer.getPiece(0);
        assertNotNull("ID가 0인 말을 가져올 수 있어야 합니다", piece0);
        assertEquals("가져온 말의 ID는 0이어야 합니다", 0, piece0.getId());
        
        Piece piece3 = testPlayer.getPiece(3);
        assertNotNull("ID가 3인 말을 가져올 수 있어야 합니다", piece3);
        assertEquals("가져온 말의 ID는 3이어야 합니다", 3, piece3.getId());
        
        // 존재하지 않는 말 ID로 테스트
        Piece nonExistentPiece = testPlayer.getPiece(10);
        assertNull("ID가 10인 말은 없어야 합니다", nonExistentPiece);
    }
    
    @Test
    public void testHasFinished() {
        // 플레이어 게임 완료 테스트
        assertFalse("초기 상태에서 플레이어는 게임을 완료하지 않아야 합니다", testPlayer.hasFinished());
        
        // 모든 말을 종료 지점으로 이동
        for (Piece piece : testPlayer.getPieces()) {
            piece.setPosition(30);
        }
        
        assertTrue("모든 말이 종료 지점에 도달하면 플레이어는 게임을 완료해야 합니다", testPlayer.hasFinished());
        
        // 하나의 말이 종료 지점에 도달하지 않은 경우
        testPlayer.getPiece(0).setPosition(5);
        assertFalse("일부 말이 종료 지점에 도달하지 않으면 플레이어는 게임을 완료하지 않아야 합니다", testPlayer.hasFinished());
    }
    
    @Test
    public void testGetFinishedPieceCount() {
        // 완료된 말 수 확인 테스트
        assertEquals("초기 상태에서는 완료된 말이 없어야 합니다", 0, testPlayer.getFinishedPieceCount());
        
        // 두 개의 말을 종료 지점으로 이동
        testPlayer.getPiece(0).setPosition(30);
        testPlayer.getPiece(1).setPosition(30);
        
        assertEquals("두 개의 말이 종료 지점에 도달하면 완료된 말이 2개여야 합니다", 2, testPlayer.getFinishedPieceCount());
    }
    
    @Test
    public void testResetPieces() {
        // 말 초기화 테스트
        // 몇 개의 말을 이동
        testPlayer.getPiece(0).setPosition(5);
        testPlayer.getPiece(1).setPosition(10);
        testPlayer.getPiece(2).setPosition(30);
        
        // 몇 개의 말을 겹침
        testPlayer.getPiece(0).stackPiece(testPlayer.getPiece(3));
        
        // 모든 말 초기화
        testPlayer.resetPieces();
        
        // 모든 말이 초기 상태로 돌아왔는지 확인
        for (Piece piece : testPlayer.getPieces()) {
            assertEquals("초기화 후 말의 위치는 -1이어야 합니다", -1, piece.getPosition());
            assertFalse("초기화 후 말은 겹쳐지지 않아야 합니다", piece.isStacked());
            assertFalse("초기화 후 말은 겹침 말이 없어야 합니다", piece.hasStackedPieces());
        }
    }
    
    @Test
    public void testGetMovablePiece() {
        // 이동 가능한 말 가져오기 테스트
        Piece movablePiece = testPlayer.getMovablePiece(3);
        assertNotNull("이동 가능한 말을 가져올 수 있어야 합니다", movablePiece);
        
        // 모든 말을 종료 지점으로 이동
        for (Piece piece : testPlayer.getPieces()) {
            piece.setPosition(30);
        }
        
        // 더 이상 이동 가능한 말이 없어야 함
        movablePiece = testPlayer.getMovablePiece(3);
        assertNull("모든 말이 종료 지점에 도달하면 이동 가능한 말이 없어야 합니다", movablePiece);
    }
} 