#!/bin/bash

# 创建输出目录
mkdir -p test-out
mkdir -p test-bin

# 编译模型类
echo "编译模型类..."
javac -d test-bin com/xingyang/yutnori/model/*.java

# 编译测试类
echo "编译测试类..."
javac -d test-bin -cp test-bin:lib/junit-4.13.2.jar:lib/hamcrest-core-1.3.jar test/*.java

# 运行测试
echo "运行测试..."
java -cp test-bin:lib/junit-4.13.2.jar:lib/hamcrest-core-1.3.jar org.junit.runner.JUnitCore \
    YutSetTest PieceTest PlayerTest BoardTest GameTest

# 检查测试结果
if [ $? -eq 0 ]; then
    echo "所有测试通过！"
else
    echo "测试失败，请查看上面的错误信息。"
fi 