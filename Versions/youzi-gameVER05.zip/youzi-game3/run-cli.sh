#!/bin/bash

echo "正在启动韩国传统游戏 - 윷놀이 (Yut Nori) 命令行版本..."

# 确保已经编译
if [ ! -d "out" ]; then
  echo "需要先编译游戏，正在编译..."
  sh fix-compile.sh
else
  # 如果已经编译，直接运行
  java -cp out com.xingyang.yutnori.YutNoriGame
fi 