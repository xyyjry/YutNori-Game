#!/bin/bash

echo "正在启动韩国传统游戏 - 윷놀이 (Yut Nori)..."

# 确保已经编译
if [ ! -d "out" ]; then
  echo "需要先编译游戏，正在编译..."
  sh fix-compile.sh
fi

# 移除环境变量设置，让程序显示UI选择界面
# export YUT_NORI_UI_TYPE=3  # 3表示简易图形界面

# 启动游戏
java -cp out com.xingyang.yutnori.YutNoriGame 