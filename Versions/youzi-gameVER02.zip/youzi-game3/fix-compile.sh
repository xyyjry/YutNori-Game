#!/bin/bash

echo "正在清理之前的类文件..."
find . -name "*.class" -type f -delete

echo "确保目录结构正确..."
mkdir -p out

echo "使用单一命令编译所有Java文件，指定正确的类路径..."
javac -d out -sourcepath . com/xingyang/yutnori/model/*.java com/xingyang/yutnori/ui/*.java com/xingyang/*.java

if [ $? -eq 0 ]; then
  echo "编译成功！正在运行游戏..."
  java -cp out com.xingyang.YutNoriApp
else
  echo "编译失败，请检查错误信息。"
fi 