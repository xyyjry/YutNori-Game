package com.xingyang.yutnori.model;

import java.awt.Color;
import java.util.ArrayList;
import java.util.List;

/**
 * Represents a player in the Yut Nori game.
 * Each player has a name, color, and a set of pieces to move around the board.
 */
public class Player {
    private String name;
    private Color color;
    private List<Piece> pieces;
    private int pieceCount = 4;  // Default number of pieces per player
    
    /**
     * Constructs a new player with the specified name and color.
     * 
     * @param name The player's name
     * @param color The player's color
     */
    public Player(String name, Color color) {
        this.name = name;
        this.color = color;
        this.pieces = new ArrayList<>();
        
        // Create the pieces for this player
        initializePieces();
    }
    
    /**
     * Initializes the player's pieces.
     */
    private void initializePieces() {
        for (int i = 0; i < pieceCount; i++) {
            Piece piece = new Piece(this, i);
            pieces.add(piece);
        }
    }
    
    /**
     * Gets the player's name.
     * 
     * @return The player's name
     */
    public String getName() {
        return name;
    }
    
    /**
     * Gets the player's color.
     * 
     * @return The player's color
     */
    public Color getColor() {
        return color;
    }
    
    /**
     * Gets the player's pieces.
     * 
     * @return A list of the player's pieces
     */
    public List<Piece> getPieces() {
        return pieces;
    }
    
    /**
     * Checks if all of the player's pieces have reached the end.
     * 
     * @return True if all pieces have reached the end, false otherwise
     */
    public boolean hasFinished() {
        for (Piece piece : pieces) {
            // A piece is finished if:
            // 1. It's at position 30 (marked as completed)
            // 2. It's at position 5 after completing a circuit
            if (piece.getPosition() != 30) {
                return false;
            }
        }
        return true;
    }
    
    /**
     * Gets the count of pieces that have reached the end.
     * 
     * @return The number of pieces that have finished
     */
    public int getFinishedPieceCount() {
        int count = 0;
        for (Piece piece : pieces) {
            if (piece.getPosition() == 30) {
                count++;
            }
        }
        return count;
    }
    
    /**
     * Gets a piece that can be moved with the given roll.
     * 
     * @param roll The roll result
     * @return A piece that can be moved, or null if none can be moved
     */
    public Piece getMovablePiece(int roll) {
        for (Piece piece : pieces) {
            if (piece.getPosition() < 30) {
                return piece;
            }
        }
        return null;
    }
    
    /**
     * Resets all pieces to their starting positions.
     */
    public void resetPieces() {
        for (Piece piece : pieces) {
            piece.setPosition(-1);  // -1 represents the starting position (off board)
            piece.clearStackedPieces();
        }
    }
    
    @Override
    public String toString() {
        return name;
    }
} 