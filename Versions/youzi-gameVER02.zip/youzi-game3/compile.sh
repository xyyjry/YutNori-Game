#!/bin/bash

echo "Cleaning previous class files..."
find . -name "*.class" -type f -delete

echo "Compiling all Java files..."
# 先编译model
javac -d . com/xingyang/yutnori/model/*.java
# 再编译UI
javac -d . com/xingyang/yutnori/ui/*.java
# 最后编译主应用程序
javac -d . com/xingyang/*.java

echo "Compilation complete. Running the application..."
java com.xingyang.YutNoriApp 