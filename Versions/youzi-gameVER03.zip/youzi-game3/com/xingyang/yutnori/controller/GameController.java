package com.xingyang.yutnori.controller;

import com.xingyang.yutnori.model.*;
import java.awt.Color;
import java.util.ArrayList;
import java.util.List;

/**
 * 游戏控制器类，负责协调模型和视图之间的交互。
 * 这个类实现了MVC架构中的控制器部分，处理游戏逻辑并将模型变化通知给视图。
 */
public class GameController {
    // 游戏模型
    private Game game;
    
    // 监听器列表（遵循观察者模式）
    private List<GameStateListener> listeners;
    
    /**
     * 构造函数 - 使用默认玩家创建游戏控制器
     */
    public GameController() {
        // 创建两名默认玩家
        List<Player> players = new ArrayList<>();
        Player player1 = new Player("Player 1", new Color(220, 50, 50));
        Player player2 = new Player("Player 2", new Color(50, 100, 220));
        
        players.add(player1);
        players.add(player2);
        
        // 创建游戏实例
        this.game = new Game(players);
        this.listeners = new ArrayList<>();
    }
    
    /**
     * 构造函数 - 使用指定的玩家创建游戏控制器
     * 
     * @param playerCount 玩家数量
     * @param playerNames 玩家名称数组
     * @param playerColors 玩家颜色数组
     */
    public GameController(int playerCount, String[] playerNames, Color[] playerColors) {
        // 根据传入的参数创建玩家
        List<Player> players = new ArrayList<>();
        
        for (int i = 0; i < playerCount; i++) {
            Player player = new Player(playerNames[i], playerColors[i]);
            players.add(player);
        }
        
        // 创建游戏实例
        this.game = new Game(players);
        this.listeners = new ArrayList<>();
    }
    
    /**
     * 获取游戏实例
     * @return 游戏实例
     */
    public Game getGame() {
        return game;
    }
    
    /**
     * 重置游戏
     */
    public void resetGame() {
        game.resetGame();
        notifyGameReset();
    }
    
    /**
     * 处理掷棒结果
     * @param result 掷棒结果
     */
    public void handleThrowResult(int result) {
        game.handleThrowResult(result);
        notifyYutThrown(result);
    }
    
    /**
     * 选择特定的掷棒结果
     * @param roll 选择的掷棒结果
     * @return 如果选择成功返回true，否则返回false
     */
    public boolean selectRoll(int roll) {
        boolean success = game.selectRoll(roll);
        if (success) {
            notifyRollSelected(roll);
        }
        return success;
    }
    
    /**
     * 移动棋子
     * @param piece 要移动的棋子
     * @param roll 移动的步数
     * @return 如果移动成功返回true，否则返回false
     */
    public boolean movePiece(Piece piece, int roll) {
        boolean success = game.movePiece(piece, roll);
        if (success) {
            notifyPieceMoved(piece);
        }
        return success;
    }
    
    /**
     * 移动棋子（带路径选择）
     * @param piece 要移动的棋子
     * @param roll 移动的步数
     * @param pathType 选择的路径类型
     * @return 如果移动成功返回true，否则返回false
     */
    public boolean movePiece(Piece piece, int roll, Board.PathType pathType) {
        boolean success = game.movePiece(piece, roll, pathType);
        if (success) {
            notifyPieceMoved(piece);
        }
        return success;
    }
    
    /**
     * 结束当前回合
     */
    public void endTurn() {
        game.endTurn();
        notifyTurnEnded();
    }
    
    /**
     * 添加游戏状态监听器
     * @param listener 要添加的监听器
     */
    public void addGameStateListener(GameStateListener listener) {
        if (!listeners.contains(listener)) {
            listeners.add(listener);
        }
    }
    
    /**
     * 移除游戏状态监听器
     * @param listener 要移除的监听器
     */
    public void removeGameStateListener(GameStateListener listener) {
        listeners.remove(listener);
    }
    
    // 以下是通知方法，用于通知所有监听器游戏状态变化
    
    private void notifyGameReset() {
        for (GameStateListener listener : listeners) {
            listener.onGameReset();
        }
    }
    
    private void notifyYutThrown(int result) {
        for (GameStateListener listener : listeners) {
            listener.onYutThrown(result);
        }
    }
    
    private void notifyRollSelected(int roll) {
        for (GameStateListener listener : listeners) {
            listener.onRollSelected(roll);
        }
    }
    
    private void notifyPieceMoved(Piece piece) {
        for (GameStateListener listener : listeners) {
            listener.onPieceMoved(piece);
        }
    }
    
    private void notifyTurnEnded() {
        for (GameStateListener listener : listeners) {
            listener.onTurnEnded();
        }
    }
    
    private void notifyGameOver(Player winner) {
        for (GameStateListener listener : listeners) {
            listener.onGameOver(winner);
        }
    }
} 