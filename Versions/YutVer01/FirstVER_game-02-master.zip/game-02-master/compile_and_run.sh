#!/bin/bash

# Create build directory if it doesn't exist
mkdir -p build

# Compile all Java files
javac -d build src/com/xingyang/yutnori/model/*.java src/com/xingyang/yutnori/ui/*.java src/com/xingyang/yutnori/*.java

# Run the application
java -cp build com.xingyang.yutnori.YutNoriApp 