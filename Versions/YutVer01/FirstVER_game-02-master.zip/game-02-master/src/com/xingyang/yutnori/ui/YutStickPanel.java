package com.xingyang.yutnori.ui;

import com.xingyang.yutnori.model.Game;
import com.xingyang.yutnori.model.YutSet;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.geom.AffineTransform;
import java.awt.geom.RoundRectangle2D;

/**
 * A panel that displays the Yut sticks and allows the player to throw them.
 */
public class YutStickPanel extends JPanel {
    private YutSet yutSet;
    private JButton throwButton;
    private boolean[] flatSideUp; // true = flat side up, false = curved side up
    private int rollResult;
    private GameBoard gameBoard;
    
    // Animation properties
    private Timer animationTimer;
    private int animationStep;
    private int totalAnimationSteps = 20;
    private double[] rotationAngles;
    private boolean isAnimating = false;
    
    // Enhanced visualization
    private Color[] stickColors = {
        new Color(205, 170, 125), // Light brown
        new Color(185, 150, 105), // Medium brown 
        new Color(165, 130, 85),  // Dark brown
        new Color(145, 110, 65)   // Darker brown
    };
    
    /**
     * Constructs a new YutStickPanel with the specified YutSet.
     * 
     * @param yutSet The YutSet to use for throwing
     * @param gameBoard The game board to update after throwing
     */
    public YutStickPanel(YutSet yutSet, GameBoard gameBoard) {
        this.yutSet = yutSet;
        this.gameBoard = gameBoard;
        this.flatSideUp = new boolean[4];
        this.rotationAngles = new double[4];
        this.rollResult = 0;
        
        setPreferredSize(new Dimension(250, 350)); // 继续增加面板高度，确保有足够空间显示所有内容
        setBackground(new Color(245, 245, 220)); // Beige background
        
        // Initialize throw button
        throwButton = new JButton("Throw Yut Sticks");
        throwButton.setFont(new Font("Arial", Font.BOLD, 16));
        throwButton.setBackground(new Color(210, 180, 140)); // Tan button color
        throwButton.setForeground(Color.BLACK);
        throwButton.setFocusPainted(false);
        throwButton.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(139, 69, 19), 2),
                BorderFactory.createEmptyBorder(8, 16, 8, 16)
        ));
        
        throwButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                throwYutSticks();
            }
        });
        
        // Set layout - Use more appropriate layout
        setLayout(new BorderLayout(0, 20)); // 添加垂直间隔
        
        // 创建单独的面板来放置按钮，并确保它位于底部
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        buttonPanel.setBackground(new Color(245, 245, 220));
        buttonPanel.add(throwButton);
        
        // 添加带有内边距的按钮面板到底部
        add(buttonPanel, BorderLayout.SOUTH);
        
        // Initialize animation timer
        animationTimer = new Timer(30, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                animateSticks();
            }
        });
    }
    
    /**
     * Throws the Yut sticks and starts the animation.
     */
    public void throwYutSticks() {
        if (isAnimating) {
            return;
        }
        
        System.out.println("Throwing Yut sticks...");
        throwButton.setEnabled(false);
        isAnimating = true;
        animationStep = 0;
        
        // Initialize random rotation angles for animation
        for (int i = 0; i < 4; i++) {
            rotationAngles[i] = Math.random() * 720 + 360; // 1-3 full rotations
            // Ensure fully random initial state
            flatSideUp[i] = Math.random() < 0.5;
        }
        
        // Start animation
        animationTimer.start();
    }
    
    /**
     * Animates the Yut sticks during a throw.
     */
    private void animateSticks() {
        animationStep++;
        
        if (animationStep >= totalAnimationSteps) {
            // Animation finished
            animationTimer.stop();
            
            // Get the game instance from the game board
            Game game = gameBoard.getGame();
            
            // Use the game's rollYut method to ensure proper state update
            rollResult = game.rollYut();
            System.out.println("Roll result: " + rollResult + " (" + getResultName(rollResult) + ")");
            System.out.println("Game hasRolled state: " + game.hasRolled());
            
            // Update the stick states to match the roll result
            updateStickStates();
            
            isAnimating = false;
            throwButton.setEnabled(false);  // Disable throw button after roll until turn is completed
            
            // Add a visual feedback for roll completion
            JRootPane rootPane = SwingUtilities.getRootPane(this);
            if (rootPane != null) {
                rootPane.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
                Timer cursorTimer = new Timer(1500, e -> {
                    rootPane.setCursor(Cursor.getDefaultCursor());
                    ((Timer)e.getSource()).stop();
                });
                cursorTimer.setRepeats(false);
                cursorTimer.start();
            }
            
            // Update the game board
            gameBoard.updateAfterRoll(rollResult);
        }
        
        repaint();
    }
    
    /**
     * Gets the name of a roll result.
     * 
     * @param result The roll result
     * @return The name of the result
     */
    private String getResultName(int result) {
        switch (result) {
            case YutSet.DO: return "Do";
            case YutSet.GAE: return "Gae";
            case YutSet.GEOL: return "Geol";
            case YutSet.YUT: return "Yut";
            case YutSet.MO: return "Mo";
            default: return "Invalid";
        }
    }
    
    /**
     * Updates the visual state of the sticks to match the roll result.
     */
    private void updateStickStates() {
        // For Mo (0 flat sides up)
        if (rollResult == YutSet.MO) {
            for (int i = 0; i < 4; i++) {
                flatSideUp[i] = false;
            }
            System.out.println("Mo: All curved sides up");
        } 
        // For other results, set the appropriate number of flat sides up
        else {
            // Clear all states first
            for (int i = 0; i < 4; i++) {
                flatSideUp[i] = false;
            }
            
            // Set the required number of flat sides up
            for (int i = 0; i < rollResult; i++) {
                flatSideUp[i] = true;
            }
            
            System.out.println(rollResult + " flat sides up");
        }
    }
    
    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2d = (Graphics2D) g;
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        
        // Draw the result text if not animating
        if (!isAnimating && rollResult > 0) {
            String resultName = "";
            switch (rollResult) {
                case YutSet.DO:
                    resultName = "Do (1)";
                    break;
                case YutSet.GAE:
                    resultName = "Gae (2)";
                    break;
                case YutSet.GEOL:
                    resultName = "Geol (3)";
                    break;
                case YutSet.YUT:
                    resultName = "Yut (4)";
                    break;
                case YutSet.MO:
                    resultName = "Mo (5)";
                    break;
            }
            
            // Draw result background - 更强的背景效果
            g2d.setColor(new Color(255, 255, 255, 220)); // 更不透明的白色
            g2d.fillRoundRect(getWidth()/2 - 110, 10, 220, 50, 15, 15);
            
            // 添加边框使文本区域更明显
            g2d.setColor(new Color(200, 180, 140));
            g2d.drawRoundRect(getWidth()/2 - 110, 10, 220, 50, 15, 15);
            
            // Draw main result text with shadow
            g2d.setColor(new Color(50, 50, 50, 100)); // Shadow color
            g2d.setFont(new Font("Arial", Font.BOLD, 32));
            FontMetrics fm = g2d.getFontMetrics();
            int textWidth = fm.stringWidth(resultName);
            g2d.drawString(resultName, (getWidth() - textWidth) / 2 + 2, 45 + 2);
            
            // Main text
            Color resultColor;
            switch (rollResult) {
                case YutSet.DO: resultColor = new Color(100, 100, 100); break; // Gray for Do
                case YutSet.GAE: resultColor = new Color(0, 100, 200); break; // Blue for Gae
                case YutSet.GEOL: resultColor = new Color(139, 69, 19); break; // Brown for Geol
                case YutSet.YUT: resultColor = new Color(200, 0, 0); break; // Red for Yut
                case YutSet.MO: resultColor = new Color(180, 0, 150); break; // Purple for Mo
                default: resultColor = Color.BLACK;
            }
            
            g2d.setColor(resultColor);
            g2d.drawString(resultName, (getWidth() - textWidth) / 2, 45);
            
            // Draw information about re-throw - 增加明显的视觉区分
            if (rollResult == YutSet.YUT || rollResult == YutSet.MO) {
                String reThrowText = "You can throw again!";
                g2d.setFont(new Font("Arial", Font.BOLD, 16));
                fm = g2d.getFontMetrics();
                int reThrowWidth = fm.stringWidth(reThrowText);
                
                // Draw background for bonus text - 更明显的背景
                g2d.setColor(new Color(255, 240, 200, 220)); // 更不透明的背景
                g2d.fillRoundRect(getWidth()/2 - reThrowWidth/2 - 15, 65, reThrowWidth + 30, 25, 10, 10);
                
                // 添加边框
                g2d.setColor(new Color(220, 150, 150));
                g2d.drawRoundRect(getWidth()/2 - reThrowWidth/2 - 15, 65, reThrowWidth + 30, 25, 10, 10);
                
                g2d.setColor(new Color(180, 0, 0)); // Dark red
                g2d.drawString(reThrowText, (getWidth() - reThrowWidth) / 2, 82);
            }
        }
        
        // Draw the sticks
        drawSticks(g2d);
        
        // Draw result explanation only if we have a roll result
        if (!isAnimating && rollResult > 0) {
            drawResultExplanation(g2d);
        }
    }
    
    /**
     * Draws the Yut sticks.
     * 
     * @param g2d The Graphics2D object to draw with
     */
    private void drawSticks(Graphics2D g2d) {
        if (g2d == null) {
            return;
        }
        
        int centerX = getWidth() / 2;
        int centerY = 150; // 棍子中心位置向下调整，为顶部文字留出更多空间
        int stickLength = 60; // 减小棍子长度
        int stickWidth = 16; // 减小棍子宽度
        
        // 重新排列棍子，使它们不重叠
        int[][] positions = {
            {centerX - 70, centerY - 30}, // 左上棍子
            {centerX + 70, centerY - 30}, // 右上棍子 
            {centerX - 70, centerY + 30}, // 左下棍子
            {centerX + 70, centerY + 30}  // 右下棍子
        };
        
        for (int i = 0; i < 4; i++) {
            // 计算旋转角度（动画）
            double rotationAngle = 0;
            if (isAnimating) {
                double progress = (double) animationStep / totalAnimationSteps;
                rotationAngle = rotationAngles[i] * progress;
                
                // 根据动画进度确定最终状态
                flatSideUp[i] = Math.cos(rotationAngle * Math.PI / 180) > 0;
            }
            
            // 不同颜色的木棍以提高可见性
            g2d.setColor(stickColors[i]);
            
            // 保存当前变换
            AffineTransform oldTransform = g2d.getTransform();
            
            // 移动到棍子中心
            g2d.translate(positions[i][0], positions[i][1]);
            
            // 旋转
            g2d.rotate(Math.toRadians(rotationAngle));
            
            // 绘制棍子
            if (flatSideUp[i]) {
                // 平面朝上 - 绘制矩形
                g2d.fillRect(-stickLength / 2, -stickWidth / 2, stickLength, stickWidth);
                
                // 添加标记表示这是平面
                g2d.setColor(new Color(100, 50, 20));
                g2d.fillRect(-stickLength / 3, -stickWidth / 4, 2 * stickLength / 3, stickWidth / 2);
                
                g2d.setColor(Color.BLACK);
                g2d.drawRect(-stickLength / 2, -stickWidth / 2, stickLength, stickWidth);
            } else {
                // 弯曲面朝上 - 绘制圆角矩形
                RoundRectangle2D roundRect = new RoundRectangle2D.Double(
                        -stickLength / 2, -stickWidth / 2, stickLength, stickWidth, 15, 15);
                g2d.fill(roundRect);
                
                // 添加标记表示这是弯曲面
                g2d.setColor(new Color(120, 80, 50));
                g2d.fillOval(-8, -4, 16, 8);
                
                g2d.setColor(Color.BLACK);
                g2d.draw(roundRect);
            }
            
            // 在每个棍子上添加标签
            g2d.setColor(Color.WHITE);
            g2d.setFont(new Font("Arial", Font.BOLD, 12));
            g2d.drawString(String.valueOf(i+1), -4, 4);
            
            // 恢复旧的变换
            g2d.setTransform(oldTransform);
        }
    }
    
    /**
     * Enables or disables the throw button.
     * 
     * @param enabled True to enable the button, false to disable
     */
    public void setThrowEnabled(boolean enabled) {
        throwButton.setEnabled(enabled);
    }
    
    /**
     * Resets the YutStickPanel state and clears roll results
     */
    public void reset() {
        rollResult = 0;
        isAnimating = false;
        throwButton.setEnabled(true);
        
        // Reset the throw button's appearance
        throwButton.setBackground(new Color(210, 180, 140)); // Reset to original color
        throwButton.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(139, 69, 19), 2),
                BorderFactory.createEmptyBorder(8, 16, 8, 16)
        ));
        
        repaint();
    }
    
    /**
     * Highlights the throw button to guide the user to click it
     */
    public void highlightThrowButton() {
        // Change background color to draw attention
        throwButton.setBackground(new Color(255, 215, 0)); // Gold color
        
        // Add a pulsing border effect
        throwButton.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(255, 0, 0), 3), // Red border
                BorderFactory.createEmptyBorder(8, 16, 8, 16)
        ));
        
        // Make the text more visible
        throwButton.setForeground(new Color(200, 0, 0));
        throwButton.setFont(new Font("Arial", Font.BOLD, 16));
        
        // Add a tooltip
        throwButton.setToolTipText("Click here to throw the Yut sticks");
        
        repaint();
    }
    
    /**
     * Counts the number of flat sides up
     * @return Number of flat sides up
     */
    private int flatSideCounter() {
        int flatCount = 0;
        for (boolean isFlat : flatSideUp) {
            if (isFlat) flatCount++;
        }
        return flatCount;
    }
    
    /**
     * Draws the result explanation.
     * 
     * @param g2d The Graphics2D object to draw with
     */
    private void drawResultExplanation(Graphics2D g2d) {
        if (!isAnimating && rollResult > 0) {
            g2d.setFont(new Font("Arial", Font.PLAIN, 12));
            g2d.setColor(new Color(60, 60, 60));
            
            String explanation;
            switch(rollResult) {
                case YutSet.DO:
                    explanation = "Move 1 space. Select a piece to move.";
                    break;
                case YutSet.GAE:
                    explanation = "Move 2 spaces. Select a piece to move.";
                    break;
                case YutSet.GEOL:
                    explanation = "Move 3 spaces. Select a piece to move.";
                    break;
                case YutSet.YUT:
                    explanation = "Move 4 spaces. You'll get another turn!";
                    break;
                case YutSet.MO:
                    explanation = "Move 5 spaces. You'll get another turn!";
                    break;
                default:
                    explanation = "";
            }
            
            // 绘制带背景的文本说明 - 更大的间距和更强的背景，位置向下调整
            int textWidth = g2d.getFontMetrics().stringWidth(explanation);
            int x = (getWidth() - textWidth) / 2;
            int y = 220; // 向下移动位置
            
            // 绘制更明显的背景
            g2d.setColor(new Color(255, 255, 220, 240)); // 更不透明的背景
            g2d.fillRoundRect(x - 15, y - 15, textWidth + 30, 24, 10, 10); // 增加背景大小
            
            // 添加边框使文本更明显
            g2d.setColor(new Color(200, 180, 140));
            g2d.drawRoundRect(x - 15, y - 15, textWidth + 30, 24, 10, 10);
            
            // 绘制文本
            g2d.setColor(new Color(60, 60, 60));
            g2d.drawString(explanation, x, y);
            
            // Add a "click on a piece" instruction - 放到下方位置，进一步放低
            String moveInstruction = "Click on one of your pieces to move it";
            textWidth = g2d.getFontMetrics().stringWidth(moveInstruction);
            x = (getWidth() - textWidth) / 2;
            y = 250; // 向下移动
            
            // 绘制更明显的背景
            g2d.setColor(new Color(255, 255, 220, 240));
            g2d.fillRoundRect(x - 15, y - 15, textWidth + 30, 24, 10, 10); // 增加背景大小
            
            // 添加边框
            g2d.setColor(new Color(200, 180, 140));
            g2d.drawRoundRect(x - 15, y - 15, textWidth + 30, 24, 10, 10);
            
            // 绘制文本
            g2d.setColor(new Color(60, 60, 60));
            g2d.drawString(moveInstruction, x, y);
            
            // Add additional text to explain the stick configuration - 移到底部并增加背景
            g2d.setFont(new Font("Arial", Font.PLAIN, 12));
            
            String stickInfo = flatSideCounter() + " flat side(s) up = " + getResultName(rollResult);
            textWidth = g2d.getFontMetrics().stringWidth(stickInfo);
            x = (getWidth() - textWidth) / 2;
            y = 280; // 放到更下方，确保不会重叠
            
            // 绘制背景
            g2d.setColor(new Color(255, 255, 220, 220));
            g2d.fillRoundRect(x - 10, y - 15, textWidth + 20, 20, 8, 8);
            
            // 添加边框
            g2d.setColor(new Color(200, 180, 140));
            g2d.drawRoundRect(x - 10, y - 15, textWidth + 20, 20, 8, 8);
            
            // 绘制文本
            g2d.setColor(Color.BLACK);
            g2d.drawString(stickInfo, x, y);
        }
    }
} 