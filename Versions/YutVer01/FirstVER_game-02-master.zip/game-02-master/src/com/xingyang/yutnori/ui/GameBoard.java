package com.xingyang.yutnori.ui;

import com.xingyang.yutnori.model.*;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.geom.Ellipse2D;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

/**
 * The main game board display component.
 * Handles rendering of the board, pieces, and user interactions.
 */
public class GameBoard extends JPanel {
    private Game game;
    private Board board;
    private List<Piece> selectedPieces;
    private boolean canSelectPieces;
    
    // Movement hint indicators
    private Map<Integer, Boolean> possibleMovePositions;
    private boolean showingHints = false;
    
    // UI constants
    private static final int BOARD_SIZE = 700; // 增加棋盘大小
    private static final int PIECE_SIZE = 25;
    private static final int POSITION_SIZE = 30;
    
    // Piece offsets for stacked pieces
    private static final int[] STACK_OFFSETS_X = {0, 4, -4, 0};
    private static final int[] STACK_OFFSETS_Y = {0, 0, 0, 4};
    
    // Home areas for players' pieces not on board
    private Rectangle[] homeAreas;
    
    // Player movement hints
    private JLabel movementHintLabel;
    private JLabel currentActionLabel;  // New label for current required action
    
    /**
     * 添加脉冲动画效果的变量
     */
    private int pulseCounter = 0;
    private Timer pulseTimer;
    
    /**
     * Constructs a new GameBoard for the specified game.
     * 
     * @param game The game to display
     */
    public GameBoard(Game game) {
        this.game = game;
        this.board = game.getBoard();
        this.selectedPieces = new ArrayList<>();
        this.canSelectPieces = false;
        this.possibleMovePositions = new HashMap<>();
        
        // 设置固定的棋盘大小
        setPreferredSize(new Dimension(BOARD_SIZE, BOARD_SIZE));
        setBackground(new Color(240, 230, 200)); // Light beige background
        setLayout(null); // Use absolute positioning
        
        // 恢复到原始的玩家区域布局
        homeAreas = new Rectangle[4];
        // 将玩家区域移到棋盘外部四角
        homeAreas[0] = new Rectangle(30, 620, 120, 120);   // 左下 (Player 1 - Red)
        homeAreas[1] = new Rectangle(580, 620, 120, 120);  // 右下 (Player 2 - Blue)
        homeAreas[2] = new Rectangle(30, 460, 120, 120);   // 左上 (Player 3 - Green) - 向下移动避免与其他元素重叠
        homeAreas[3] = new Rectangle(30, 160, 120, 120);  // 右上 (Player 4 - Yellow) - 向下移动避免与其他元素重叠
        
        // 重新定位和调整移动提示标签 - 上移到顶部并增加宽度
        movementHintLabel = new JLabel();
        movementHintLabel.setFont(new Font("SansSerif", Font.BOLD, 14));
        movementHintLabel.setForeground(new Color(120, 0, 0));
        movementHintLabel.setBackground(new Color(255, 255, 220, 220));
        movementHintLabel.setOpaque(true);
        movementHintLabel.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(200, 150, 100), 1),
                BorderFactory.createEmptyBorder(4, 8, 4, 8)
        ));
        // 设置固定宽度，避免过长溢出
        movementHintLabel.setBounds(120, 3, 400, 30);
        movementHintLabel.setHorizontalAlignment(JLabel.CENTER);
        movementHintLabel.setVisible(false);
        add(movementHintLabel);
        
        // Add current action label - 放到提示下方
        currentActionLabel = new JLabel("Throw the Yut sticks to begin your turn");
        currentActionLabel.setFont(new Font("SansSerif", Font.BOLD, 14));
        currentActionLabel.setForeground(new Color(0, 0, 120));
        currentActionLabel.setBackground(new Color(255, 255, 220, 220));
        currentActionLabel.setOpaque(true);
        currentActionLabel.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(100, 150, 200), 1),
                BorderFactory.createEmptyBorder(4, 8, 4, 8)
        ));
        // 保持与上面的提示标签对齐
        currentActionLabel.setBounds(120, 40, 400, 30);
        currentActionLabel.setHorizontalAlignment(JLabel.CENTER);
        currentActionLabel.setVisible(true);
        add(currentActionLabel);
        
        // Add mouse listener for piece selection and movement
        addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                handleMouseClick(e.getX(), e.getY());
            }
        });
        
        // 初始化脉冲动画计时器
        pulseTimer = new Timer(100, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                pulseCounter = (pulseCounter + 1) % 10;
                repaint();
            }
        });
        pulseTimer.start();
    }
    
    /**
     * Gets the game instance associated with this board.
     * 
     * @return The game instance
     */
    public Game getGame() {
        return game;
    }
    
    /**
     * Updates the game board after a roll.
     * 
     * @param rollResult The result of the roll
     */
    public void updateAfterRoll(int rollResult) {
        System.out.println("Updating board after roll: " + rollResult);
        
        // Make sure the game knows a roll has happened
        if (!game.hasRolled()) {
            System.out.println("Warning: Game doesn't think a roll has happened!");
            // This might need to be fixed in the Game class
        }
        
        // Enable piece selection
        canSelectPieces = true;
        
        // Show movement hint
        showMovementHint(rollResult);
        
        // Calculate possible moves
        calculatePossibleMoves(rollResult);
        
        // Update current action label
        currentActionLabel.setText("Select a piece to move " + rollResult + " spaces");
        
        repaint();
    }
    
    /**
     * Shows a movement hint message based on the roll result.
     * 
     * @param rollResult The result of the roll
     */
    private void showMovementHint(int rollResult) {
        Player currentPlayer = game.getCurrentPlayer();
        String resultName = "";
        switch (rollResult) {
            case YutSet.DO: resultName = "Do (1)"; break;
            case YutSet.GAE: resultName = "Gae (2)"; break;
            case YutSet.GEOL: resultName = "Geol (3)"; break;
            case YutSet.YUT: resultName = "Yut (4)"; break;
            case YutSet.MO: resultName = "Mo (5)"; break;
        }
        
        String hintText = currentPlayer.getName() + " rolled " + resultName + " - Select a piece to move";
        movementHintLabel.setText(hintText);
        movementHintLabel.setVisible(true);
        
        // Check if player has any movable pieces
        boolean hasMovablePieces = false;
        for (Piece piece : currentPlayer.getPieces()) {
            if (piece.canMove(rollResult)) {
                hasMovablePieces = true;
                break;
            }
        }
        
        if (!hasMovablePieces) {
            movementHintLabel.setText(currentPlayer.getName() + " has no movable pieces - End your turn");
        }
        
        showingHints = true;
    }
    
    /**
     * Calculates and stores the possible move positions for the current roll.
     * 
     * @param rollResult The result of the roll
     */
    private void calculatePossibleMoves(int rollResult) {
        possibleMovePositions.clear();
        
        Player currentPlayer = game.getCurrentPlayer();
        for (Piece piece : currentPlayer.getPieces()) {
            if (piece.canMove(rollResult)) {
                int newPosition = board.getNextPosition(piece.getPosition(), rollResult);
                possibleMovePositions.put(newPosition, true);
            }
        }
    }
    
    /**
     * Moves a piece for the current player.
     * 
     * @param piece The piece to move
     */
    private void movePieceWithAnimation(Piece piece) {
        if (piece == null) return;
        
        // Debug current game state
        System.out.println("Current roll: " + game.getCurrentRoll() + ", Has rolled: " + game.hasRolled());
        
        // Skip animation and directly move the piece
        if (!game.hasRolled()) {
            System.out.println("Game doesn't have a valid roll. Displaying error message.");
            currentActionLabel.setText("You need to roll the Yut sticks first before moving!");
            selectedPieces.clear();
            repaint();
            return;
        }
        
        // 记录起始位置
        final int startPosition = piece.getPosition();
        System.out.println("Starting animation to move piece from position " + startPosition);
        
        // 计算新位置
        final int endPosition = board.getNextPosition(startPosition, game.getCurrentRoll());
        System.out.println("Target position: " + endPosition);
        
        // 禁用交互直到动画结束
        canSelectPieces = false;
        showingHints = false;
        
        // 获取移动路径上的所有点
        final List<Point> pathPoints = new ArrayList<>();
        Point startPoint = null;
        Point endPoint = null;
        
        // 如果是从起点开始移动
        if (startPosition == -1) {
            int playerIndex = 0;
            for (Player player : game.getPlayers()) {
                if (player == piece.getOwner()) {
                    break;
                }
                playerIndex++;
            }
            
            Rectangle homeArea = homeAreas[playerIndex];
            startPoint = new Point(homeArea.x + homeArea.width / 2, homeArea.y + homeArea.height / 2);
            endPoint = board.getCoordinate(0); // 移动到起点位置
        } else {
            startPoint = board.getCoordinate(startPosition);
            
            // 如果是移动到终点
            if (endPosition == 30) {
                int playerIndex = 0;
                for (Player player : game.getPlayers()) {
                    if (player == piece.getOwner()) {
                        break;
                    }
                    playerIndex++;
                }
                
                Rectangle homeArea = homeAreas[playerIndex];
                endPoint = new Point(homeArea.x + homeArea.width / 2, homeArea.y + homeArea.height / 2);
            } else {
                endPoint = board.getCoordinate(endPosition);
            }
        }
        
        if (startPoint == null || endPoint == null) {
            // 如果无法计算路径，直接移动
            System.out.println("Could not determine animation path. Moving piece directly.");
            boolean success = game.movePiece(piece);
            System.out.println("Direct move completed with success: " + success);
            
            // 正确更新UI状态
            if (success) {
                canSelectPieces = game.isReThrowAllowed();
                updateUIAfterMove();
            } else {
                // 恢复UI状态
                canSelectPieces = true;
                selectedPieces.clear();
                currentActionLabel.setText("Move failed! Try selecting another piece.");
                repaint();
            }
            return;
        }
        
        pathPoints.add(startPoint);
        
        // 对于从-1到0的移动，添加明确的中间点
        if (startPosition == -1 && endPosition == 0) {
            // 添加一个中间点，使动画更平滑
            Point midPoint = new Point(
                (startPoint.x + endPoint.x) / 2,
                (startPoint.y + endPoint.y) / 2
            );
            pathPoints.add(midPoint);
        }
        
        pathPoints.add(endPoint);
        
        // 创建动画计时器
        final int[] currentStep = {0};
        final int totalSteps = 15; // 增加总帧数以延长动画
        
        // 创建动画中显示的临时棋子位置
        final Point[] currentAnimationPoint = {new Point(startPoint)};
        
        Timer moveTimer = new Timer(50, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                currentStep[0]++;
                
                // 计算当前动画位置
                if (pathPoints.size() >= 2) {
                    float progress = (float) currentStep[0] / totalSteps;
                    if (progress > 1.0f) progress = 1.0f;
                    
                    // 使用二次方缓动使动画更自然
                    float easeProgress = progress < 0.5f ? 
                        2 * progress * progress : 
                        -1 + (4 - 2 * progress) * progress;
                    
                    if (pathPoints.size() == 2) {
                        // 只有起点和终点的简单动画
                        Point start = pathPoints.get(0);
                        Point end = pathPoints.get(1);
                        
                        currentAnimationPoint[0].x = start.x + (int)((end.x - start.x) * easeProgress);
                        currentAnimationPoint[0].y = start.y + (int)((end.y - start.y) * easeProgress);
                    } else {
                        // 多段路径动画
                        if (progress < 0.5f) {
                            // 第一段：从起点到中点
                            Point start = pathPoints.get(0);
                            Point mid = pathPoints.get(1);
                            float adjustedProgress = progress * 2; // 0-0.5 -> 0-1
                            
                            currentAnimationPoint[0].x = start.x + (int)((mid.x - start.x) * adjustedProgress);
                            currentAnimationPoint[0].y = start.y + (int)((mid.y - start.y) * adjustedProgress);
                        } else {
                            // 第二段：从中点到终点
                            Point mid = pathPoints.get(1);
                            Point end = pathPoints.get(2);
                            float adjustedProgress = (progress - 0.5f) * 2; // 0.5-1 -> 0-1
                            
                            currentAnimationPoint[0].x = mid.x + (int)((end.x - mid.x) * adjustedProgress);
                            currentAnimationPoint[0].y = mid.y + (int)((end.y - mid.y) * adjustedProgress);
                        }
                    }
                }
                
                // 当动画完成时
                if (currentStep[0] >= totalSteps) {
                    ((Timer)e.getSource()).stop();
                    
                    // 确保修复移动逻辑
                    System.out.println("Attempting to move piece " + piece.getId() + " for player " + piece.getOwner().getName());
                    System.out.println("Has rolled: " + game.hasRolled() + ", Current roll: " + game.getCurrentRoll());
                    System.out.println("Is piece owner current player? " + (piece.getOwner() == game.getCurrentPlayer()));
                    
                    // 完成实际移动
                    boolean success = game.movePiece(piece);
                    System.out.println("Move completed with success: " + success);
                    
                    // If the move failed, show an error message
                    if (!success) {
                        currentActionLabel.setText("Move failed! Make sure you've rolled the Yut sticks first.");
                        // 恢复UI状态
                        canSelectPieces = true;
                        selectedPieces.clear();
                    } else {
                        // 添加闪光效果表示移动完成
                        addMoveCompletionEffect(endPosition);
                        // 更新UI状态 - 这将在捕获棋子的情况下正确处理重掷
                        updateUIAfterMove();
                    }
                    
                    // 无论如何都重绘
                    repaint();
                }
                
                // 无论如何都要重绘
                repaint();
            }
        });
        
        moveTimer.start();
    }
    
    /**
     * Updates UI elements after a move
     */
    private void updateUIAfterMove() {
        if (game.isReThrowAllowed()) {
            // 如果允许重新投掷，更新提示
            movementHintLabel.setText(game.getCurrentPlayer().getName() + " gets another turn! Throw the Yut sticks again.");
            currentActionLabel.setText("Throw the Yut sticks for your bonus turn");
            
            // 重要：重新启用掷骰子按钮，确保玩家可以再次掷骰子
            YutStickPanel yutPanel = getYutStickPanel();
            if (yutPanel != null) {
                yutPanel.reset();
                yutPanel.setThrowEnabled(true);
                yutPanel.highlightThrowButton();
            }
        } else {
            // 如果移动完成且无再次掷骰机会，提示结束回合
            movementHintLabel.setText(game.getCurrentPlayer().getName() + " finished moving. End your turn.");
            currentActionLabel.setText("Click 'End Turn' to finish your turn");
        }
        
        // 确保标签可见
        movementHintLabel.setVisible(true);
        
        // 清除选中的棋子
        selectedPieces.clear();
        
        repaint();
    }
    
    /**
     * 尝试获取YutStickPanel的引用以便更新投掷按钮状态
     */
    private YutStickPanel getYutStickPanel() {
        Container parent = getParent();
        while (parent != null && !(parent instanceof JFrame)) {
            parent = parent.getParent();
        }
        
        if (parent instanceof JFrame) {
            JFrame frame = (JFrame) parent;
            for (Component comp : frame.getContentPane().getComponents()) {
                if (comp instanceof JPanel) {
                    // 检查右侧面板
                    JPanel panel = (JPanel) comp;
                    for (Component innerComp : panel.getComponents()) {
                        if (innerComp instanceof YutStickPanel) {
                            return (YutStickPanel) innerComp;
                        }
                    }
                }
            }
        }
        
        return null;
    }
    
    /**
     * Gets the piece at the specified coordinates.
     * 
     * @param x The x-coordinate
     * @param y The y-coordinate
     * @return The piece at the given coordinates, or null if none
     */
    private Piece getPieceAt(int x, int y) {
        // Check pieces on the board
        for (Player player : game.getPlayers()) {
            for (Piece piece : player.getPieces()) {
                // Skip pieces that are stacked (not the leader)
                if (piece.isStacked()) {
                    continue;
                }
                
                Point piecePos = getPieceDrawPosition(piece);
                if (piecePos != null) {
                    // Create a circle representing the piece
                    Ellipse2D pieceShape = new Ellipse2D.Double(
                            piecePos.x - PIECE_SIZE / 2,
                            piecePos.y - PIECE_SIZE / 2,
                            PIECE_SIZE,
                            PIECE_SIZE);
                    
                    if (pieceShape.contains(x, y)) {
                        return piece;
                    }
                }
            }
        }
        
        // Check home areas for off-board pieces
        int playerIndex = 0;
        for (Player player : game.getPlayers()) {
            if (player != game.getCurrentPlayer()) {
                playerIndex++;
                continue;
            }
            
            Rectangle homeArea = homeAreas[playerIndex];
            if (homeArea.contains(x, y)) {
                // Find a piece that's not on the board and not selected yet
                for (Piece piece : player.getPieces()) {
                    if (piece.getPosition() == -1 && !piece.isStacked() && !selectedPieces.contains(piece)) {
                        return piece;
                    }
                }
            }
            
            break;
        }
        
        return null;
    }
    
    /**
     * Gets the drawing position for a piece on the board.
     * 
     * @param piece The piece to get position for
     * @return The position to draw the piece at, or null if off board
     */
    private Point getPieceDrawPosition(Piece piece) {
        int position = piece.getPosition();
        
        // If piece is not on board, return null
        if (position == -1) {
            return null;
        }
        
        // If piece has finished, draw it at home
        if (position == 30) {
            int playerIndex = 0;
            for (Player player : game.getPlayers()) {
                if (player == piece.getOwner()) {
                    break;
                }
                playerIndex++;
            }
            
            Rectangle homeArea = homeAreas[playerIndex];
            return new Point(homeArea.x + homeArea.width / 2, homeArea.y + homeArea.height / 2);
        }
        
        // Get position from board
        Point boardPos = board.getCoordinate(position);
        if (boardPos == null) {
            return null;
        }
        
        // Calculate offset based on stack position
        int stackIndex = 0;
        if (piece.hasStackedPieces()) {
            stackIndex = 0; // Leader is at index 0
        } else if (piece.isStacked()) {
            // Find index in stack
            Piece leader = piece.getStackLeader();
            stackIndex = leader.getStackedPieces().indexOf(piece) + 1;
        }
        
        // Apply offset for stacked pieces
        int offsetX = STACK_OFFSETS_X[stackIndex % STACK_OFFSETS_X.length];
        int offsetY = STACK_OFFSETS_Y[stackIndex % STACK_OFFSETS_Y.length];
        
        return new Point(boardPos.x + offsetX, boardPos.y + offsetY);
    }
    
    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2d = (Graphics2D) g;
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        
        // Draw the board with improved visibility
        drawEnhancedBoard(g2d);
        
        // Draw possible moves if showing hints
        if (showingHints) {
            if (selectedPieces.isEmpty()) {
                // 高亮所有可移动的棋子
                highlightMovablePieces(g2d);
            } else {
                // 高亮选中棋子的移动路径
                drawPossibleMoves(g2d);
            }
        }
        
        // Draw player homes
        drawPlayerHomes(g2d);
        
        // Draw pieces
        drawPieces(g2d);
        
        // Draw turn indicator
        drawTurnIndicator(g2d);
        
        // Draw game over message if applicable
        if (game.isGameOver()) {
            drawGameOverMessage(g2d);
        }
    }
    
    /**
     * Draws an enhanced version of the game board.
     * 
     * @param g2d The Graphics2D object to draw with
     */
    private void drawEnhancedBoard(Graphics2D g2d) {
        // 获取当前棋盘尺寸
        int boardSize = BOARD_SIZE;
        
        // 计算棋盘位置和大小，确保居中放置
        int boardX = boardSize / 4;
        int boardY = 80;
        int boardWidth = boardSize / 2 + boardSize / 4;
        int boardHeight = boardSize - 160;
        
        // Draw board background
        g2d.setColor(new Color(245, 240, 215)); // Soft beige for board background
        g2d.fillRect(boardX, boardY, boardWidth, boardHeight);
        
        // Draw border
        g2d.setColor(new Color(139, 69, 19)); // Brown
        g2d.setStroke(new BasicStroke(3)); 
        g2d.drawRect(boardX, boardY, boardWidth, boardHeight);
        
        // 固定棋盘轨道位置
        int leftX = boardX + 40;    // Left
        int rightX = boardX + boardWidth - 40; // Right
        int topY = boardY + 40;     // Top
        int bottomY = boardY + boardHeight - 40; // Bottom
        int midY = boardY + boardHeight/2;    // Vertical center
        int midX = boardX + boardWidth/2;     // Horizontal center
        
        // Draw outer track with thicker lines
        g2d.setColor(new Color(160, 82, 45)); // Brown
        g2d.setStroke(new BasicStroke(2)); 
        
        // Draw vertical lines
        g2d.drawLine(leftX, topY, leftX, bottomY); // Left
        g2d.drawLine(rightX, topY, rightX, bottomY); // Right
        
        // Draw horizontal lines
        g2d.drawLine(leftX, topY, rightX, topY); // Top
        g2d.drawLine(leftX, bottomY, rightX, bottomY); // Bottom
        
        // Draw diagonal lines
        g2d.drawLine(leftX, bottomY, rightX, topY); // Bottom-left to top-right
        g2d.drawLine(leftX, topY, rightX, bottomY); // Top-left to bottom-right
        
        // Draw center lines
        g2d.setColor(new Color(160, 82, 45, 150)); // Lighter brown
        g2d.drawLine(leftX, midY, rightX, midY); // Horizontal center
        g2d.drawLine(midX, topY, midX, bottomY); // Vertical center
        
        // Draw all positions - 不再使用updateBoardCoordinates方法，直接绘制
        for (int i = 0; i <= 29; i++) {
            Point pos = board.getCoordinate(i);
            if (pos != null) {
                boolean isCorner = board.isCorner(i);
                drawBoardPosition(g2d, pos.x, pos.y, isCorner, i);
            }
        }
        
        // Draw legend for better understanding
        drawBoardLegend(g2d);
    }
    
    /**
     * Draws a legend explaining the board elements.
     * 
     * @param g2d The Graphics2D object to draw with
     */
    private void drawBoardLegend(Graphics2D g2d) {
        // 根据棋盘大小调整图例位置
        int boardSize = BOARD_SIZE;
        int legendX = 15;
        int legendY = 160;
        int legendWidth = 140;
        int legendHeight = 90;
        
        // 绘制背景框
        g2d.setColor(new Color(250, 250, 240, 220));
        g2d.fillRoundRect(legendX, legendY, legendWidth, legendHeight, 10, 10);
        g2d.setColor(new Color(139, 69, 19));
        g2d.setStroke(new BasicStroke(1.5f));
        g2d.drawRoundRect(legendX, legendY, legendWidth, legendHeight, 10, 10);
        
        // 标题
        g2d.setColor(new Color(139, 69, 19));
        g2d.setFont(new Font("SansSerif", Font.BOLD, 12));
        g2d.drawString("Board Legend:", legendX + 10, legendY + 20);
        
        // 图例项目
        g2d.setFont(new Font("SansSerif", Font.PLAIN, 11));
        
        // Main Path
        g2d.setColor(new Color(0, 0, 0));
        g2d.drawString("Main Path", legendX + 10, legendY + 40);
        g2d.setColor(new Color(160, 82, 45));
        g2d.setStroke(new BasicStroke(2));
        g2d.drawLine(legendX + 80, legendY + 37, legendX + 120, legendY + 37);
        
        // Shortcut Paths
        g2d.setColor(new Color(0, 0, 0));
        g2d.drawString("Shortcut Paths", legendX + 10, legendY + 60);
        g2d.setColor(new Color(0, 100, 0));
        g2d.drawLine(legendX + 80, legendY + 57, legendX + 120, legendY + 57);
        
        // Corner Positions
        g2d.setColor(new Color(0, 0, 0));
        g2d.drawString("Corner Positions", legendX + 10, legendY + 80);
        g2d.setColor(new Color(139, 69, 19));
        g2d.fillOval(legendX + 100, legendY + 75, 10, 10);
    }
    
    /**
     * Draws the game board.
     * 
     * @param g2d The Graphics2D object to draw with
     */
    private void drawBoard(Graphics2D g2d) {
        // Draw outer track
        g2d.setColor(new Color(160, 82, 45)); // Brown
        g2d.setStroke(new BasicStroke(3));
        
        // Draw vertical lines
        g2d.drawLine(300, 100, 300, 700); // Left
        g2d.drawLine(800, 100, 800, 700); // Right
        
        // Draw horizontal lines
        g2d.drawLine(300, 100, 800, 100); // Top
        g2d.drawLine(300, 700, 800, 700); // Bottom
        
        // Draw diagonal lines
        g2d.drawLine(300, 700, 800, 100); // Bottom-left to top-right
        g2d.drawLine(300, 100, 800, 700); // Top-left to bottom-right
        
        // Draw positions
        for (int i = 0; i <= 29; i++) {
            Point pos = board.getCoordinate(i);
            if (pos != null) {
                boolean isCorner = board.isCorner(i);
                drawBoardPosition(g2d, pos.x, pos.y, isCorner);
            }
        }
    }
    
    /**
     * Draws a position marker on the board.
     * 
     * @param g2d The Graphics2D object to draw with
     * @param x The x-coordinate
     * @param y The y-coordinate
     * @param isCorner Whether this is a corner position
     * @param positionNumber The position number to display
     */
    private void drawBoardPosition(Graphics2D g2d, int x, int y, boolean isCorner, int positionNumber) {
        if (isCorner) {
            // Draw larger, distinguished circle for corners
            g2d.setColor(new Color(139, 69, 19)); // Saddle brown
            g2d.fillOval(x - POSITION_SIZE / 2, y - POSITION_SIZE / 2, POSITION_SIZE, POSITION_SIZE);
            g2d.setColor(Color.BLACK);
            g2d.drawOval(x - POSITION_SIZE / 2, y - POSITION_SIZE / 2, POSITION_SIZE, POSITION_SIZE);
        } else {
            // Regular position
            g2d.setColor(new Color(210, 180, 140)); // Tan
            g2d.fillOval(x - POSITION_SIZE / 3, y - POSITION_SIZE / 3, 2 * POSITION_SIZE / 3, 2 * POSITION_SIZE / 3);
            g2d.setColor(Color.BLACK);
            g2d.drawOval(x - POSITION_SIZE / 3, y - POSITION_SIZE / 3, 2 * POSITION_SIZE / 3, 2 * POSITION_SIZE / 3);
        }
        
        // 总是绘制位置编号，确保可见性
        if (positionNumber >= 0) {
            // 最后在位置上方绘制数字
            g2d.setColor(new Color(0, 0, 0));  // 使用黑色而不是白色，以确保在任何背景上都可见
            g2d.setFont(new Font("SansSerif", Font.BOLD, 12));  // 增大字体以提高可读性
            String positionText = String.valueOf(positionNumber);
            FontMetrics fm = g2d.getFontMetrics();
            int textWidth = fm.stringWidth(positionText);
            g2d.drawString(positionText, x - textWidth/2, y + 4);
        }
    }
    
    /**
     * 兼容旧的调用方法
     */
    private void drawBoardPosition(Graphics2D g2d, int x, int y, boolean isCorner) {
        drawBoardPosition(g2d, x, y, isCorner, -1); // 使用-1表示不显示数字
    }
    
    /**
     * Draws the home areas for each player.
     * 
     * @param g2d The Graphics2D object to draw with
     */
    private void drawPlayerHomes(Graphics2D g2d) {
        // Draw all player home areas with fixed positions
        int playerIndex = 0;
        for (Player player : game.getPlayers()) {
            Rectangle homeArea = homeAreas[playerIndex];
            
            g2d.setColor(player.getColor());
            g2d.fillRect(homeArea.x, homeArea.y, homeArea.width, homeArea.height);
            g2d.setColor(Color.BLACK);
            g2d.drawRect(homeArea.x, homeArea.y, homeArea.width, homeArea.height);
            
            // 添加名称背景确保可读性
            String playerName = player.getName();
            g2d.setFont(new Font("SansSerif", Font.BOLD, 14));
            FontMetrics fm = g2d.getFontMetrics();
            int textWidth = fm.stringWidth(playerName);
            int textHeight = fm.getHeight();
            
            // 绘制半透明背景
            g2d.setColor(new Color(0, 0, 0, 150));
            g2d.fillRect(
                homeArea.x + (homeArea.width - textWidth - 10) / 2, 
                homeArea.y + homeArea.height - textHeight - 5,
                textWidth + 10, 
                textHeight + 2
            );
            
            // 绘制玩家名称
            g2d.setColor(Color.WHITE);
            g2d.drawString(playerName, 
                homeArea.x + (homeArea.width - textWidth) / 2, 
                homeArea.y + homeArea.height - 10);
            
            playerIndex++;
        }
    }
    
    /**
     * Draws all player pieces on the board.
     * 
     * @param g2d The Graphics2D object to draw with
     */
    private void drawPieces(Graphics2D g2d) {
        int playerIndex = 0;
        for (Player player : game.getPlayers()) {
            // Always draw in designated corners regardless of player turn
            Rectangle homeArea = homeAreas[playerIndex];
            playerIndex++;
            
            // Draw pieces that are not on the board in player's home area
            List<Piece> offBoardPieces = new ArrayList<>();
            for (Piece piece : player.getPieces()) {
                if (piece.getPosition() == -1 && !piece.isStacked()) {
                    offBoardPieces.add(piece);
                }
            }
            
            // Arrange off-board pieces in the home area
            int offsetX = homeArea.width / 5;
            int offsetY = homeArea.height / 5;
            
            // Draw off-board pieces
            for (int i = 0; i < offBoardPieces.size(); i++) {
                Piece piece = offBoardPieces.get(i);
                int row = i / 2;
                int col = i % 2;
                int x = homeArea.x + offsetX + col * 2 * offsetX;
                int y = homeArea.y + offsetY + row * 2 * offsetY;
                
                drawPiece(g2d, piece, x, y);
            }
            
            // Draw pieces on the board
            for (Piece piece : player.getPieces()) {
                // Skip pieces that are stacked (not the leader)
                if (piece.isStacked()) {
                    continue;
                }
                
                // Skip pieces that are not on the board
                if (piece.getPosition() == -1) {
                    continue;
                }
                
                Point pos = getPieceDrawPosition(piece);
                if (pos != null) {
                    drawPiece(g2d, piece, pos.x, pos.y);
                    
                    // Draw stacked pieces
                    if (piece.hasStackedPieces()) {
                        for (Piece stackedPiece : piece.getStackedPieces()) {
                            Point stackedPos = getPieceDrawPosition(stackedPiece);
                            if (stackedPos != null) {
                                drawPiece(g2d, stackedPiece, stackedPos.x, stackedPos.y);
                            }
                        }
                    }
                }
            }
        }
    }
    
    /**
     * Draws a single piece.
     * 
     * @param g2d The Graphics2D object to draw with
     * @param piece The piece to draw
     * @param x The x-coordinate
     * @param y The y-coordinate
     */
    private void drawPiece(Graphics2D g2d, Piece piece, int x, int y) {
        Color pieceColor = piece.getOwner().getColor();
        
        // Draw piece
        g2d.setColor(pieceColor);
        g2d.fillOval(x - PIECE_SIZE / 2, y - PIECE_SIZE / 2, PIECE_SIZE, PIECE_SIZE);
        
        // Draw outline
        g2d.setColor(Color.BLACK);
        g2d.drawOval(x - PIECE_SIZE / 2, y - PIECE_SIZE / 2, PIECE_SIZE, PIECE_SIZE);
        
        // Highlight selected pieces
        if (selectedPieces.contains(piece)) {
            g2d.setColor(Color.YELLOW);
            g2d.setStroke(new BasicStroke(3));
            g2d.drawOval(x - PIECE_SIZE / 2 - 3, y - PIECE_SIZE / 2 - 3, PIECE_SIZE + 6, PIECE_SIZE + 6);
        }
        
        // Draw piece ID
        g2d.setColor(Color.WHITE);
        g2d.setFont(new Font("Arial", Font.BOLD, 12));
        String id = String.valueOf(piece.getId() + 1);
        FontMetrics fm = g2d.getFontMetrics();
        int textWidth = fm.stringWidth(id);
        int textHeight = fm.getHeight();
        g2d.drawString(id, x - textWidth / 2, y + textHeight / 4);
    }
    
    /**
     * Draws the turn indicator.
     * 
     * @param g2d The Graphics2D object to draw with
     */
    private void drawTurnIndicator(Graphics2D g2d) {
        Player currentPlayer = game.getCurrentPlayer();
        
        // 获取当前棋盘尺寸
        int boardSize = BOARD_SIZE;
        
        // 将回合指示器移到顶部中央，避免被遮挡
        int indicatorWidth = boardSize / 2;
        int indicatorHeight = 40;
        int indicatorX = (boardSize - indicatorWidth) / 2;
        int indicatorY = 5;
        
        // 创建更醒目的背景
        g2d.setColor(new Color(245, 245, 220, 240));
        g2d.fillRoundRect(indicatorX, indicatorY, indicatorWidth, indicatorHeight, 15, 15);
        g2d.setColor(new Color(139, 69, 19));
        g2d.setStroke(new BasicStroke(2));
        g2d.drawRoundRect(indicatorX, indicatorY, indicatorWidth, indicatorHeight, 15, 15);
        
        // 绘制具有描边效果的文本，使其更加突出
        String turnText = "Current Turn: " + currentPlayer.getName();
        
        // 减小描边效果
        g2d.setColor(new Color(0, 0, 0));
        g2d.setFont(new Font("SansSerif", Font.BOLD, 18));
        
        // 使用FontMetrics绘制居中文本
        FontMetrics fm = g2d.getFontMetrics();
        int textWidth = fm.stringWidth(turnText);
        int textX = indicatorX + (indicatorWidth - textWidth) / 2;
        
        g2d.drawString(turnText, textX, indicatorY + 28);
    }
    
    /**
     * Draws a game over message.
     * 
     * @param g2d The Graphics2D object to draw with
     */
    private void drawGameOverMessage(Graphics2D g2d) {
        Player winner = game.getWinner();
        if (winner == null) {
            return;
        }
        
        // 半透明背景
        g2d.setColor(new Color(0, 0, 0, 180)); // 更透明的背景
        g2d.fillRect(0, 0, getWidth(), getHeight());
        
        // 创建胜利消息区域
        int messageWidth = 500;
        int messageHeight = 300;
        int messageX = (getWidth() - messageWidth) / 2;
        int messageY = (getHeight() - messageHeight) / 2;
        
        // 使用获胜者的颜色
        Color winnerColor = winner.getColor();
        Color darkerColor = new Color(
            Math.max(0, winnerColor.getRed() - 50),
            Math.max(0, winnerColor.getGreen() - 50),
            Math.max(0, winnerColor.getBlue() - 50),
            240
        );
        
        // 填充背景
        g2d.setColor(new Color(255, 255, 255, 240));
        g2d.fillRoundRect(messageX, messageY, messageWidth, messageHeight, 30, 30);
        
        // 添加边框
        g2d.setStroke(new BasicStroke(5f));
        g2d.setColor(winner.getColor());
        g2d.drawRoundRect(messageX, messageY, messageWidth, messageHeight, 30, 30);
        
        // 闪烁边框效果
        float alpha = 0.5f + 0.5f * (float)Math.sin(pulseCounter * 0.3);
        g2d.setColor(new Color(
            255, 255, 255, 
            (int)(alpha * 200)
        ));
        g2d.setStroke(new BasicStroke(2f));
        g2d.drawRoundRect(messageX + 5, messageY + 5, messageWidth - 10, messageHeight - 10, 25, 25);
        
        // 绘制"游戏结束"标题
        g2d.setFont(new Font("Arial", Font.BOLD, 48));
        g2d.setColor(new Color(50, 50, 50));
        String gameOverText = "游戏结束!";
        FontMetrics fm = g2d.getFontMetrics();
        int gameOverWidth = fm.stringWidth(gameOverText);
        g2d.drawString(gameOverText, messageX + (messageWidth - gameOverWidth) / 2 + 2, messageY + 80 + 2);
        
        // 绘制游戏结束文字（添加阴影效果）
        g2d.setColor(new Color(245, 245, 245));
        g2d.drawString(gameOverText, messageX + (messageWidth - gameOverWidth) / 2, messageY + 80);
        
        // 绘制获胜者信息
        g2d.setFont(new Font("Arial", Font.BOLD, 36));
        String winnerText = winner.getName() + " 获胜!";
        fm = g2d.getFontMetrics();
        int winnerWidth = fm.stringWidth(winnerText);
        
        // 绘制文字阴影
        g2d.setColor(new Color(80, 80, 80));
        g2d.drawString(winnerText, messageX + (messageWidth - winnerWidth) / 2 + 2, messageY + 160 + 2);
        
        // 绘制带有获胜者颜色的文字
        g2d.setColor(winner.getColor());
        g2d.drawString(winnerText, messageX + (messageWidth - winnerWidth) / 2, messageY + 160);
        
        // 添加重新开始游戏的提示
        g2d.setFont(new Font("Arial", Font.PLAIN, 20));
        String restartText = "点击 'New Game' 开始新的游戏";
        fm = g2d.getFontMetrics();
        int restartWidth = fm.stringWidth(restartText);
        
        // 绘制闪烁的提示文字
        int brightness = 100 + (int)(155 * Math.sin(pulseCounter * 0.2));
        g2d.setColor(new Color(brightness, brightness, brightness));
        g2d.drawString(restartText, messageX + (messageWidth - restartWidth) / 2, messageY + 220);
        
        // 绘制星星装饰效果
        drawVictoryStars(g2d);
    }
    
    /**
     * 绘制胜利庆祝的星星装饰效果
     */
    private void drawVictoryStars(Graphics2D g2d) {
        // 根据脉冲计数器计算星星的位置和大小
        int numStars = 20;
        Random random = new Random(123); // 固定种子使星星位置保持一致
        
        for (int i = 0; i < numStars; i++) {
            // 计算星星位置 (随机分布在屏幕周围)
            int x = random.nextInt(getWidth());
            int y = random.nextInt(getHeight());
            
            // 计算星星大小 (基于脉冲计数器，使它们闪烁)
            float starPhase = (pulseCounter * 0.2f + i * 0.5f) % 10;
            float starSize = 5 + 15 * Math.abs((starPhase - 5) / 5);
            
            // 计算星星颜色 (随机亮色)
            int r = 150 + random.nextInt(105);
            int g = 150 + random.nextInt(105);
            int b = 150 + random.nextInt(105);
            int alpha = 150 + (int)(105 * Math.sin(starPhase));
            
            Color starColor = new Color(r, g, b, alpha);
            
            // 绘制星星
            drawStar(g2d, x, y, starSize, starColor);
        }
    }
    
    /**
     * 在指定位置绘制一颗星星
     */
    private void drawStar(Graphics2D g2d, int x, int y, float size, Color color) {
        // 创建星星的形状
        int numPoints = 5;
        int[] xPoints = new int[numPoints * 2];
        int[] yPoints = new int[numPoints * 2];
        
        double angle = Math.PI / numPoints;
        double outerRadius = size;
        double innerRadius = size / 2;
        
        for (int i = 0; i < numPoints * 2; i++) {
            double r = (i % 2 == 0) ? outerRadius : innerRadius;
            double theta = i * angle;
            xPoints[i] = x + (int)(r * Math.sin(theta));
            yPoints[i] = y + (int)(r * Math.cos(theta));
        }
        
        // 填充星星
        g2d.setColor(color);
        g2d.fillPolygon(xPoints, yPoints, numPoints * 2);
    }
    
    /**
     * Draws indicators for possible move positions.
     * 
     * @param g2d The Graphics2D object to draw with
     */
    private void drawPossibleMoves(Graphics2D g2d) {
        if (selectedPieces.isEmpty()) {
            return;
        }

        Piece selectedPiece = selectedPieces.get(0);
        int currentPosition = selectedPiece.getPosition();
        int newPosition = board.getNextPosition(currentPosition, game.getCurrentRoll());
        
        System.out.println("Drawing move path from " + currentPosition + " to " + newPosition);
        
        // Draw path arrow from current position to new position
        if (currentPosition != -1 && newPosition != 30) {
            Point startPos = board.getCoordinate(currentPosition);
            Point endPos = board.getCoordinate(newPosition);
            
            if (startPos != null && endPos != null) {
                // 使用脉冲效果增强路径指示
                int alpha = 150 + (int)(50 * Math.sin(pulseCounter * 0.6));
                
                // Draw path arrow - 增加线宽
                g2d.setColor(new Color(0, 200, 0, alpha)); // Semi-transparent green with pulsing
                g2d.setStroke(new BasicStroke(5, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND)); // 更粗的线
                
                // Draw arrow line
                g2d.drawLine(startPos.x, startPos.y, endPos.x, endPos.y);
                
                // Draw arrow head - 增大箭头
                double angle = Math.atan2(endPos.y - startPos.y, endPos.x - startPos.x);
                int arrowSize = 20; // 更大的箭头
                int x1 = (int)(endPos.x - arrowSize * Math.cos(angle - Math.PI/6));
                int y1 = (int)(endPos.y - arrowSize * Math.sin(angle - Math.PI/6));
                int x2 = (int)(endPos.x - arrowSize * Math.cos(angle + Math.PI/6));
                int y2 = (int)(endPos.y - arrowSize * Math.sin(angle + Math.PI/6));
                
                g2d.drawLine(endPos.x, endPos.y, x1, y1);
                g2d.drawLine(endPos.x, endPos.y, x2, y2);
                
                // 添加一个虚线辅助线增强视觉效果
                g2d.setStroke(new BasicStroke(2, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND, 0, new float[]{5, 5}, 0));
                g2d.setColor(new Color(0, 200, 0, 100));
                g2d.drawLine(startPos.x, startPos.y, endPos.x, endPos.y);
            }
        } else if (currentPosition == -1) {
            // Draw arrow from home to start position
            int playerIndex = 0;
            for (Player player : game.getPlayers()) {
                if (player == selectedPiece.getOwner()) {
                    break;
                }
                playerIndex++;
            }
            Rectangle homeArea = homeAreas[playerIndex];
            Point startPos = new Point(homeArea.x + homeArea.width / 2, homeArea.y + homeArea.height / 2);
            Point endPos = board.getCoordinate(0); // Start position
            
            if (endPos != null) {
                // 使用脉冲效果增强路径指示
                int alpha = 200 + (int)(55 * Math.sin(pulseCounter * 0.6));
                
                // Draw path arrow - 增加线宽
                g2d.setColor(new Color(0, 200, 0, alpha)); // 加深颜色
                g2d.setStroke(new BasicStroke(5, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND)); // 更粗的线
                
                // Draw arrow line
                g2d.drawLine(startPos.x, startPos.y, endPos.x, endPos.y);
                
                // Draw arrow head - 增大箭头
                double angle = Math.atan2(endPos.y - startPos.y, endPos.x - startPos.x);
                int arrowSize = 20; // 更大的箭头
                int x1 = (int)(endPos.x - arrowSize * Math.cos(angle - Math.PI/6));
                int y1 = (int)(endPos.y - arrowSize * Math.sin(angle - Math.PI/6));
                int x2 = (int)(endPos.x - arrowSize * Math.cos(angle + Math.PI/6));
                int y2 = (int)(endPos.y - arrowSize * Math.sin(angle + Math.PI/6));
                
                g2d.drawLine(endPos.x, endPos.y, x1, y1);
                g2d.drawLine(endPos.x, endPos.y, x2, y2);
                
                // 添加一个明亮的"起始点"提示
                g2d.setColor(new Color(255, 255, 0, 150)); // 黄色
                g2d.fillOval(endPos.x - 15, endPos.y - 15, 30, 30);
                g2d.setColor(new Color(0, 100, 0));
                g2d.setStroke(new BasicStroke(2));
                g2d.drawOval(endPos.x - 15, endPos.y - 15, 30, 30);
                
                // 添加文字提示
                g2d.setFont(new Font("Arial", Font.BOLD, 14));
                g2d.drawString("Start Here", endPos.x - 35, endPos.y - 20);
            }
        }
        
        // Draw destination position highlight
        if (newPosition != 30) { // Not finished
            Point pos = board.getCoordinate(newPosition);
            if (pos != null) {
                // 使用脉冲效果增强目标位置高亮
                float pulseSize = 1.0f + (float)Math.sin(pulseCounter * 0.6) * 0.3f; // 增强脉冲效果
                int highlightSize = (int)((POSITION_SIZE + 20) * pulseSize); // 更大的高亮区域
                
                // Draw highlight around destination position - 添加双层高亮
                g2d.setColor(new Color(0, 200, 0, 70)); // 外层淡绿色
                g2d.fillOval(pos.x - highlightSize / 2, pos.y - highlightSize / 2, 
                             highlightSize, highlightSize);
                
                // 内层高亮
                g2d.setColor(new Color(50, 220, 50, 130)); // 内层亮绿色
                g2d.fillOval(pos.x - highlightSize / 3, pos.y - highlightSize / 3, 
                            2 * highlightSize / 3, 2 * highlightSize / 3);
                
                // 添加闪烁边框
                g2d.setStroke(new BasicStroke(3));
                g2d.setColor(new Color(255, 255, 100, 150 + (int)(100 * Math.sin(pulseCounter * 0.6))));
                g2d.drawOval(pos.x - highlightSize / 4, pos.y - highlightSize / 4, 
                            highlightSize / 2, highlightSize / 2);
                
                // Draw "Move here" text - 更醒目的文字
                g2d.setColor(new Color(0, 0, 0));
                g2d.setFont(new Font("Arial", Font.BOLD, 16));
                String moveHere = "Move here!";
                FontMetrics fm = g2d.getFontMetrics();
                int textWidth = fm.stringWidth(moveHere);
                
                // 绘制文字背景
                g2d.setColor(new Color(255, 255, 220, 220));
                g2d.fillRoundRect(pos.x - textWidth/2 - 5, pos.y - POSITION_SIZE - 25, 
                                textWidth + 10, 25, 10, 10);
                
                // 绘制文字
                g2d.setColor(new Color(0, 100, 0));
                g2d.drawString(moveHere, pos.x - textWidth/2, pos.y - POSITION_SIZE - 8);
            }
        } else {
            // Show finish indicator with pulsing effect
            int alpha = 150 + (int)(100 * Math.sin(pulseCounter * 0.6));
            g2d.setColor(new Color(0, 200, 0, alpha));
            g2d.setFont(new Font("Arial", Font.BOLD, 20)); // 更大的字体
            
            // 绘制提示背景
            String finishText = "Move to Finish!";
            FontMetrics fm = g2d.getFontMetrics();
            int textWidth = fm.stringWidth(finishText);
            
            g2d.setColor(new Color(255, 255, 220, 220));
            g2d.fillRoundRect(350 - 10, 750 - 20, textWidth + 20, 30, 15, 15);
            
            g2d.setColor(new Color(0, 150, 0, alpha));
            g2d.drawString(finishText, 350, 750);
            
            // Draw arrow to finish - 更明显的完成箭头
            int playerIndex = 0;
            for (Player player : game.getPlayers()) {
                if (player == selectedPiece.getOwner()) {
                    break;
                }
                playerIndex++;
            }
            Rectangle homeArea = homeAreas[playerIndex];
            
            // 计算当前位置和终点位置
            Point currentPos = board.getCoordinate(currentPosition);
            Point finishPos = new Point(homeArea.x + homeArea.width/2, homeArea.y + homeArea.height/2);
            
            if (currentPos != null) {
                g2d.setStroke(new BasicStroke(5, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
                g2d.setColor(new Color(0, 200, 0, alpha));
                g2d.drawLine(currentPos.x, currentPos.y, finishPos.x, finishPos.y);
                
                // 绘制箭头
                double angle = Math.atan2(finishPos.y - currentPos.y, finishPos.x - currentPos.x);
                int arrowSize = 20;
                int x1 = (int)(finishPos.x - arrowSize * Math.cos(angle - Math.PI/6));
                int y1 = (int)(finishPos.y - arrowSize * Math.sin(angle - Math.PI/6));
                int x2 = (int)(finishPos.x - arrowSize * Math.cos(angle + Math.PI/6));
                int y2 = (int)(finishPos.y - arrowSize * Math.sin(angle + Math.PI/6));
                
                g2d.drawLine(finishPos.x, finishPos.y, x1, y1);
                g2d.drawLine(finishPos.x, finishPos.y, x2, y2);
                
                // 高亮终点区域
                g2d.setColor(new Color(255, 255, 0, 100));
                float pulseSize = 1.0f + (float)Math.sin(pulseCounter * 0.6) * 0.2f;
                int highlightSize = (int)(100 * pulseSize);
                g2d.fillOval(finishPos.x - highlightSize/2, finishPos.y - highlightSize/2, 
                           highlightSize, highlightSize);
            }
        }
    }
    
    /**
     * 高亮所有可移动的棋子
     */
    private void highlightMovablePieces(Graphics2D g2d) {
        Player currentPlayer = game.getCurrentPlayer();
        if (canSelectPieces && game.hasRolled()) {
            g2d.setColor(new Color(200, 0, 0, 200));
            g2d.setFont(new Font("Arial", Font.BOLD, 14));
            String hintText = "Select one of " + currentPlayer.getName() + "'s pieces to move";
            FontMetrics fm = g2d.getFontMetrics();
            int textWidth = fm.stringWidth(hintText);
            g2d.drawString(hintText, (getWidth() - textWidth) / 2, 40);
            
            // 计算脉冲效果大小
            float pulseSize = 1.0f + (float)Math.sin(pulseCounter * 0.6) * 0.1f;
            
            // 查找所有可移动的棋子
            for (Piece piece : currentPlayer.getPieces()) {
                if (piece.canMove(game.getCurrentRoll()) && !piece.isStacked()) {
                    Point pos = getPieceDrawPosition(piece);
                    if (pos != null) {
                        // Draw pulsing highlight around movable pieces
                        int highlightSize = (int)(PIECE_SIZE * 2 * pulseSize);
                        g2d.setColor(new Color(255, 215, 0, 150)); // Gold color
                        g2d.fillOval(pos.x - highlightSize/2, pos.y - highlightSize/2, 
                            highlightSize, highlightSize);
                        
                        // 添加"可移动"指示文本
                        g2d.setColor(new Color(0, 0, 0));
                        g2d.setFont(new Font("Arial", Font.BOLD, 10));
                        g2d.drawString("Click", pos.x - 10, pos.y - PIECE_SIZE - 5);
                    } else if (piece.getPosition() == -1) {
                        // Highlight home area for pieces not on board
                        int playerIndex = 0;
                        for (Player player : game.getPlayers()) {
                            if (player == currentPlayer) {
                                break;
                            }
                            playerIndex++;
                        }
                        Rectangle homeArea = homeAreas[playerIndex];
                        g2d.setColor(new Color(255, 215, 0, 100)); // Gold color
                        
                        // 绘制带脉冲效果的高亮
                        int pulseWidth = (int)(homeArea.width * pulseSize);
                        int pulseHeight = (int)(homeArea.height * pulseSize);
                        int pulseX = homeArea.x - (pulseWidth - homeArea.width)/2;
                        int pulseY = homeArea.y - (pulseHeight - homeArea.height)/2;
                        
                        g2d.fillRect(pulseX, pulseY, pulseWidth, pulseHeight);
                        g2d.setColor(new Color(255, 215, 0));
                        g2d.setStroke(new BasicStroke(3.0f));
                        g2d.drawRect(homeArea.x, homeArea.y, homeArea.width, homeArea.height);
                        
                        // Add text hint for new pieces
                        g2d.setColor(new Color(0, 0, 0));
                        g2d.setFont(new Font("Arial", Font.BOLD, 12));
                        String homeHint = "Click to place a new piece";
                        g2d.drawString(homeHint, homeArea.x + 10, homeArea.y + homeArea.height / 2);
                    }
                }
            }
        }
    }
    
    /**
     * 重置游戏板状态
     */
    public void reset() {
        selectedPieces.clear();
        canSelectPieces = false;
        showingHints = false;
        movementHintLabel.setVisible(false);
        possibleMovePositions.clear();
        
        // Reset current action label
        currentActionLabel.setText("Throw the Yut sticks to begin your turn");
        
        repaint();
    }
    
    /**
     * 在移动完成后添加闪光效果
     */
    private void addMoveCompletionEffect(int position) {
        if (position == 30) {
            // 在玩家区域添加效果
            int playerIndex = 0;
            for (Player player : game.getPlayers()) {
                if (player == game.getCurrentPlayer()) {
                    break;
                }
                playerIndex++;
            }
            Rectangle homeArea = homeAreas[playerIndex];
            final Point pos = new Point(homeArea.x + homeArea.width / 2, homeArea.y + homeArea.height / 2);
            
            final int[] step = {0};
            final int totalSteps = 10;
            
            Timer effectTimer = new Timer(100, new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    step[0]++;
                    if (step[0] >= totalSteps) {
                        ((Timer)e.getSource()).stop();
                    } 
                    repaint();
                }
            });
            
            effectTimer.start();
            return;
        }
        
        final Point pos = board.getCoordinate(position);
        if (pos == null) return;
        
        final int[] step = {0};
        final int totalSteps = 10;
        
        Timer effectTimer = new Timer(100, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                step[0]++;
                if (step[0] >= totalSteps) {
                    ((Timer)e.getSource()).stop();
                } 
                repaint();
            }
        });
        
        effectTimer.start();
    }
    
    /**
     * Handles mouse clicks on the game board.
     * 
     * @param x The x-coordinate of the click
     * @param y The y-coordinate of the click
     */
    private void handleMouseClick(int x, int y) {
        if (!canSelectPieces || game.isGameOver()) {
            return;
        }
        
        Player currentPlayer = game.getCurrentPlayer();
        System.out.println("Handling click for " + currentPlayer.getName() + " at (" + x + ", " + y + ")");
        
        // Check if a piece was clicked
        Piece clickedPiece = getPieceAt(x, y);
        
        if (clickedPiece != null && clickedPiece.getOwner() == currentPlayer) {
            System.out.println("Clicked on piece " + clickedPiece.getId() + " at position " + clickedPiece.getPosition());
            
            // Check if the piece can move
            if (clickedPiece.canMove(game.getCurrentRoll())) {
                System.out.println("Piece can move with roll " + game.getCurrentRoll());
                
                // 如果之前已经选中了其他棋子，则取消选中
                if (!selectedPieces.isEmpty() && !selectedPieces.contains(clickedPiece)) {
                    selectedPieces.clear();
                }
                
                // 选中或取消选中棋子
                if (selectedPieces.contains(clickedPiece)) {
                    selectedPieces.remove(clickedPiece);
                    System.out.println("Deselected piece " + clickedPiece.getId());
                } else {
                    selectedPieces.add(clickedPiece);
                    System.out.println("Selected piece " + clickedPiece.getId() + " and initiating move");
                }
                
                // 更新提示显示
                showingHints = true;
                
                // 刷新UI显示选中状态
                repaint();
            } else {
                System.out.println("Piece cannot move with roll " + game.getCurrentRoll());
                // 显示错误提示
                currentActionLabel.setText("This piece cannot move " + game.getCurrentRoll() + " spaces. Try another piece.");
            }
        } else if (!selectedPieces.isEmpty()) {
            System.out.println("Processing move for " + selectedPieces.size() + " selected pieces");
            
            // 检查所有选中的棋子是否在同一位置
            boolean samePiecePosition = true;
            int position = selectedPieces.get(0).getPosition();
            
            for (int i = 1; i < selectedPieces.size(); i++) {
                if (selectedPieces.get(i).getPosition() != position) {
                    samePiecePosition = false;
                    break;
                }
            }
            
            // 如果多个棋子被选中，尝试堆叠它们
            if (selectedPieces.size() > 1 && samePiecePosition) {
                System.out.println("Stacking " + selectedPieces.size() + " pieces");
                boolean success = game.stackPieces(selectedPieces);
                if (success) {
                    System.out.println("Stacking successful");
                    
                    // 堆叠后进行移动
                    Piece leaderPiece = selectedPieces.get(0);
                    selectedPieces.clear();
                    selectedPieces.add(leaderPiece);
                    movePieceWithAnimation(leaderPiece);
                } else {
                    System.out.println("Stacking failed");
                    selectedPieces.clear();
                    updateUIAfterMove();
                }
            } 
            // 如果选中了一个棋子且点击了棋盘的其他位置，直接移动它
            else if (selectedPieces.size() == 1) {
                Piece selectedPiece = selectedPieces.get(0);
                // 移除检查点击位置是否接近目标位置的限制，直接移动棋子
                System.out.println("Moving single piece with animation");
                movePieceWithAnimation(selectedPiece);
            }
        } else {
            System.out.println("No piece selected or clicked");
            currentActionLabel.setText("Select one of your pieces to move " + game.getCurrentRoll() + " spaces");
        }
    }
} 