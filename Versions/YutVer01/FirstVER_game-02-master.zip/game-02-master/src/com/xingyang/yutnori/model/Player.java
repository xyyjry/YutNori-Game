package com.xingyang.yutnori.model;

import java.awt.Color;
import java.util.ArrayList;
import java.util.List;

/**
 * Represents a player in the Yut game.
 * Each player has a color and manages their own pieces.
 */
public class Player {
    private String name;
    private Color color;
    private List<Piece> pieces;
    private boolean hasWon;
    
    /**
     * Constructs a new player with the given name and color.
     * 
     * @param name The player's name
     * @param color The player's color
     */
    public Player(String name, Color color) {
        this.name = name;
        this.color = color;
        this.pieces = new ArrayList<>();
        this.hasWon = false;
        
        // Initialize 4 pieces for the player
        for (int i = 0; i < 4; i++) {
            pieces.add(new Piece(this, i));
        }
    }
    
    /**
     * Gets the player's name.
     * 
     * @return The player's name
     */
    public String getName() {
        return name;
    }
    
    /**
     * Gets the player's color.
     * 
     * @return The player's color
     */
    public Color getColor() {
        return color;
    }
    
    /**
     * Gets the list of player's pieces.
     * 
     * @return List of player's pieces
     */
    public List<Piece> getPieces() {
        return pieces;
    }
    
    /**
     * Checks if the player has any pieces that can move with the given roll.
     * 
     * @param roll The number of spaces to move
     * @return true if any piece can move, false otherwise
     */
    public boolean canMove(int roll) {
        for (Piece piece : pieces) {
            if (piece.canMove(roll)) {
                return true;
            }
        }
        return false;
    }
    
    /**
     * Checks if the player has won the game.
     * A player wins when all 4 pieces reach the end.
     * 
     * @return true if the player has won, false otherwise
     */
    public boolean hasWon() {
        int finishedPieces = 0;
        for (Piece piece : pieces) {
            if (piece.hasFinished()) {
                finishedPieces++;
            }
        }
        hasWon = finishedPieces == 4;
        return hasWon;
    }
    
    /**
     * Sets pieces to be stacked together.
     * When pieces are stacked, they move together.
     * 
     * @param pieces The list of pieces to stack
     */
    public void stackPieces(List<Piece> pieces) {
        if (pieces.size() < 2) {
            return;
        }
        
        Piece leader = pieces.get(0);
        for (int i = 1; i < pieces.size(); i++) {
            leader.stack(pieces.get(i));
        }
    }
    
    /**
     * Finds the lead piece for a stacked piece.
     * If the piece is not stacked, returns null.
     * 
     * @param piece The piece to find the lead piece for
     * @return The lead piece, or null if the piece is not stacked
     */
    public Piece getLeadPieceFor(Piece piece) {
        if (!piece.isStacked()) {
            // If the piece is not marked as stacked, it might be a lead piece itself
            // Check if this piece has any stacked pieces
            if (!piece.getStackedPieces().isEmpty()) {
                return piece;
            }
            return null;
        }
        
        // Search for a piece that has this piece in its stacked pieces
        for (Piece potentialLeader : pieces) {
            if (!potentialLeader.isStacked() && potentialLeader.getStackedPieces().contains(piece)) {
                return potentialLeader;
            }
        }
        
        return null;
    }
} 