package com.xingyang.yutnori.model;

import java.awt.Point;
import java.util.HashMap;
import java.util.Map;

/**
 * Represents the game board in the Yut game.
 * Defines the positions and paths for moving pieces.
 */
public class Board {
    // Board positions
    private Map<Integer, Point> positions;
    
    // Special path mappings for shortcuts
    private Map<Integer, Integer> specialPaths;
    
    /**
     * Constructs and initializes the game board.
     * Sets up the positions and special paths.
     */
    public Board() {
        initializePositions();
        initializeSpecialPaths();
    }
    
    /**
     * Initializes the positions on the board.
     * Each position is mapped to a coordinate for display.
     */
    private void initializePositions() {
        positions = new HashMap<>();
        
        // 设置棋盘位置 - 完全重新定位坐标与UI匹配
        int boardX = 180; // 棋盘左上角X坐标
        int boardY = 80;  // 棋盘左上角Y坐标
        int boardWidth = 450; // 棋盘宽度
        int boardHeight = 500; // 棋盘高度
        
        // 设置轨道位置
        int leftX = boardX + 40;    // 左侧轨道
        int rightX = boardX + boardWidth - 40; // 右侧轨道
        int topY = boardY + 40;     // 顶部轨道
        int bottomY = boardY + boardHeight - 40; // 底部轨道
        int midX = boardX + boardWidth/2;     // 水平中心
        int midY = boardY + boardHeight/2;    // 垂直中心
        
        // 计算坐标间距
        int spacingH = (rightX - leftX) / 4; // 水平间距
        int spacingV = (bottomY - topY) / 4; // 垂直间距
        
        // Outer track positions (0-20)
        positions.put(0, new Point(midX, bottomY));  // Start position
        positions.put(1, new Point(midX + spacingH, bottomY));
        positions.put(2, new Point(midX + 2*spacingH, bottomY));
        positions.put(3, new Point(midX + 3*spacingH, bottomY));
        positions.put(4, new Point(rightX, bottomY));
        positions.put(5, new Point(rightX, bottomY - spacingV));  // Corner
        positions.put(6, new Point(rightX, bottomY - 2*spacingV));
        positions.put(7, new Point(rightX, bottomY - 3*spacingV));
        positions.put(8, new Point(rightX, bottomY - 4*spacingV));
        positions.put(9, new Point(rightX, topY + spacingV));
        positions.put(10, new Point(rightX, topY)); // Corner
        positions.put(11, new Point(rightX - spacingH, topY));
        positions.put(12, new Point(rightX - 2*spacingH, topY));
        positions.put(13, new Point(rightX - 3*spacingH, topY));
        positions.put(14, new Point(midX, topY));
        positions.put(15, new Point(leftX, topY)); // Corner
        positions.put(16, new Point(leftX, topY + spacingV));
        positions.put(17, new Point(leftX, topY + 2*spacingV));
        positions.put(18, new Point(leftX, topY + 3*spacingV));
        positions.put(19, new Point(leftX, topY + 4*spacingV));
        positions.put(20, new Point(leftX, bottomY)); // Corner
        
        // Inner diagonal paths - 保持对角线路径
        int diagonalSpacing = spacingH / 2; // 对角线点之间的间距
        
        positions.put(21, new Point(leftX + diagonalSpacing, bottomY - diagonalSpacing)); // Shortcut from pos 0
        positions.put(22, new Point(leftX + 2*diagonalSpacing, bottomY - 2*diagonalSpacing));
        positions.put(23, new Point(leftX + 3*diagonalSpacing, bottomY - 3*diagonalSpacing));
        positions.put(24, new Point(midX, midY));
        positions.put(25, new Point(midX + diagonalSpacing, midY - diagonalSpacing));
        positions.put(26, new Point(midX + 2*diagonalSpacing, midY - 2*diagonalSpacing));
        positions.put(27, new Point(midX + 3*diagonalSpacing, midY - 3*diagonalSpacing)); // Joins back to main track at 10
        
        // Center shortcut diagonal
        positions.put(28, new Point(midX - diagonalSpacing, midY - diagonalSpacing)); // From center to top
        positions.put(29, new Point(midX - 2*diagonalSpacing, midY - 2*diagonalSpacing));
        
        // Finish position (not drawn)
        positions.put(30, new Point(midX, bottomY + 30));
    }
    
    /**
     * Initializes the special paths on the board.
     * Special paths include shortcuts and diagonal paths.
     */
    private void initializeSpecialPaths() {
        specialPaths = new HashMap<>();
        
        // Corner shortcuts
        specialPaths.put(5, 21);  // First corner shortcut
        specialPaths.put(10, 28); // Second corner shortcut
        specialPaths.put(15, 29); // Third corner shortcut
    }
    
    /**
     * Gets the next position based on current position and steps.
     * Takes into account special paths and shortcuts.
     * 
     * @param currentPos The current position
     * @param steps The number of steps to move
     * @return The new position
     */
    public int getNextPosition(int currentPos, int steps) {
        // Special case: starting from home
        if (currentPos == -1) {
            // When starting from home, first step is always to position 0
            if (steps == 1) { // Do (1)
                return 0;
            } else if (steps == 2) { // Gae (2)
                return 1;
            } else if (steps == 3) { // Geol (3)
                return 2;
            } else if (steps == 4) { // Yut (4)
                return 3;
            } else if (steps == 5) { // Mo (5)
                return 4;
            }
        }
        
        int newPos = currentPos;
        
        // Move through the board step by step
        for (int i = 0; i < steps; i++) {
            // First step might take a special path
            if (i == 0 && specialPaths.containsKey(newPos)) {
                newPos = specialPaths.get(newPos);
            } else {
                // Normal movement
                newPos++;
                
                // Transition back to main track at junctions
                if (newPos == 25) {
                    newPos = 15;
                } else if (newPos == 28) {
                    newPos = 15;
                } else if (newPos == 30) {
                    newPos = 20;
                }
            }
        }
        
        // Check if we've completed the main circuit
        if (newPos > 20) {
            // Only mark as finished if the piece has gone all the way around
            // or if it's on an inner track that leads to the finish
            boolean onInnerTrack = currentPos >= 21 && currentPos <= 29;
            boolean completedCircuit = (currentPos < 21 && newPos > 20);
            
            if (completedCircuit || (onInnerTrack && newPos > 27)) {
                return 30; // Mark as finished
            }
        }
        
        return newPos;
    }
    
    /**
     * Gets the coordinate for a specific position on the board.
     * 
     * @param position The position to get coordinates for
     * @return The coordinate point
     */
    public Point getCoordinate(int position) {
        // If finished or not on board, return null
        if (position == 30 || position == -1) {
            return null;
        }
        
        return positions.get(position);
    }
    
    /**
     * Checks if a position is a corner position (allowing shortcuts).
     * 
     * @param position The position to check
     * @return True if the position is a corner, false otherwise
     */
    public boolean isCorner(int position) {
        return position == 5 || position == 10 || position == 15 || position == 20;
    }
    
    /**
     * Checks if a position allows a shortcut.
     * 
     * @param position The position to check
     * @return True if a shortcut is available, false otherwise
     */
    public boolean hasShortcut(int position) {
        return specialPaths.containsKey(position);
    }
    
    /**
     * Gets the shortcut destination for a position.
     * 
     * @param position The current position
     * @return The shortcut destination, or -1 if none
     */
    public int getShortcutDestination(int position) {
        if (specialPaths.containsKey(position)) {
            return specialPaths.get(position);
        }
        return -1;
    }
} 