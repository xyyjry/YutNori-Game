package com.xingyang.yutnori.model;

/**
 * Represents a set of 4 Yut sticks used in the traditional Korean Yut game.
 * Handles throwing the sticks and calculating the resulting move.
 */
public class YutSet {
    public static final int DO = 1;   // One stick flat side up
    public static final int GAE = 2;  // Two sticks flat side up
    public static final int GEOL = 3; // Three sticks flat side up
    public static final int YUT = 4;  // Four sticks flat side up
    public static final int MO = 5;   // No sticks flat side up
    
    private YutStick[] sticks;
    
    /**
     * Constructs a set of 4 Yut sticks.
     */
    public YutSet() {
        sticks = new YutStick[4];
        for (int i = 0; i < 4; i++) {
            sticks[i] = new YutStick();
        }
    }
    
    /**
     * Throws all sticks and returns the result.
     * 
     * @return The result value (DO, GAE, GEOL, YUT, or MO)
     */
    public int toss() {
        // Direct random approach to ensure truly random distribution
        int result = (int)(Math.random() * 5) + 1;
        
        // Make sure to toss the sticks for animation purposes
        for (YutStick stick : sticks) {
            stick.toss();
        }
        
        return result;
    }
    
    /**
     * Calculates the result based on the current state of the sticks.
     * 
     * @return The result value (DO, GAE, GEOL, YUT, or MO)
     */
    public int getResult() {
        int flatCount = 0;
        
        for (YutStick stick : sticks) {
            if (stick.isFlatSideUp()) {
                flatCount++;
            }
        }
        
        if (flatCount == 0) {
            return MO;
        } else {
            return flatCount;
        }
    }
    
    /**
     * Checks if the current result allows for an additional throw.
     * In Yut game, throwing YUT or MO allows an additional throw.
     * 
     * @return true if result is YUT or MO, false otherwise
     */
    public boolean isReThrowAllowed() {
        int result = getResult();
        return result == YUT || result == MO;
    }
    
    /**
     * Gets the name of the current result.
     * 
     * @return String representation of the result
     */
    public String getResultName() {
        switch (getResult()) {
            case DO: return "Do";
            case GAE: return "Gae";
            case GEOL: return "Geol";
            case YUT: return "Yut";
            case MO: return "Mo";
            default: return "Invalid";
        }
    }
} 