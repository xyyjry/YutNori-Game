package com.xingyang.yutnori.model;

import java.util.ArrayList;
import java.util.List;

/**
 * Represents a game piece in the Yut game.
 * Each piece belongs to a player and can move on the board.
 */
public class Piece {
    private Player owner;
    private int id;
    private int position; // -1 means not on board, 0-29 are board positions, 30 is finished
    private List<Piece> stackedPieces; // Pieces stacked with this one
    private boolean isStacked; // If piece is stacked with another piece
    private Piece stackLeader; // The lead piece if this piece is stacked
    
    /**
     * Constructs a new piece for the specified player.
     * 
     * @param owner The player who owns this piece
     * @param id The unique identifier for this piece
     */
    public Piece(Player owner, int id) {
        this.owner = owner;
        this.id = id;
        this.position = -1; // Always start off board
        this.stackedPieces = new ArrayList<>();
        this.isStacked = false;
        this.stackLeader = null;
    }
    
    /**
     * Gets the owner of this piece.
     * 
     * @return The player who owns this piece
     */
    public Player getOwner() {
        return owner;
    }
    
    /**
     * Gets the unique identifier of this piece.
     * 
     * @return The piece ID
     */
    public int getId() {
        return id;
    }
    
    /**
     * Gets the current position of this piece on the board.
     * 
     * @return The position (-1 if off board, 30 if finished)
     */
    public int getPosition() {
        if (isStacked) {
            return stackLeader.getPosition();
        }
        return position;
    }
    
    /**
     * Sets the position of this piece on the board.
     * 
     * @param position The new position
     */
    public void setPosition(int position) {
        System.out.println("Setting piece " + id + " position to " + position);
        this.position = position;
        
        // Also move any stacked pieces
        for (Piece piece : stackedPieces) {
            piece.position = position;
            System.out.println("  Also moving stacked piece " + piece.getId() + " to " + position);
        }
    }
    
    /**
     * Moves the piece by the specified number of steps.
     * 
     * @param steps Number of steps to move
     * @return True if the piece reached the end, false otherwise
     */
    public boolean move(int steps) {
        // If this piece is stacked with another, the leader handles movement
        if (isStacked) {
            System.out.println("This piece is stacked and cannot move directly");
            return false;
        }
        
        System.out.println("Moving piece " + id + " by " + steps + " steps");
        
        // If piece is not on board yet, place it at the start position
        if (position == -1) {
            System.out.println("Piece not on board. Placing at start position.");
            position = 0;
            steps--;
        }
        
        if (steps <= 0) {
            System.out.println("No more steps to move.");
            return false;
        }
        
        // Move the piece
        position += steps;
        System.out.println("New position: " + position);
        
        // Check if piece has finished
        if (position >= 30) {
            position = 30; // Mark as finished
            System.out.println("Piece has finished!");
            return true;
        }
        
        // Move any stacked pieces as well
        for (Piece piece : stackedPieces) {
            piece.position = position;
        }
        
        return false;
    }
    
    /**
     * Checks if this piece can move with the given roll.
     * 
     * @param roll The number of spaces to move
     * @return True if the piece can move, false otherwise
     */
    public boolean canMove(int roll) {
        // If stacked, only the leader can move
        if (isStacked) {
            System.out.println("Piece " + id + " is stacked and cannot move");
            return false;
        }
        
        // If not on board yet, always can move
        if (position == -1) {
            System.out.println("Piece " + id + " is not on board yet and can be placed");
            return true;
        }
        
        // If already finished, can't move
        if (position == 30) {
            System.out.println("Piece " + id + " has already finished");
            return false;
        }
        
        System.out.println("Piece " + id + " at position " + position + " can move " + roll + " steps");
        return true;
    }
    
    /**
     * Checks if this piece has finished the game.
     * 
     * @return True if the piece has finished, false otherwise
     */
    public boolean hasFinished() {
        return getPosition() == 30;
    }
    
    /**
     * Stacks this piece with another piece.
     * When pieces are stacked, they move together.
     * 
     * @param piece The piece to stack with this one
     */
    public void stack(Piece piece) {
        System.out.println("Stacking piece " + piece.getId() + " with leader piece " + id);
        
        if (piece.isStacked) {
            // If the piece is already stacked, unstack it first
            System.out.println("Piece " + piece.getId() + " is already stacked with " + piece.stackLeader.getId() + ". Unstacking first.");
            piece.stackLeader.unstackPiece(piece);
        }
        
        stackedPieces.add(piece);
        piece.isStacked = true;
        piece.stackLeader = this;
        piece.position = this.position;
        System.out.println("Piece " + piece.getId() + " is now stacked with " + id + " at position " + position);
    }
    
    /**
     * Unstacks a piece from this stack.
     * 
     * @param piece The piece to unstack
     */
    public void unstackPiece(Piece piece) {
        if (stackedPieces.contains(piece)) {
            System.out.println("Unstacking piece " + piece.getId() + " from " + id);
            stackedPieces.remove(piece);
            piece.isStacked = false;
            piece.stackLeader = null;
        }
    }
    
    /**
     * Gets all pieces stacked with this piece.
     * 
     * @return List of stacked pieces
     */
    public List<Piece> getStackedPieces() {
        return new ArrayList<>(stackedPieces);
    }
    
    /**
     * Checks if this piece is stacked with other pieces.
     * 
     * @return True if this piece has other pieces stacked with it, false otherwise
     */
    public boolean hasStackedPieces() {
        return !stackedPieces.isEmpty();
    }
    
    /**
     * Gets the total number of pieces in this stack.
     * 
     * @return The stack size (1 if not stacked)
     */
    public int getStackSize() {
        return stackedPieces.size() + 1;
    }
    
    /**
     * Checks if this piece is stacked with another piece.
     * 
     * @return True if this piece is part of a stack, false otherwise
     */
    public boolean isStacked() {
        return isStacked;
    }
    
    /**
     * Gets the leader of the stack this piece belongs to.
     * 
     * @return The leader piece, or null if not stacked
     */
    public Piece getStackLeader() {
        return stackLeader;
    }
} 