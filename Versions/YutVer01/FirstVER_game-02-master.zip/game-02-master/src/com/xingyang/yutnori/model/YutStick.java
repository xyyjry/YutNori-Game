package com.xingyang.yutnori.model;

/**
 * Represents a single Yut stick used in the traditional Korean Yut game.
 * Each stick has two sides - flat and curved.
 */
public class YutStick {
    private boolean flatSideUp;
    
    /**
     * Constructs a Yut stick with random initial state.
     */
    public YutStick() {
        // Randomly determine initial state
        this.flatSideUp = Math.random() < 0.5;
    }
    
    /**
     * Throws the stick to get a random result.
     */
    public void toss() {
        // 60% chance of flat side up, 40% chance of curved side up
        this.flatSideUp = Math.random() < 0.6;
    }
    
    /**
     * Checks if the flat side is facing up.
     * 
     * @return true if flat side is up, false otherwise
     */
    public boolean isFlatSideUp() {
        return flatSideUp;
    }
} 