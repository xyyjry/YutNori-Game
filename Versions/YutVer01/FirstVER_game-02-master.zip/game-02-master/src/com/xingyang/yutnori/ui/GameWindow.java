package com.xingyang.yutnori.ui;

import com.xingyang.yutnori.model.Game;
import com.xingyang.yutnori.model.YutSet;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * The main game window for the Yut game.
 * Contains the game board, Yut stick panel, and information panel.
 */
public class GameWindow extends JFrame {
    private Game game;
    private GameBoard gameBoard;
    private YutStickPanel yutStickPanel;
    private JPanel infoPanel;
    private JButton endTurnButton;
    private JButton newGameButton;
    
    /**
     * Constructs a new game window with the given player names.
     * 
     * @param playerNames Names of the players
     */
    public GameWindow(String[] playerNames) {
        // Set up the window
        super("Yut Nori - Traditional Korean Board Game");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1100, 800); // 进一步增加窗口宽度
        setLocationRelativeTo(null);
        setResizable(false);
        
        // Create the game
        game = new Game(playerNames);
        
        // Create UI components
        createComponents();
        
        // Set layout and add components
        setupLayout();
        
        // Show the window
        setVisible(true);
    }
    
    /**
     * Creates all UI components.
     */
    private void createComponents() {
        // Create game board
        gameBoard = new GameBoard(game);
        
        // Create Yut stick panel
        YutSet yutSet = new YutSet();
        yutStickPanel = new YutStickPanel(yutSet, gameBoard);
        
        // Create info panel
        infoPanel = createInfoPanel();
        
        // Create buttons
        endTurnButton = new JButton("End Turn");
        endTurnButton.setFont(new Font("Arial", Font.BOLD, 16));
        endTurnButton.setBackground(new Color(210, 180, 140)); // Tan color
        endTurnButton.setForeground(Color.BLACK);
        endTurnButton.setFocusPainted(false);
        endTurnButton.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(139, 69, 19), 2), // Brown border
                BorderFactory.createEmptyBorder(10, 20, 10, 20)
        ));
        
        endTurnButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // 确保只有在游戏没有结束时才能结束回合
                if (game.isGameOver()) {
                    JOptionPane.showMessageDialog(GameWindow.this, 
                        "Game is over! " + game.getWinner().getName() + " has won!", 
                        "Game Over", 
                        JOptionPane.INFORMATION_MESSAGE);
                    return;
                }
                
                // 确保玩家已经扔过骰子
                if (!game.hasRolled()) {
                    // 增加更清晰的错误消息
                    JOptionPane.showMessageDialog(GameWindow.this,
                        "You must throw the Yut sticks before ending your turn.\n\n" +
                        "Click the 'Throw Yut Sticks' button first.",
                        "Action Required",
                        JOptionPane.WARNING_MESSAGE);
                    
                    // 高亮Throw按钮
                    yutStickPanel.highlightThrowButton();
                    return;
                }
                
                // 结束当前玩家回合
                String currentPlayerName = game.getCurrentPlayer().getName();
                game.endTurn();
                
                // 重置UI组件
                yutStickPanel.setThrowEnabled(true);
                yutStickPanel.reset(); // 重置YutStickPanel以清除上一次掷骰子的结果
                gameBoard.reset(); // 重置GameBoard状态
                
                // 显示回合变更提示
                JOptionPane.showMessageDialog(GameWindow.this, 
                    "Turn ended. Now it's " + game.getCurrentPlayer().getName() + "'s turn.", 
                    "Turn Changed", 
                    JOptionPane.INFORMATION_MESSAGE);
                
                // 更新UI显示
                gameBoard.repaint();
            }
        });
        
        newGameButton = new JButton("New Game");
        newGameButton.setFont(new Font("Arial", Font.BOLD, 16));
        newGameButton.setBackground(new Color(210, 180, 140)); // Tan color
        newGameButton.setForeground(Color.BLACK);
        newGameButton.setFocusPainted(false);
        newGameButton.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(139, 69, 19), 2), // Brown border
                BorderFactory.createEmptyBorder(10, 20, 10, 20)
        ));
        
        newGameButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int confirm = JOptionPane.showConfirmDialog(GameWindow.this,
                    "Are you sure you want to start a new game?",
                    "New Game Confirmation",
                    JOptionPane.YES_NO_OPTION);
                
                if (confirm == JOptionPane.YES_OPTION) {
                    // 获取当前玩家名称
                    String[] playerNames = new String[game.getPlayers().size()];
                    for (int i = 0; i < playerNames.length; i++) {
                        playerNames[i] = game.getPlayers().get(i).getName();
                    }
                    
                    // 关闭当前窗口并创建新的游戏窗口
                    dispose();
                    SwingUtilities.invokeLater(new Runnable() {
                        @Override
                        public void run() {
                            new GameWindow(playerNames);
                        }
                    });
                }
            }
        });
    }
    
    /**
     * Creates the information panel with game instructions.
     * 
     * @return The information panel
     */
    private JPanel createInfoPanel() {
        JPanel panel = new JPanel();
        panel.setLayout(new BorderLayout());
        panel.setBackground(new Color(245, 245, 220)); // Beige background
        panel.setBorder(BorderFactory.createTitledBorder("Game Rules"));
        
        JTextArea rulesText = new JTextArea(
                "Yut Nori - Game Rules:\n\n" +
                "1. Players take turns throwing the Yut sticks and moving their pieces.\n\n" +
                "2. The Yut sticks can result in the following moves:\n" +
                "   - Do (1): Move 1 space\n" +
                "   - Gae (2): Move 2 spaces\n" +
                "   - Geol (3): Move 3 spaces\n" +
                "   - Yut (4): Move 4 spaces and throw again\n" +
                "   - Mo (5): Move 5 spaces and throw again\n\n" +
                "3. To move a piece, click on it after throwing the sticks.\n\n" +
                "4. To stack pieces, select multiple pieces at the same position and click on an empty area.\n\n" +
                "5. If your piece lands on an opponent's piece, it captures that piece (sending it back to start).\n\n" +
                "6. The goal is to get all 4 of your pieces to the finish position.\n\n" +
                "7. Corner positions allow shortcuts across the board."
        );
        
        rulesText.setEditable(false);
        rulesText.setBackground(new Color(245, 245, 220));
        rulesText.setFont(new Font("Arial", Font.PLAIN, 14));
        rulesText.setLineWrap(true);
        rulesText.setWrapStyleWord(true);
        
        panel.add(new JScrollPane(rulesText), BorderLayout.CENTER);
        
        return panel;
    }
    
    /**
     * Sets up the layout and adds components to the window.
     */
    private void setupLayout() {
        // 使用更灵活的布局
        setLayout(new BorderLayout(20, 20)); // 增加组件间的间距
        
        // 创建左侧面板(游戏板)
        JPanel leftPanel = new JPanel(new BorderLayout(10, 10));
        leftPanel.setBackground(new Color(240, 230, 200));
        leftPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 10));
        
        // 添加游戏板到左侧面板
        leftPanel.add(gameBoard, BorderLayout.CENTER);
        
        // 创建右侧面板(控制区域)
        JPanel rightPanel = new JPanel();
        rightPanel.setLayout(new BoxLayout(rightPanel, BoxLayout.Y_AXIS));
        rightPanel.setBackground(new Color(240, 230, 200));
        rightPanel.setBorder(BorderFactory.createEmptyBorder(20, 10, 20, 20));
        rightPanel.setPreferredSize(new Dimension(300, getHeight())); // 增加右侧面板宽度
        
        // 添加Yut棍面板
        yutStickPanel.setAlignmentX(Component.CENTER_ALIGNMENT);
        rightPanel.add(yutStickPanel);
        
        // 添加垂直间隔
        rightPanel.add(Box.createVerticalStrut(20));
        
        // 添加规则面板
        infoPanel.setAlignmentX(Component.CENTER_ALIGNMENT);
        infoPanel.setMaximumSize(new Dimension(300, 350)); // 限制规则面板高度
        rightPanel.add(infoPanel);
        
        // 添加垂直间隔
        rightPanel.add(Box.createVerticalStrut(20));
        
        // 创建按钮面板
        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new BoxLayout(buttonPanel, BoxLayout.X_AXIS));
        buttonPanel.setBackground(new Color(245, 245, 220));
        buttonPanel.setAlignmentX(Component.CENTER_ALIGNMENT);
        buttonPanel.setBorder(BorderFactory.createEmptyBorder(10, 0, 10, 0));
        
        // 调整按钮
        endTurnButton.setFont(new Font("Arial", Font.BOLD, 16));
        newGameButton.setFont(new Font("Arial", Font.BOLD, 16));
        
        buttonPanel.add(endTurnButton);
        buttonPanel.add(Box.createHorizontalStrut(20)); // 增加按钮间距
        buttonPanel.add(newGameButton);
        
        rightPanel.add(buttonPanel);
        
        // 添加主面板到窗口
        add(leftPanel, BorderLayout.CENTER);
        add(rightPanel, BorderLayout.EAST);
    }
} 