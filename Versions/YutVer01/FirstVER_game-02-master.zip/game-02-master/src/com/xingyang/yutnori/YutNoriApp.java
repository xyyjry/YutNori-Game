package com.xingyang.yutnori;

import com.xingyang.yutnori.ui.GameWindow;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;

/**
 * The main application class for the Yut Nori game.
 * Handles startup and player configuration.
 */
public class YutNoriApp {
    /**
     * The main entry point for the application.
     * 
     * @param args Command line arguments (not used)
     */
    public static void main(String[] args) {
        // Set look and feel to system
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        // Start the application
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                showStartScreen();
            }
        });
    }
    
    /**Ω
     * Shows the start screen to get player names and start the game.
     */
    private static void showStartScreen() {
        final JFrame startFrame = new JFrame("Yut Nori - Player Setup");
        startFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        startFrame.setSize(500, 400);
        startFrame.setLocationRelativeTo(null);
        startFrame.setResizable(false);
        
        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new BorderLayout());
        mainPanel.setBackground(new Color(245, 245, 220)); // Beige background
        
        // Title label
        JLabel titleLabel = new JLabel("Yut Nori - Traditional Korean Board Game", JLabel.CENTER);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 24));
        titleLabel.setForeground(new Color(139, 69, 19)); // Brown
        titleLabel.setBorder(BorderFactory.createEmptyBorder(20, 0, 20, 0));
        
        // Player panel
        JPanel playerPanel = new JPanel(new GridLayout(4, 2, 10, 10));
        playerPanel.setBackground(new Color(245, 245, 220));
        playerPanel.setBorder(BorderFactory.createEmptyBorder(10, 40, 10, 40));
        
        // Player input fields
        final JTextField[] playerFields = new JTextField[4];
        for (int i = 0; i < 4; i++) {
            JLabel playerLabel = new JLabel("Player " + (i + 1) + " Name:");
            playerLabel.setFont(new Font("Arial", Font.PLAIN, 16));
            
            playerFields[i] = new JTextField(i == 0 ? "Player 1" : i == 1 ? "Player 2" : "");
            playerFields[i].setFont(new Font("Arial", Font.PLAIN, 16));
            
            playerPanel.add(playerLabel);
            playerPanel.add(playerFields[i]);
        }
        
        // Number of players selector
        JPanel numPlayersPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        numPlayersPanel.setBackground(new Color(245, 245, 220));
        JLabel numPlayersLabel = new JLabel("Number of Players:");
        numPlayersLabel.setFont(new Font("Arial", Font.PLAIN, 16));
        
        Integer[] playerCounts = {2, 3, 4};
        final JComboBox<Integer> numPlayersCombo = new JComboBox<>(playerCounts);
        numPlayersCombo.setFont(new Font("Arial", Font.PLAIN, 16));
        
        numPlayersCombo.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int numPlayers = (Integer) numPlayersCombo.getSelectedItem();
                for (int i = 0; i < playerFields.length; i++) {
                    playerFields[i].setEnabled(i < numPlayers);
                    if (i >= numPlayers) {
                        playerFields[i].setText("");
                    }
                }
            }
        });
        
        numPlayersPanel.add(numPlayersLabel);
        numPlayersPanel.add(numPlayersCombo);
        
        // Start button
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        buttonPanel.setBackground(new Color(245, 245, 220));
        JButton startButton = new JButton("Start Game");
        startButton.setFont(new Font("Arial", Font.BOLD, 16));
        startButton.setBackground(new Color(210, 180, 140)); // Tan color
        startButton.setForeground(Color.BLACK);
        startButton.setFocusPainted(false);
        startButton.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(139, 69, 19), 2), // Brown border
                BorderFactory.createEmptyBorder(10, 20, 10, 20)
        ));
        
        startButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int numPlayers = (Integer) numPlayersCombo.getSelectedItem();
                List<String> names = new ArrayList<>();
                
                boolean validNames = true;
                for (int i = 0; i < numPlayers; i++) {
                    String name = playerFields[i].getText().trim();
                    if (name.isEmpty()) {
                        validNames = false;
                        playerFields[i].setBackground(new Color(255, 200, 200)); // Light red for error
                    } else {
                        names.add(name);
                        playerFields[i].setBackground(Color.WHITE);
                    }
                }
                
                if (validNames) {
                    startFrame.dispose();
                    new GameWindow(names.toArray(new String[0]));
                } else {
                    JOptionPane.showMessageDialog(startFrame, 
                            "Please enter names for all players.", 
                            "Missing Names", 
                            JOptionPane.WARNING_MESSAGE);
                }
            }
        });
        
        buttonPanel.add(startButton);
        
        // Add components to main panel
        mainPanel.add(titleLabel, BorderLayout.NORTH);
        mainPanel.add(playerPanel, BorderLayout.CENTER);
        
        JPanel southPanel = new JPanel(new BorderLayout());
        southPanel.setBackground(new Color(245, 245, 220));
        southPanel.add(numPlayersPanel, BorderLayout.NORTH);
        southPanel.add(buttonPanel, BorderLayout.SOUTH);
        
        mainPanel.add(southPanel, BorderLayout.SOUTH);
        
        // Set initial state
        for (int i = 2; i < playerFields.length; i++) {
            playerFields[i].setEnabled(false);
        }
        
        startFrame.add(mainPanel);
        startFrame.setVisible(true);
    }
} 