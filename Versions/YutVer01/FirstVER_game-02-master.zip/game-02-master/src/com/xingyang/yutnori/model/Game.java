package com.xingyang.yutnori.model;

import java.awt.Color;
import java.util.ArrayList;
import java.util.List;

/**
 * Manages the game state for the Yut game.
 * Coordinates players, turns, moves, and game rules.
 */
public class Game {
    private final Board board;
    private final YutSet yutSet;
    private final List<Player> players;
    private int currentPlayerIndex;
    private int currentRoll;
    private boolean hasRolled;
    private boolean gameOver;
    private boolean allowReThrow;
    
    /**
     * Constructs a new game with the specified players.
     * 
     * @param playerNames Names of the players
     */
    public Game(String[] playerNames) {
        board = new Board();
        yutSet = new YutSet();
        players = new ArrayList<>();
        
        // Create players with different colors
        Color[] playerColors = {
            new Color(255, 0, 0),    // Red
            new Color(0, 0, 255),    // Blue
            new Color(0, 150, 0),    // Green
            new Color(255, 200, 0)   // Yellow
        };
        
        for (int i = 0; i < playerNames.length && i < 4; i++) {
            players.add(new Player(playerNames[i], playerColors[i]));
        }
        
        currentPlayerIndex = 0;
        currentRoll = 0;
        hasRolled = false;
        gameOver = false;
        allowReThrow = false;
    }
    
    /**
     * Gets the game board.
     * 
     * @return The game board
     */
    public Board getBoard() {
        return board;
    }
    
    /**
     * Gets the list of players.
     * 
     * @return The list of players
     */
    public List<Player> getPlayers() {
        return players;
    }
    
    /**
     * Gets the current player.
     * 
     * @return The current player
     */
    public Player getCurrentPlayer() {
        return players.get(currentPlayerIndex);
    }
    
    /**
     * Checks if the game is over.
     * 
     * @return True if the game is over, false otherwise
     */
    public boolean isGameOver() {
        return gameOver;
    }
    
    /**
     * Gets the winner of the game.
     * 
     * @return The winner, or null if the game is not over
     */
    public Player getWinner() {
        if (!gameOver) {
            return null;
        }
        
        for (Player player : players) {
            if (player.hasWon()) {
                return player;
            }
        }
        
        return null;
    }
    
    /**
     * Rolls the Yut sticks for the current player.
     * 
     * @return The result of the roll
     */
    public int rollYut() {
        currentRoll = yutSet.toss();
        hasRolled = true;
        allowReThrow = yutSet.isReThrowAllowed();
        
        return currentRoll;
    }
    
    /**
     * Gets the result of the current roll.
     * 
     * @return The current roll result
     */
    public int getCurrentRoll() {
        return currentRoll;
    }
    
    /**
     * Gets the name of the current roll.
     * 
     * @return The name of the current roll
     */
    public String getCurrentRollName() {
        if (currentRoll == YutSet.DO) return "Do";
        if (currentRoll == YutSet.GAE) return "Gae";
        if (currentRoll == YutSet.GEOL) return "Geol";
        if (currentRoll == YutSet.YUT) return "Yut";
        if (currentRoll == YutSet.MO) return "Mo";
        return "Invalid";
    }
    
    /**
     * Checks if a re-throw is allowed for the current roll.
     * In Yut game, throwing YUT or MO allows an additional throw.
     * 
     * @return True if re-throw is allowed, false otherwise
     */
    public boolean isReThrowAllowed() {
        return allowReThrow;
    }
    
    /**
     * Checks if the current player has rolled the Yut sticks.
     * 
     * @return True if the player has rolled, false otherwise
     */
    public boolean hasRolled() {
        return hasRolled;
    }
    
    /**
     * Moves a piece for the current player.
     * 
     * @param piece The piece to move
     * @return True if the move was successful, false otherwise
     */
    public boolean movePiece(Piece piece) {
        // 输出调试信息
        System.out.println("Attempting to move piece " + piece.getId() + " for player " + getCurrentPlayer().getName());
        System.out.println("Has rolled: " + hasRolled + ", Current roll: " + currentRoll + " (" + getCurrentRollName() + ")");
        System.out.println("Is piece owner current player? " + (piece.getOwner() == getCurrentPlayer()));
        
        if (!hasRolled || piece.getOwner() != getCurrentPlayer()) {
            System.out.println("Move failed: " + (!hasRolled ? "Player has not rolled" : "Piece does not belong to current player"));
            return false;
        }
        
        // 检查是否为堆叠棋子（作为非主棋子）
        if (piece.isStacked()) {
            System.out.println("This is a stacked piece. We need to find and move the lead piece.");
            // 查找拥有这个棋子的主棋子
            for (Piece potentialLeader : getCurrentPlayer().getPieces()) {
                if (!potentialLeader.isStacked() && potentialLeader.getStackedPieces().contains(piece)) {
                    System.out.println("Found lead piece " + potentialLeader.getId() + " for stacked piece " + piece.getId());
                    return movePiece(potentialLeader);
                }
            }
        }
        
        // Check if piece can be moved with current roll
        if (!piece.canMove(currentRoll)) {
            System.out.println("Move failed: Piece cannot move with current roll");
            return false;
        }
        
        // Calculate new position based on current roll
        int currentPosition = piece.getPosition();
        int newPosition = board.getNextPosition(currentPosition, currentRoll);
        
        System.out.println("Moving piece " + piece.getId() + " from position " + currentPosition + " to " + newPosition);
        System.out.println("Current roll: " + currentRoll + " (" + getCurrentRollName() + ")");
        
        // 如果棋子从家出发，确保位置设置正确
        if (currentPosition == -1) {
            System.out.println("Moving piece from home to board");
            // Detailed debug for starting position
            System.out.println("Roll: " + currentRoll + " (" + getCurrentRollName() + ") => Move to position: " + newPosition);
        }
        
        // Update piece position
        piece.setPosition(newPosition);
        
        // Also update any stacked pieces
        for (Piece stackedPiece : piece.getStackedPieces()) {
            stackedPiece.setPosition(newPosition);
            System.out.println("Updated stacked piece " + stackedPiece.getId() + " to position " + newPosition);
        }
        
        // Check for capturing opponent pieces
        checkCapture(piece);
        
        // Check if game is over
        if (getCurrentPlayer().hasWon()) {
            gameOver = true;
            System.out.println("Game over! " + getCurrentPlayer().getName() + " has won!");
        }
        
        // End turn if no re-throw is allowed
        if (!allowReThrow) {
            // We don't end turn here to let GameWindow handle it
            System.out.println("No re-throw allowed. Turn will end when player clicks End Turn button.");
            hasRolled = true; // Mark as rolled so the end turn button works
        } else {
            // Reset hasRolled so player can roll again
            hasRolled = false;
            System.out.println("Re-throw allowed. Player can roll again.");
        }
        
        return true;
    }
    
    /**
     * Checks if the moved piece can capture opponent pieces.
     * 
     * @param movedPiece The piece that was moved
     */
    private void checkCapture(Piece movedPiece) {
        if (movedPiece.getPosition() == -1 || movedPiece.getPosition() == 30) {
            return;
        }
        
        for (Player player : players) {
            if (player == movedPiece.getOwner()) {
                continue;
            }
            
            for (Piece piece : player.getPieces()) {
                if (piece.getPosition() == movedPiece.getPosition() && !piece.isStacked()) {
                    // Capture opponent piece
                    System.out.println("Capturing opponent piece " + piece.getId());
                    piece.setPosition(-1);
                    
                    // Also capture any stacked pieces
                    for (Piece stackedPiece : piece.getStackedPieces()) {
                        stackedPiece.setPosition(-1);
                    }
                }
            }
        }
    }
    
    /**
     * Stacks pieces at the same position.
     * 
     * @param pieces The pieces to stack
     * @return True if stacking was successful, false otherwise
     */
    public boolean stackPieces(List<Piece> pieces) {
        if (pieces.size() < 2) {
            return false;
        }
        
        // Check that all pieces belong to the current player
        for (Piece piece : pieces) {
            if (piece.getOwner() != getCurrentPlayer()) {
                return false;
            }
        }
        
        // Check that all pieces are at the same position
        int position = pieces.get(0).getPosition();
        for (int i = 1; i < pieces.size(); i++) {
            if (pieces.get(i).getPosition() != position) {
                return false;
            }
        }
        
        // Stack the pieces
        System.out.println("Stacking " + pieces.size() + " pieces at position " + position);
        getCurrentPlayer().stackPieces(pieces);
        return true;
    }
    
    /**
     * Ends the current player's turn and moves to the next player.
     */
    public void endTurn() {
        if (gameOver) {
            return;
        }
        
        System.out.println("Ending turn for player " + getCurrentPlayer().getName());
        
        // Move to next player
        currentPlayerIndex = (currentPlayerIndex + 1) % players.size();
        
        // Reset turn state
        currentRoll = 0;
        hasRolled = false;
        allowReThrow = false;
        
        System.out.println("New turn: " + getCurrentPlayer().getName());
    }
} 